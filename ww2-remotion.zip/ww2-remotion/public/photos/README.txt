Letakkan foto sejarah (domain publik) di folder ini, lalu atur di src/config.ts:
  USE_REAL_PHOTOS = true
dan sesuaikan nama file di PHOTO_FILES.

Sumber foto domain publik yang disarankan:
- Wikimedia Commons (cari "World War II", pilih lisensi Public domain)
- US National Archives (catalog.archives.gov)
- Library of Congress (loc.gov)
- Imperial War Museums (cek lisensi tiap foto)
Ukuran ideal: lebar >= 1200 px, format .jpg
