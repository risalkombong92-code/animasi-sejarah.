// Membuat musik latar sinematik-dokumenter 60 detik (WAV stereo 44.1 kHz) tanpa library.
// Drone + pad akor (Am-F-Dm-E-Am) + detak jam + taiko + string swell.
// Ingin musik sendiri? Taruh file di public/ dan ubah MUSIC_FILE di src/config.ts.
import fs from 'node:fs';
import path from 'node:path';

const OUT = path.join(process.cwd(), 'public', 'music.wav');
if (fs.existsSync(OUT) && !process.argv.includes('--force')) {
  console.log('public/music.wav sudah ada - dilewati (pakai --force untuk buat ulang).');
  process.exit(0);
}

const SR = 44100;
const DUR = 60;
const N = SR * DUR;
const TAU = Math.PI * 2;
const dry = new Float32Array(N);

let seed = 20240901;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const midi = (n) => 440 * Math.pow(2, (n - 69) / 12);
const smooth = (x) => (x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x));

// ---------- Pad akor ----------
const chords = [
  {s: 0, e: 14, n: [33, 40, 45, 48]},
  {s: 12, e: 26, n: [29, 36, 41, 45]},
  {s: 24, e: 38, n: [26, 33, 38, 41]},
  {s: 36, e: 50, n: [28, 35, 40, 44]},
  {s: 48, e: 62, n: [33, 40, 45, 48]},
];
const ATT = 3.5;
const REL = 3.5;
const chordLevel = (c, t) => smooth((t - c.s) / ATT) * (1 - smooth((t - (c.e - REL)) / REL));

for (const c of chords) {
  const i0 = Math.max(0, Math.floor(c.s * SR));
  const i1 = Math.min(N, Math.floor(c.e * SR));
  for (const note of c.n) {
    const f = midi(note);
    for (let i = i0; i < i1; i++) {
      const t = i / SR;
      const lvl = chordLevel(c, t);
      if (lvl <= 0) continue;
      const vib = 1 + 0.002 * Math.sin(TAU * 0.35 * t + note);
      let s = 0;
      for (let h = 1; h <= 3; h++) {
        const a = 1 / Math.pow(h, 1.4);
        s += a * Math.sin(TAU * f * h * vib * 0.999 * t);
        s += a * Math.sin(TAU * f * h * vib * 1.001 * t + 1.3);
      }
      dry[i] += s * lvl * 0.045;
    }
  }
}

// Sub-drone A1 konstan
for (let i = 0; i < N; i++) {
  const t = i / SR;
  dry[i] += Math.sin(TAU * 55 * t) * 0.07 * smooth(t / 4) + Math.sin(TAU * 110.2 * t) * 0.025;
}

// ---------- String swell (30-56 s) ----------
for (const note of [57, 60, 64, 69]) {
  const f = midi(note);
  for (let i = Math.floor(30 * SR); i < Math.min(N, Math.floor(56 * SR)); i++) {
    const t = i / SR;
    const env = smooth((t - 30) / 18) * (1 - smooth((t - 50) / 6));
    const trem = 0.75 + 0.25 * Math.sin(TAU * 5.2 * t);
    let s = 0;
    for (let h = 1; h <= 4; h++) s += Math.sin(TAU * f * h * t) / (h * h * 0.7);
    dry[i] += s * env * trem * 0.018;
  }
}

// ---------- Perkusi ----------
const addTaiko = (time, vol) => {
  const i0 = Math.floor(time * SR);
  let ph = 0;
  for (let k = 0; k < SR * 1.1 && i0 + k < N; k++) {
    const x = k / SR;
    const f = 38 + 62 * Math.exp(-x * 9);
    ph += (TAU * f) / SR;
    const env = Math.exp(-x * 5.5);
    const click = x < 0.02 ? rnd() * (1 - x / 0.02) * 0.35 : 0;
    dry[i0 + k] += (Math.sin(ph) * env + click) * vol;
  }
};
const addTick = (time, vol) => {
  const i0 = Math.floor(time * SR);
  let last = 0;
  for (let k = 0; k < SR * 0.05 && i0 + k < N; k++) {
    const x = k / SR;
    last = last * 0.55 + rnd() * 0.45;
    dry[i0 + k] += last * Math.exp(-x * 160) * vol;
  }
};

addTaiko(0.5, 0.35);
addTaiko(4.5, 0.3);
for (let t = 9; t < 34; t += 1) addTick(t, 0.09);
for (let t = 12; t < 34; t += 4) addTaiko(t, 0.38);
let n = 0;
for (let t = 34; t < 52; t += 0.75, n++) addTaiko(t, n % 4 === 0 ? 0.62 : 0.4);
addTaiko(52, 0.85);
addTaiko(55.5, 0.3);

// ---------- Reverb sederhana (comb filter) -> stereo ----------
const combs = (delays, g) => {
  const out = new Float32Array(N);
  for (const d of delays) {
    const len = Math.floor(d * SR);
    const buf = new Float32Array(len);
    let p = 0;
    for (let i = 0; i < N; i++) {
      const y = dry[i] + buf[p] * g;
      buf[p] = y;
      p = (p + 1) % len;
      out[i] += y / delays.length;
    }
  }
  return out;
};
const wetL = combs([0.0677, 0.0791, 0.0913, 0.1013], 0.84);
const wetR = combs([0.0713, 0.0839, 0.0937, 0.1049], 0.84);

// ---------- Mix, fade, normalisasi ----------
const L = new Float32Array(N);
const R = new Float32Array(N);
let peak = 0;
for (let i = 0; i < N; i++) {
  const t = i / SR;
  const fade = smooth(t / 3) * (1 - smooth((t - 56) / 4));
  L[i] = (dry[i] * 0.65 + wetL[i] * 0.55) * fade;
  R[i] = (dry[i] * 0.65 + wetR[i] * 0.55) * fade;
  peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
}
const gain = 0.85 / (peak || 1);

const data = Buffer.alloc(N * 4);
for (let i = 0; i < N; i++) {
  data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(L[i] * gain * 32767))), i * 4);
  data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(R[i] * gain * 32767))), i * 4 + 2);
}
const header = Buffer.alloc(44);
header.write('RIFF', 0);
header.writeUInt32LE(36 + data.length, 4);
header.write('WAVEfmt ', 8);
header.writeUInt32LE(16, 16);
header.writeUInt16LE(1, 20);
header.writeUInt16LE(2, 22);
header.writeUInt32LE(SR, 24);
header.writeUInt32LE(SR * 4, 28);
header.writeUInt16LE(4, 32);
header.writeUInt16LE(16, 34);
header.write('data', 36);
header.writeUInt32LE(data.length, 40);

fs.mkdirSync(path.dirname(OUT), {recursive: true});
fs.writeFileSync(OUT, Buffer.concat([header, data]));
console.log(`OK: ${OUT} (${(data.length / 1048576).toFixed(1)} MB)`);
