#!/usr/bin/env bash
# Setup sekali jalan untuk GitHub Codespaces (Linux Debian/Ubuntu)
set -e
echo ">> Memasang library sistem untuk Chrome headless..."
sudo apt-get update -y
sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 libgbm-dev \
  libasound2 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 \
  libpango-1.0-0 libcairo2 libcups2 unzip
echo ">> npm install..."
npm install
echo ">> Membuat musik sinematik..."
npm run music
echo ">> SELESAI. Jalankan: npm start"
