# Perang Dunia II - Documentary Motion Graphics (Remotion)

Video 60 detik · 1920×1080 · 30 FPS · gaya dokumenter (peta, foto arsip, garis waktu, kinetic typography, efek film).

## Struktur folder

```
ww2-remotion/
├── .devcontainer/devcontainer.json   # Konfigurasi otomatis GitHub Codespaces
├── setup.sh                          # Install library sistem + npm install + buat musik
├── package.json / tsconfig.json / remotion.config.ts
├── scripts/generate-music.mjs        # Membuat musik sinematik (WAV 60 dtk) tanpa library
├── public/
│   ├── photos/                       # (opsional) taruh foto sejarah domain publik di sini
│   └── music.wav                     # dibuat otomatis oleh `npm run music`
└── src/
    ├── index.ts · Root.tsx           # Registrasi komposisi "WW2Documentary"
    ├── WW2Video.tsx                  # Komposisi utama: scene, transisi, musik, efek film
    ├── config.ts                     # Durasi scene, musik, foto  <- edit di sini
    ├── data.ts                       # Teks garis waktu, kota & rute peta <- edit di sini
    ├── geo.ts                        # Poligon peta dunia + proyeksi Mercator
    ├── theme.ts                      # Warna & font
    ├── components/                   # KineticText, Typewriter, PhotoFrame, WorldMap,
    │                                 # FilmOverlay (grain/vignette/letterbox), SceneFade, LightLeak
    └── scenes/                       # Opening, Intro, Timeline, MapScene, Closing
```

## Struktur waktu

| Scene | Detik | Isi |
|---|---|---|
| 1. Opening | 0–9,5 | Typewriter tanggal, judul kinetic, peta redup, letterbox |
| 2. Pengenalan | 9–19,5 | Sekutu vs Poros, foto arsip, counter korban jiwa |
| 3. Garis waktu | 19–34,5 | 8 peristiwa, kamera menggeser horizontal |
| 4. Peta perang | 34–52,5 | Kamera zoom Eropa → Pasifik, rute animasi |
| 5. Closing | 52–60 | Kesimpulan kinetic, fade to black |

Transisi: crossfade + push-in + blur + light leak. Musik: fade in/out otomatis.

## Menjalankan di GitHub Codespaces (dari HP Android)

1. Buka Chrome di HP → `github.com` → login → menu ⋮ → centang **Situs desktop**.
2. Buka `https://github.com/codespaces/new?template_repository=github/codespaces-blank` lalu tekan **Create codespace**. Tunggu editor VS Code terbuka di browser.
3. Unggah `ww2-remotion.zip`: di panel **Explorer** tekan lama area kosong → **Upload...** → pilih zip.
4. Buka terminal (menu ☰ → Terminal → New Terminal), lalu:
   ```bash
   unzip ww2-remotion.zip
   cd ww2-remotion
   bash setup.sh        # sekali saja, ±3-5 menit
   ```
5. Preview: `npm start` → Codespaces menampilkan notifikasi port 3000 → **Open in Browser**. Pilih komposisi `WW2Documentary`, tekan Play.
6. Render video akhir (hentikan preview dengan Ctrl+C dulu):
   ```bash
   npm run render:preview   # cepat, 960x540  -> out/preview.mp4
   npm run render           # Full HD         -> out/ww2-documentary.mp4
   ```
7. Unduh hasil: di Explorer buka folder `out`, tekan lama `ww2-documentary.mp4` → **Download**.
   Alternatif: `npm run serve:out`, buka port 8080 di tab **Ports**, lalu tap file mp4.

Tips: render Full HD di Codespaces 2-core bisa 10-25 menit; jaga layar tetap menyala. Hentikan/hapus Codespace setelah selesai untuk menghemat kuota gratis.

## Kustomisasi

- **Foto asli**: taruh .jpg domain publik di `public/photos/`, sesuaikan nama di `PHOTO_FILES`, set `USE_REAL_PHOTOS = true` di `src/config.ts`.
- **Musik sendiri**: taruh mp3/wav di `public/`, ubah `MUSIC_FILE` di `src/config.ts`.
- **Teks/peristiwa**: `src/data.ts`. **Warna/font**: `src/theme.ts`.

## Troubleshooting

| Masalah | Solusi |
|---|---|
| Error Chrome / shared library saat render | `bash setup.sh` ulang |
| Out of memory | `npx remotion render WW2Documentary out/ww2.mp4 --concurrency=1` |
| `music.wav` tidak ditemukan | `npm run music` |
| Font gagal dimuat | Pastikan Codespace online, jalankan ulang |
| Peringatan versi Remotion | `npx remotion upgrade` |
