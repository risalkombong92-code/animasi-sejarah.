import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {KineticText} from '../components/KineticText';
import {Land, cameraTransform} from '../components/WorldMap';
import {CITIES, ROUTES, SIDE_COLOR} from '../data';
import type {City, Route} from '../data';
import {HEIGHT, WIDTH} from '../config';
import {MAP_W, project} from '../geo';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Keyframe kamera: {frame, lon, lat, zoom}
const KEYS = [
  {f: 0, lon: 15, lat: 30, z: 1},
  {f: 40, lon: 18, lat: 51, z: 4.0},
  {f: 125, lon: 18, lat: 51, z: 4.0},
  {f: 160, lon: 28, lat: 51, z: 3.3},
  {f: 265, lon: 28, lat: 51, z: 3.3},
  {f: 300, lon: 6, lat: 51.5, z: 6.2},
  {f: 360, lon: 6, lat: 51.5, z: 6.2},
  {f: 400, lon: 172, lat: 28, z: 2.4},
  {f: 480, lon: 172, lat: 28, z: 2.4},
  {f: 505, lon: 138, lat: 35, z: 5.5},
  {f: 515, lon: 138, lat: 35, z: 5.5},
  {f: 555, lon: 15, lat: 30, z: 1},
];

const camera = (frame: number) => {
  let i = 0;
  while (i < KEYS.length - 2 && frame >= KEYS[i + 1].f) i++;
  const a = KEYS[i];
  const b = KEYS[i + 1];
  const t = interpolate(frame, [a.f, b.f], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  return {
    lon: a.lon + (b.lon - a.lon) * t,
    lat: a.lat + (b.lat - a.lat) * t,
    z: Math.exp(Math.log(a.z) + (Math.log(b.z) - Math.log(a.z)) * t),
  };
};

const RouteLine: React.FC<{route: Route; frame: number; S: number}> = ({route, frame, S}) => {
  if (frame < route.start) return null;
  const a = CITIES[route.from];
  const b = CITIES[route.to];
  const [x0, y0] = project(a.lon, a.lat);
  const [x2, y2] = project(b.lon, b.lat);
  const cx = (x0 + x2) / 2 - (y2 - y0) * route.bend;
  const cy = (y0 + y2) / 2 + (x2 - x0) * route.bend;
  const t = interpolate(frame, [route.start, route.end], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const color = SIDE_COLOR[route.side];
  const d = `M ${x0} ${y0} Q ${cx} ${cy} ${x2} ${y2}`;

  // posisi & arah kepala panah pada kurva bezier kuadratik
  const hx = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x2;
  const hy = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y2;
  const tx = 2 * (1 - t) * (cx - x0) + 2 * t * (x2 - cx);
  const ty = 2 * (1 - t) * (cy - y0) + 2 * t * (y2 - cy);
  const angle = (Math.atan2(ty, tx) * 180) / Math.PI;
  const done = frame > route.end;

  return (
    <g>
      <path d={d} fill="none" stroke={color} strokeWidth={16 / S} opacity={0.2} strokeLinecap="round" pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - t} />
      <path d={d} fill="none" stroke={color} strokeWidth={5 / S} opacity={done ? 0.8 : 1} strokeLinecap="round" pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - t} />
      {t > 0 && (
        <g transform={`translate(${hx} ${hy}) rotate(${angle})`}>
          <polygon points={`${-22 / S},${-12 / S} ${6 / S},0 ${-22 / S},${12 / S}`} fill={color} />
        </g>
      )}
    </g>
  );
};

const CityMarker: React.FC<{city: City; frame: number; S: number; hot?: boolean}> = ({city, frame, S, hot}) => {
  if (frame < city.showAt) return null;
  const [x, y] = project(city.lon, city.lat);
  const o = interpolate(frame, [city.showAt, city.showAt + 10], [0, 1], clamp);
  const ph = (frame % 45) / 45;
  const ring = ((hot ? 14 : 8) + ph * (hot ? 46 : 26)) / S;
  return (
    <g opacity={o}>
      <circle cx={x} cy={y} r={ring} fill="none" stroke={hot ? COLORS.red : COLORS.ink} strokeWidth={2 / S} opacity={(1 - ph) * 0.8} />
      <circle cx={x} cy={y} r={7 / S} fill={hot ? COLORS.red : COLORS.ink} />
      <text
        x={x + (city.dx ?? 14) / S}
        y={y + (city.dy ?? -12) / S}
        textAnchor={city.anchor ?? 'start'}
        fontFamily={FONT.mono}
        fontSize={28 / S}
        fill={COLORS.ink}
        stroke="#000"
        strokeWidth={6 / S}
        paintOrder="stroke"
      >
        {city.name}
      </text>
    </g>
  );
};

// Scene 4 - Peta pergerakan perang (±18,5 detik)
export const MapScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cam = camera(frame);
  const {S, transform} = cameraTransform(cam.lon, cam.lat, cam.z);

  // Garis lintang/bujur (grid)
  const grid: React.ReactNode[] = [];
  for (let lon = -180; lon <= 540; lon += 15) {
    const [x] = project(lon, 0);
    grid.push(<line key={`m${lon}`} x1={x} y1={0} x2={x} y2={3000} stroke={COLORS.ink} strokeWidth={1 / S} opacity={0.07} />);
  }
  for (let lat = -60; lat <= 80; lat += 15) {
    const [, y] = project(0, lat);
    grid.push(<line key={`p${lat}`} x1={-MAP_W} y1={y} x2={MAP_W * 2} y2={y} stroke={COLORS.ink} strokeWidth={1 / S} opacity={0.07} />);
  }

  const active = [...ROUTES].reverse().find((r) => frame >= r.start);
  const showCard = active && frame < 515;
  const cardP = active ? spring({frame: frame - active.start, fps, config: {damping: 18, stiffness: 140}}) : 0;
  const cardOut = interpolate(frame, [505, 515], [1, 0], clamp);

  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at center, #121c22 0%, ${COLORS.ocean} 80%)`}}>
      <svg width={WIDTH} height={HEIGHT}>
        <g transform={transform}>
          {grid}
          <Land strokeWidth={1.4 / S} />
          {ROUTES.map((r, i) => (
            <RouteLine key={i} route={r} frame={frame} S={S} />
          ))}
          {Object.values(CITIES).map((c) => (
            <CityMarker key={c.id} city={c} frame={frame} S={S} hot={c.id === 'hiroshima' || c.id === 'nagasaki'} />
          ))}
        </g>
      </svg>

      <KineticText
        text="PETA PERGERAKAN PERANG"
        delay={4}
        stagger={5}
        style={{position: 'absolute', left: 110, top: 90, textAlign: 'left', fontFamily: FONT.display, fontSize: 64, letterSpacing: 5, color: COLORS.ink, textShadow: '0 4px 20px #000'}}
      />

      {/* Legenda */}
      <div style={{position: 'absolute', right: 110, top: 96, fontFamily: FONT.mono, fontSize: 24, color: COLORS.ink, textShadow: '0 2px 10px #000'}}>
        {[
          ['Poros', COLORS.red],
          ['Sekutu', COLORS.blue],
          ['Uni Soviet', COLORS.soviet],
        ].map(([name, color]) => (
          <div key={name} style={{display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginBottom: 8}}>
            {name}
            <span style={{display: 'inline-block', width: 46, height: 6, background: color, marginLeft: 14}} />
          </div>
        ))}
      </div>

      {/* Kartu keterangan rute aktif */}
      {showCard && active && (
        <div
          style={{
            position: 'absolute',
            left: 110,
            bottom: 100,
            width: 760,
            padding: '16px 30px 20px',
            background: 'rgba(0,0,0,0.65)',
            borderLeft: `8px solid ${SIDE_COLOR[active.side]}`,
            opacity: cardP * cardOut,
            transform: `translateX(${(1 - cardP) * -80}px)`,
          }}
        >
          <div style={{fontFamily: FONT.display, fontSize: 110, lineHeight: 1, color: SIDE_COLOR[active.side]}}>{active.year}</div>
          <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 42, color: COLORS.ink}}>{active.label}</div>
        </div>
      )}

      {/* Penutup: kamera menjauh */}
      <KineticText
        text="Dari Warsawa hingga Hiroshima: satu perang, enam tahun."
        delay={520}
        stagger={4}
        style={{position: 'absolute', left: 0, right: 0, bottom: 110, fontFamily: FONT.serif, fontStyle: 'italic', fontSize: 48, color: COLORS.ink, textShadow: '0 3px 20px #000'}}
      />
    </AbsoluteFill>
  );
};
