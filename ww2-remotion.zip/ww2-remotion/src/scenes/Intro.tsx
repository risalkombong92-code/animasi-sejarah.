import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {KineticText} from '../components/KineticText';
import {PhotoFrame} from '../components/PhotoFrame';
import {WorldBackdrop} from '../components/WorldMap';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const SideCard: React.FC<{
  title: string;
  color: string;
  members: string;
  top: number;
  delay: number;
}> = ({title, color, members, top, delay}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: {damping: 200}});
  return (
    <div
      style={{
        position: 'absolute',
        left: 1090,
        top,
        width: 720,
        padding: '22px 30px',
        background: 'rgba(0,0,0,0.55)',
        borderLeft: `8px solid ${color}`,
        opacity: p,
        transform: `translateX(${(1 - p) * 140}px)`,
      }}
    >
      <div style={{fontFamily: FONT.display, fontSize: 70, letterSpacing: 5, color}}>{title}</div>
      <div style={{fontFamily: FONT.serif, fontSize: 32, color: COLORS.ink, marginTop: 4}}>{members}</div>
    </div>
  );
};

// Scene 2 - Pengenalan peristiwa (±10,5 detik)
export const Intro: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const lon = interpolate(frame, [0, 315], [5, 30]);
  const zoom = interpolate(frame, [0, 315], [2.6, 3.4]);

  const count = Math.round(interpolate(frame, [150, 230], [0, 70], {...clamp, easing: Easing.out(Easing.cubic)}));
  const statP = spring({frame: frame - 145, fps, config: {damping: 200}});
  const subP = spring({frame: frame - 40, fps, config: {damping: 200}});

  return (
    <AbsoluteFill style={{background: COLORS.bg}}>
      <WorldBackdrop lon={lon} lat={50} zoom={zoom} opacity={0.3} />
      <AbsoluteFill style={{background: 'linear-gradient(90deg, rgba(10,10,9,0.9) 0%, rgba(10,10,9,0.35) 100%)'}} />

      <KineticText
        text="DUNIA YANG TERBELAH"
        delay={5}
        stagger={5}
        style={{
          position: 'absolute',
          left: 110,
          top: 110,
          width: 900,
          textAlign: 'left',
          fontFamily: FONT.display,
          fontSize: 150,
          lineHeight: 0.95,
          color: COLORS.ink,
          letterSpacing: 3,
        }}
      />

      <div
        style={{
          position: 'absolute',
          left: 110,
          top: 420,
          width: 880,
          fontFamily: FONT.serif,
          fontSize: 34,
          lineHeight: 1.4,
          color: 'rgba(241,232,208,0.9)',
          opacity: subP,
          transform: `translateY(${(1 - subP) * 30}px)`,
        }}
      >
        Pada 1 September 1939, Jerman menyerbu Polandia. Dua hari kemudian Inggris dan Prancis menyatakan perang. Dalam enam tahun, konflik menyeret dunia.
      </div>

      <div style={{position: 'absolute', left: 110, top: 640}}>
        <PhotoFrame photoKey="intro1" kind="city" caption="Eropa, 1939" width={470} height={330} rotate={-3} kbDuration={315} style={{position: 'absolute', left: 0, top: 0}} />
      </div>
      <div style={{position: 'absolute', left: 510, top: 680}}>
        <PhotoFrame photoKey="intro2" kind="sky" caption="Langit Eropa, 1940" width={420} height={300} rotate={4} kbDuration={315} style={{position: 'absolute', left: 0, top: 0}} />
      </div>

      <SideCard title="SEKUTU" color={COLORS.blue} members="Inggris · Amerika Serikat · Uni Soviet · Tiongkok · Prancis" top={140} delay={55} />
      <SideCard title="POROS" color={COLORS.red} members="Jerman · Italia · Jepang" top={375} delay={85} />

      <div
        style={{
          position: 'absolute',
          left: 1090,
          top: 590,
          width: 720,
          padding: '18px 30px 22px',
          background: 'rgba(0,0,0,0.55)',
          borderLeft: `8px solid ${COLORS.gold}`,
          opacity: statP,
          transform: `translateY(${(1 - statP) * 50}px)`,
        }}
      >
        <div style={{fontFamily: FONT.mono, fontSize: 24, letterSpacing: 4, color: COLORS.gold}}>PERKIRAAN KORBAN JIWA</div>
        <div style={{fontFamily: FONT.display, fontSize: 190, lineHeight: 1, color: COLORS.ink}}>
          {count}
          {frame >= 230 ? '–85' : ''}
          <span style={{fontSize: 80, marginLeft: 16, color: COLORS.gold}}>JUTA JIWA</span>
        </div>
        <div style={{fontFamily: FONT.serif, fontSize: 26, color: 'rgba(241,232,208,0.7)'}}>Termasuk warga sipil, kelaparan, dan penyakit akibat perang</div>
      </div>
    </AbsoluteFill>
  );
};
