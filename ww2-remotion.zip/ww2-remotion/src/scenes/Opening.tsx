import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {KineticText} from '../components/KineticText';
import {Typewriter} from '../components/Typewriter';
import {WorldBackdrop} from '../components/WorldMap';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Scene 1 - Opening cinematic (±9,5 detik)
export const Opening: React.FC = () => {
  const frame = useCurrentFrame();
  const glow = 0.28 + 0.1 * Math.sin(frame / 12);
  const lineW = interpolate(frame, [150, 200], [0, 980], {...clamp, easing: Easing.out(Easing.cubic)});
  const lon = interpolate(frame, [0, 285], [-10, 40]);
  const zoom = interpolate(frame, [0, 285], [1.2, 1.9]);
  const bgOpacity = interpolate(frame, [0, 60], [0, 0.4], clamp);
  const stripOpacity = interpolate(frame, [215, 240], [0, 1], clamp);

  return (
    <AbsoluteFill style={{background: COLORS.bg}}>
      <WorldBackdrop lon={lon} lat={38} zoom={zoom} opacity={bgOpacity} />
      <AbsoluteFill
        style={{
          background: `radial-gradient(circle at 50% 48%, rgba(192,57,43,${glow}), transparent 55%)`,
        }}
      />

      <div style={{position: 'absolute', top: 300, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>
        <Typewriter
          text="1 SEPTEMBER 1939 · 04:45"
          delay={15}
          speed={0.55}
          style={{fontFamily: FONT.mono, fontSize: 40, color: COLORS.gold, letterSpacing: 8}}
        />
      </div>

      <KineticText
        text="PERANG DUNIA II"
        mode="char"
        delay={80}
        stagger={2}
        from="scale"
        style={{
          position: 'absolute',
          top: 380,
          left: 0,
          right: 0,
          fontFamily: FONT.display,
          fontSize: 260,
          lineHeight: 1,
          color: COLORS.ink,
          letterSpacing: 6,
          textShadow: '0 10px 50px rgba(0,0,0,0.8)',
        }}
      />

      <div style={{position: 'absolute', top: 690, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>
        <div style={{width: lineW, height: 4, background: COLORS.gold}} />
      </div>

      <KineticText
        text="Konflik terbesar dalam sejarah umat manusia"
        delay={165}
        stagger={4}
        style={{
          position: 'absolute',
          top: 725,
          left: 0,
          right: 0,
          fontFamily: FONT.serif,
          fontStyle: 'italic',
          fontSize: 52,
          color: COLORS.ink,
        }}
      />

      <div
        style={{
          position: 'absolute',
          top: 860,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: stripOpacity,
          fontFamily: FONT.mono,
          fontSize: 30,
          letterSpacing: 10,
          color: 'rgba(241,232,208,0.7)',
        }}
      >
        1939 — 1945 · 6 TAHUN · 30+ NEGARA
      </div>
    </AbsoluteFill>
  );
};
