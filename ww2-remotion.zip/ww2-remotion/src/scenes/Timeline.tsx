import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {KineticText} from '../components/KineticText';
import {PhotoFrame} from '../components/PhotoFrame';
import {TIMELINE} from '../data';
import {COLORS, FONT} from '../theme';

const SPACING = 780; // jarak antar peristiwa (px)
const SLOT = 52; // frame per peristiwa
const START = 20;
const HOLD = 34;
const LINE_Y = 540;

// Posisi kamera (dalam satuan indeks peristiwa): tahan di tiap peristiwa, lalu geser halus ke berikutnya
const input: number[] = [];
const output: number[] = [];
TIMELINE.forEach((_, i) => {
  input.push(START + i * SLOT, START + i * SLOT + HOLD);
  output.push(i, i);
});

// Scene 3 - Garis waktu sejarah (±15,5 detik)
export const Timeline: React.FC = () => {
  const frame = useCurrentFrame();
  const pos = interpolate(frame, input, output, {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const current = Math.min(TIMELINE.length - 1, Math.round(pos));

  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, #1a1712 0%, #0a0a09 75%)'}}>
      {/* Tahun raksasa di latar (parallax) */}
      {TIMELINE.map((ev, i) => {
        const ex = 960 + (i - pos) * SPACING;
        const d = Math.abs(ex - 960);
        const k = interpolate(d, [0, 700], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        if (ex < -900 || ex > 2800) return null;
        return (
          <div
            key={`bg-${i}`}
            style={{
              position: 'absolute',
              top: 250,
              left: 960 + (ex - 960) * 0.45 - 700,
              width: 1400,
              textAlign: 'center',
              fontFamily: FONT.display,
              fontSize: 480,
              color: COLORS.ink,
              opacity: 0.05 * k,
            }}
          >
            {ev.year}
          </div>
        );
      })}

      {/* Garis waktu */}
      <div style={{position: 'absolute', left: 0, width: 960, top: LINE_Y - 2, height: 4, background: COLORS.gold}} />
      <div style={{position: 'absolute', left: 960, right: 0, top: LINE_Y - 2, height: 4, background: 'rgba(241,232,208,0.22)'}} />
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: LINE_Y + 14,
          height: 14,
          backgroundImage: 'repeating-linear-gradient(90deg, rgba(241,232,208,0.28) 0 2px, transparent 2px 39px)',
          backgroundPosition: `${-pos * SPACING}px 0`,
        }}
      />

      {/* Peristiwa */}
      {TIMELINE.map((ev, i) => {
        const ex = 960 + (i - pos) * SPACING;
        if (ex < -500 || ex > 2400) return null;
        const d = Math.abs(ex - 960);
        const k = interpolate(d, [0, 560], [1, 0.25], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        const above = i % 2 === 0; // genap: teks di atas, foto di bawah
        const active = d < 60;

        const textBox: React.CSSProperties = {
          position: 'absolute',
          left: ex - 300,
          width: 600,
          textAlign: 'center',
          opacity: k,
          transform: `scale(${0.9 + 0.1 * k})`,
          ...(above ? {bottom: 1080 - 495, transformOrigin: '50% 100%'} : {top: 595, transformOrigin: '50% 0%'}),
        };
        const photoBox: React.CSSProperties = {
          position: 'absolute',
          left: ex - 210,
          opacity: k,
          transform: `scale(${0.92 + 0.08 * k})`,
          ...(above ? {bottom: 1080 - 495} : {top: 595}),
        };

        return (
          <React.Fragment key={i}>
            <div style={textBox}>
              <div style={{fontFamily: FONT.mono, fontSize: 26, letterSpacing: 4, color: COLORS.gold}}>{ev.date}</div>
              <div style={{fontFamily: FONT.display, fontSize: 150, lineHeight: 1, color: COLORS.ink}}>{ev.year}</div>
              <div style={{fontFamily: FONT.serif, fontWeight: 700, fontSize: 46, color: COLORS.ink, marginBottom: 8}}>{ev.title}</div>
              <div style={{fontFamily: FONT.serif, fontSize: 29, lineHeight: 1.35, color: 'rgba(241,232,208,0.78)'}}>{ev.desc}</div>
            </div>
            <div style={photoBox}>
              <PhotoFrame
                photoKey={ev.photoKey}
                kind={ev.kind}
                caption={ev.caption}
                width={420}
                height={290}
                rotate={above ? 2 : -2}
                kbDuration={465}
                style={{position: 'relative'}}
              />
            </div>
            {/* Titik pada garis */}
            <div
              style={{
                position: 'absolute',
                left: ex - 16,
                top: LINE_Y - 16,
                width: 32,
                height: 32,
                borderRadius: 16,
                background: active ? COLORS.gold : COLORS.bg,
                border: `4px solid ${COLORS.gold}`,
                boxShadow: active ? `0 0 ${24 + 10 * Math.sin(frame / 5)}px ${COLORS.gold}` : 'none',
                opacity: Math.max(0.35, k),
              }}
            />
          </React.Fragment>
        );
      })}

      {/* Judul & penghitung */}
      <KineticText
        text="GARIS WAKTU · 1939–1945"
        mode="char"
        delay={0}
        stagger={1.2}
        style={{
          position: 'absolute',
          left: 110,
          top: 84,
          textAlign: 'left',
          fontFamily: FONT.display,
          fontSize: 52,
          letterSpacing: 6,
          color: COLORS.gold,
        }}
      />
      <div style={{position: 'absolute', right: 110, bottom: 92, fontFamily: FONT.mono, fontSize: 30, letterSpacing: 4, color: 'rgba(241,232,208,0.7)'}}>
        {String(current + 1).padStart(2, '0')} / {String(TIMELINE.length).padStart(2, '0')}
      </div>
    </AbsoluteFill>
  );
};
