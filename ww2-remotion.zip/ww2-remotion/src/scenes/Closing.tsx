import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {KineticText} from '../components/KineticText';
import {WorldBackdrop} from '../components/WorldMap';
import {COLORS, FONT} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Scene 5 - Closing & kesimpulan (±8 detik)
export const Closing: React.FC = () => {
  const frame = useCurrentFrame();
  const lon = interpolate(frame, [0, 240], [20, 60]);
  const zoom = interpolate(frame, [0, 240], [1.0, 1.35]);
  const tagO = interpolate(frame, [175, 200], [0, 1], clamp);

  return (
    <AbsoluteFill style={{background: COLORS.bg}}>
      <WorldBackdrop lon={lon} lat={30} zoom={zoom} opacity={0.22} />
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, rgba(212,169,55,0.12), transparent 60%)'}} />

      <KineticText
        text="KESIMPULAN"
        mode="char"
        delay={8}
        stagger={2}
        style={{position: 'absolute', top: 180, left: 0, right: 0, fontFamily: FONT.mono, fontSize: 34, letterSpacing: 14, color: COLORS.gold}}
      />

      <KineticText
        text="Lebih dari 70 juta jiwa."
        delay={25}
        stagger={5}
        style={{position: 'absolute', top: 270, left: 0, right: 0, fontFamily: FONT.display, fontSize: 150, letterSpacing: 3, color: COLORS.ink}}
      />

      <KineticText
        text="Perang ini mengubah peta dunia, melahirkan PBB, dan meninggalkan satu pelajaran:"
        delay={80}
        stagger={3}
        style={{position: 'absolute', top: 480, left: 260, right: 260, fontFamily: FONT.serif, fontSize: 46, lineHeight: 1.35, color: 'rgba(241,232,208,0.9)'}}
      />

      <KineticText
        text="PERDAMAIAN HARUS DIJAGA"
        delay={135}
        stagger={4}
        from="scale"
        style={{position: 'absolute', top: 700, left: 0, right: 0, fontFamily: FONT.display, fontSize: 130, letterSpacing: 4, color: COLORS.gold, textShadow: '0 6px 40px rgba(0,0,0,0.8)'}}
      />

      <div style={{position: 'absolute', bottom: 105, left: 0, right: 0, textAlign: 'center', opacity: tagO, fontFamily: FONT.mono, fontSize: 26, letterSpacing: 6, color: 'rgba(241,232,208,0.6)'}}>
        1939 — 1945 · LEST WE FORGET
      </div>
    </AbsoluteFill>
  );
};
