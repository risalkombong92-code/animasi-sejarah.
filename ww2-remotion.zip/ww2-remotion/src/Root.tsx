import React from 'react';
import {Composition} from 'remotion';
import {WW2Video} from './WW2Video';
import {DURATION, FPS, HEIGHT, WIDTH} from './config';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WW2Documentary"
      component={WW2Video}
      durationInFrames={DURATION}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
