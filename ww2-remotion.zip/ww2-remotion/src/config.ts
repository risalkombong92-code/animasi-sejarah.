// ====== Spesifikasi video ======
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const DURATION = 1800; // 60 detik x 30 fps

// ====== Susunan scene (dalam frame). Tiap scene tumpang-tindih 15 frame (crossfade) ======
export const SCENES = {
  opening: {from: 0, dur: 285}, //   0.0s -  9.5s  Opening cinematic
  intro: {from: 270, dur: 315}, //   9.0s - 19.5s  Pengenalan peristiwa
  timeline: {from: 570, dur: 465}, // 19.0s - 34.5s  Garis waktu
  map: {from: 1020, dur: 555}, //   34.0s - 52.5s  Peta pergerakan perang
  closing: {from: 1560, dur: 240}, // 52.0s - 60.0s  Closing & kesimpulan
} as const;

// Titik pertemuan antar scene (untuk efek light leak)
export const TRANSITION_POINTS = [277, 577, 1027, 1567];

// ====== Musik ======
// File dibuat otomatis oleh `npm run music`. Ganti dengan file sendiri jika mau (mp3/wav di folder public/).
export const USE_MUSIC = true;
export const MUSIC_FILE = 'music.wav';

// ====== Foto sejarah ======
// false = pakai ilustrasi arsip placeholder (video langsung bisa dirender).
// true  = pakai foto asli dari public/photos/ (isi dulu file-nya, lihat PHOTO_FILES).
export const USE_REAL_PHOTOS = false;
export const PHOTO_FILES: Record<string, string> = {
  intro1: 'photos/intro1.jpg',
  intro2: 'photos/intro2.jpg',
  poland: 'photos/poland.jpg',
  paris: 'photos/paris.jpg',
  barbarossa: 'photos/barbarossa.jpg',
  pearl: 'photos/pearl.jpg',
  stalingrad: 'photos/stalingrad.jpg',
  dday: 'photos/dday.jpg',
  victory: 'photos/victory.jpg',
  surrender: 'photos/surrender.jpg',
};
