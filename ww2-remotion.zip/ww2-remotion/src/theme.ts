import {loadFont as loadBebas} from '@remotion/google-fonts/BebasNeue';
import {loadFont as loadPlayfair} from '@remotion/google-fonts/PlayfairDisplay';
import {loadFont as loadElite} from '@remotion/google-fonts/SpecialElite';

const bebas = loadBebas();
const playfair = loadPlayfair('normal', {weights: ['400', '700']});
const elite = loadElite();

export const FONT = {
  display: `${bebas.fontFamily}, Impact, sans-serif`,
  serif: `${playfair.fontFamily}, Georgia, serif`,
  mono: `${elite.fontFamily}, "Courier New", monospace`,
};

export const COLORS = {
  bg: '#0a0a09',
  ocean: '#0c1317',
  ink: '#f1e8d0',
  paper: '#e6dcc3',
  gold: '#d4a937',
  red: '#c0392b',
  blue: '#4a90c8',
  soviet: '#e07b2a',
  land: '#3a3326',
  landStroke: '#8c7b57',
};
