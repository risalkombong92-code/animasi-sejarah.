import type {PhotoKind} from './components/PhotoFrame';

// ================= GARIS WAKTU =================
export type TimelineEvent = {
  year: string;
  date: string;
  title: string;
  desc: string;
  photoKey: string;
  kind: PhotoKind;
  caption: string;
};

export const TIMELINE: TimelineEvent[] = [
  {year: '1939', date: '1 SEPTEMBER 1939', title: 'Jerman Menyerbu Polandia', desc: 'Blitzkrieg dimulai. Inggris dan Prancis menyatakan perang pada 3 September.', photoKey: 'poland', kind: 'field', caption: 'Polandia, 1939'},
  {year: '1940', date: 'JUNI 1940', title: 'Prancis Jatuh', desc: 'Paris diduduki 14 Juni. Inggris bertahan sendirian dalam Pertempuran Britania.', photoKey: 'paris', kind: 'city', caption: 'Paris, 1940'},
  {year: '1941', date: '22 JUNI 1941', title: 'Operasi Barbarossa', desc: 'Jerman menyerbu Uni Soviet. Front timur menjadi medan perang terbesar dalam sejarah.', photoKey: 'barbarossa', kind: 'field', caption: 'Front Timur, 1941'},
  {year: '1941', date: '7 DESEMBER 1941', title: 'Pearl Harbor', desc: 'Serangan Jepang di Hawaii menyeret Amerika Serikat ke dalam perang.', photoKey: 'pearl', kind: 'sea', caption: 'Hawaii, 1941'},
  {year: '1942–43', date: 'FEBRUARI 1943', title: 'Titik Balik Stalingrad', desc: 'Pasukan Jerman menyerah. Uni Soviet mulai merebut inisiatif perang.', photoKey: 'stalingrad', kind: 'city', caption: 'Stalingrad, 1943'},
  {year: '1944', date: '6 JUNI 1944', title: 'D-Day: Normandia', desc: 'Sekutu mendarat di pantai Prancis dan membuka front barat.', photoKey: 'dday', kind: 'sea', caption: 'Normandia, 1944'},
  {year: '1945', date: '8 MEI 1945', title: 'Eropa Bebas dari Perang', desc: 'Jerman menyerah tanpa syarat. Eropa merayakan V-E Day.', photoKey: 'victory', kind: 'sky', caption: 'V-E Day, 1945'},
  {year: '1945', date: '2 SEPTEMBER 1945', title: 'Perang Berakhir', desc: 'Setelah bom atom di Hiroshima dan Nagasaki, Jepang menandatangani penyerahan diri.', photoKey: 'surrender', kind: 'sea', caption: 'Teluk Tokyo, 1945'},
];

// ================= PETA =================
export type City = {
  id: string;
  name: string;
  lon: number;
  lat: number;
  showAt: number; // frame (relatif ke scene peta) kota mulai tampil
  anchor?: 'start' | 'end';
  dx?: number;
  dy?: number;
};

export const CITIES: Record<string, City> = {
  berlin: {id: 'berlin', name: 'Berlin', lon: 13.4, lat: 52.52, showAt: 45, anchor: 'end', dx: -14, dy: -14},
  warsaw: {id: 'warsaw', name: 'Warsawa', lon: 21.0, lat: 52.23, showAt: 55, dx: 14, dy: -12},
  paris: {id: 'paris', name: 'Paris', lon: 2.35, lat: 48.86, showAt: 85, anchor: 'end', dx: -14, dy: 6},
  moscow: {id: 'moscow', name: 'Moskow', lon: 37.62, lat: 55.75, showAt: 130, dx: 14, dy: -12},
  kyiv: {id: 'kyiv', name: 'Kyiv', lon: 30.5, lat: 50.45, showAt: 180, anchor: 'end', dx: -14, dy: 10},
  stalingrad: {id: 'stalingrad', name: 'Stalingrad', lon: 44.5, lat: 48.71, showAt: 180, dx: 14, dy: 10},
  london: {id: 'london', name: 'London', lon: -0.12, lat: 51.5, showAt: 295, anchor: 'end', dx: -14, dy: -14},
  normandy: {id: 'normandy', name: 'Normandia', lon: -0.87, lat: 49.37, showAt: 295, anchor: 'end', dx: -14, dy: 14},
  tokyo: {id: 'tokyo', name: 'Tokyo', lon: 139.7, lat: 35.7, showAt: 400, anchor: 'end', dx: -14, dy: -12},
  pearl: {id: 'pearl', name: 'Pearl Harbor', lon: 202.03, lat: 21.35, showAt: 400, dx: 14, dy: 22},
  hiroshima: {id: 'hiroshima', name: 'Hiroshima', lon: 132.45, lat: 34.39, showAt: 480, anchor: 'end', dx: -14, dy: -14},
  nagasaki: {id: 'nagasaki', name: 'Nagasaki', lon: 129.87, lat: 32.75, showAt: 492, anchor: 'end', dx: -14, dy: 14},
};

export type Side = 'axis' | 'allies' | 'soviet';
export const SIDE_COLOR: Record<Side, string> = {
  axis: '#c0392b',
  allies: '#4a90c8',
  soviet: '#e07b2a',
};

export type Route = {
  from: string;
  to: string;
  side: Side;
  start: number;
  end: number;
  year: string;
  label: string;
  bend: number; // kelengkungan garis
};

export const ROUTES: Route[] = [
  {from: 'berlin', to: 'warsaw', side: 'axis', start: 60, end: 85, year: '1939', label: 'Invasi Polandia', bend: 0.12},
  {from: 'berlin', to: 'paris', side: 'axis', start: 92, end: 125, year: '1940', label: 'Jatuhnya Prancis', bend: -0.14},
  {from: 'warsaw', to: 'moscow', side: 'axis', start: 135, end: 180, year: '1941', label: 'Operasi Barbarossa', bend: 0.1},
  {from: 'kyiv', to: 'stalingrad', side: 'axis', start: 186, end: 215, year: '1942', label: 'Menuju Stalingrad', bend: 0.12},
  {from: 'stalingrad', to: 'berlin', side: 'soviet', start: 220, end: 268, year: '1943–45', label: 'Serangan Balik Soviet', bend: -0.12},
  {from: 'london', to: 'normandy', side: 'allies', start: 302, end: 318, year: '1944', label: 'D-Day: Pendaratan Normandia', bend: 0.2},
  {from: 'normandy', to: 'berlin', side: 'allies', start: 322, end: 362, year: '1944–45', label: 'Pembebasan Eropa Barat', bend: 0.1},
  {from: 'tokyo', to: 'pearl', side: 'axis', start: 405, end: 440, year: '1941', label: 'Serangan Pearl Harbor', bend: -0.12},
  {from: 'pearl', to: 'tokyo', side: 'allies', start: 446, end: 482, year: '1942–45', label: 'Serangan Balik di Pasifik', bend: 0.12},
];
