import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';

/** Kilatan cahaya hangat ala film - dipasang di titik pergantian scene. */
export const LightLeak: React.FC<{duration?: number}> = ({duration = 40}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, duration / 2, duration], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const x = interpolate(frame, [0, duration], [-20, 120]);
  return (
    <AbsoluteFill
      style={{
        opacity: p * 0.85,
        mixBlendMode: 'screen',
        pointerEvents: 'none',
        background: `radial-gradient(circle at ${x}% 40%, rgba(255,170,60,0.9), rgba(200,60,20,0.35) 35%, transparent 65%)`,
      }}
    />
  );
};
