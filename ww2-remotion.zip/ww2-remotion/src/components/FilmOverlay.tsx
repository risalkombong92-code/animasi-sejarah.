import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame, Easing} from 'remotion';

/** Efek film dokumenter lama: grain, goresan, flicker, vignette. */
export const FilmOverlay: React.FC = () => {
  const frame = useCurrentFrame();
  const seed = Math.floor(frame / 2) % 10;
  const step = Math.floor(frame / 3);

  const scratches = [0, 1, 2, 3].map((i) => ({
    x: random(`sx-${step}-${i}`) * 100,
    on: random(`so-${step}-${i}`) > 0.72,
  }));
  const flicker = random(`fl-${frame}`) * 0.07;

  return (
    <>
      <AbsoluteFill style={{background: `rgba(0,0,0,${flicker})`, pointerEvents: 'none'}} />
      <AbsoluteFill style={{mixBlendMode: 'overlay', opacity: 0.16, pointerEvents: 'none'}}>
        <svg width="100%" height="100%" viewBox="0 0 480 270" preserveAspectRatio="none" style={{width: '100%', height: '100%'}}>
          <filter id="grain">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={seed} stitchTiles="stitch" />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <rect width="480" height="270" filter="url(#grain)" />
        </svg>
      </AbsoluteFill>
      <AbsoluteFill style={{pointerEvents: 'none'}}>
        {scratches.map((s, i) =>
          s.on ? (
            <div key={i} style={{position: 'absolute', left: `${s.x}%`, top: 0, bottom: 0, width: 2, background: 'rgba(255,255,255,0.18)'}} />
          ) : null,
        )}
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 52%, rgba(0,0,0,0.78) 100%)',
        }}
      />
    </>
  );
};

/** Letterbox sinematik: bar hitam menutup dari tengah lalu membuka ke 64px. */
export const Letterbox: React.FC = () => {
  const frame = useCurrentFrame();
  const h = interpolate(frame, [0, 55], [540, 64], {
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  return (
    <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: h, background: '#000'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: h, background: '#000'}} />
    </>
  );
};
