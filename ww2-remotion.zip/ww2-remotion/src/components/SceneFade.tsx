import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';

/** Transisi sinematik: fade-in + push-in halus + sedikit blur saat scene masuk. */
export const SceneFade: React.FC<React.PropsWithChildren<{fadeIn?: number}>> = ({fadeIn = 15, children}) => {
  const frame = useCurrentFrame();
  const d = Math.max(1, fadeIn);
  const opacity = interpolate(frame, [0, d], [0, 1], {extrapolateRight: 'clamp'});
  const scale = interpolate(frame, [0, d * 2.5], [1.07, 1], {
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const blur = interpolate(frame, [0, d], [8, 0], {extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{opacity, transform: `scale(${scale})`, filter: `blur(${blur}px)`}}>{children}</AbsoluteFill>
  );
};
