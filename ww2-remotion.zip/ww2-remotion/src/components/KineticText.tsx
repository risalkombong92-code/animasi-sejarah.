import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

type Props = {
  text: string;
  delay?: number; // frame mulai
  stagger?: number; // jeda antar kata/huruf (frame)
  mode?: 'word' | 'char';
  from?: 'up' | 'down' | 'scale';
  style?: React.CSSProperties;
};

/**
 * Kinetic typography: tiap kata/huruf muncul bergantian dengan spring + blur + slide.
 */
export const KineticText: React.FC<Props> = ({text, delay = 0, stagger = 3, mode = 'word', from = 'up', style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = text.split(' ');
  let index = 0;

  return (
    <div style={{textAlign: 'center', ...style}}>
      {words.map((word, wi) => {
        const parts = mode === 'char' ? Array.from(word) : [word];
        return (
          <span key={wi} style={{display: 'inline-block', whiteSpace: 'nowrap', marginRight: '0.26em'}}>
            {parts.map((part, pi) => {
              const i = index++;
              const p = spring({
                frame: frame - delay - i * stagger,
                fps,
                config: {damping: 20, stiffness: 120, mass: 0.9},
              });
              const y = from === 'up' ? (1 - p) * 70 : from === 'down' ? -(1 - p) * 70 : 0;
              const sc = from === 'scale' ? 1.6 - 0.6 * p : 1;
              return (
                <span
                  key={pi}
                  style={{
                    display: 'inline-block',
                    opacity: interpolate(p, [0, 0.6], [0, 1], {extrapolateRight: 'clamp'}),
                    transform: `translateY(${y}px) scale(${sc})`,
                    filter: `blur(${(1 - p) * 10}px)`,
                  }}
                >
                  {part}
                </span>
              );
            })}
          </span>
        );
      })}
    </div>
  );
};
