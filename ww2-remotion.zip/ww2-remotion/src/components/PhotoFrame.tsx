import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {PHOTO_FILES, USE_REAL_PHOTOS} from '../config';
import {FONT} from '../theme';

export type PhotoKind = 'city' | 'sea' | 'field' | 'sky';

// Ilustrasi arsip placeholder (siluet) - dipakai bila USE_REAL_PHOTOS = false
const Silhouette: React.FC<{kind: PhotoKind}> = ({kind}) => {
  const c = '#17110c';
  switch (kind) {
    case 'city':
      return (
        <g>
          <ellipse cx="120" cy="120" rx="60" ry="26" fill="#3a2d20" opacity="0.5" />
          <ellipse cx="290" cy="100" rx="70" ry="30" fill="#3a2d20" opacity="0.4" />
          <polygon fill={c} points="0,260 0,170 30,170 30,140 55,140 55,175 80,160 80,120 110,120 110,180 140,180 140,150 170,150 170,190 200,170 200,130 235,130 235,185 270,185 270,145 300,145 300,200 330,175 330,155 360,155 360,190 400,190 400,260" />
        </g>
      );
    case 'sea':
      return (
        <g>
          <rect x="0" y="175" width="400" height="85" fill="#2a2016" />
          <polygon fill={c} points="60,176 340,176 322,198 92,198" />
          <rect x="130" y="150" width="120" height="26" fill={c} />
          <rect x="165" y="128" width="40" height="22" fill={c} />
          <rect x="175" y="100" width="8" height="30" fill={c} />
          <rect x="210" y="118" width="14" height="32" fill={c} />
          <rect x="285" y="138" width="40" height="6" fill={c} />
          <rect x="85" y="140" width="40" height="6" fill={c} />
        </g>
      );
    case 'field':
      return (
        <g>
          <ellipse cx="90" cy="110" rx="70" ry="22" fill="#3a2d20" opacity="0.45" />
          <rect x="0" y="195" width="400" height="65" fill="#2a2016" />
          <rect x="110" y="168" width="170" height="28" rx="6" fill={c} />
          <rect x="160" y="146" width="70" height="24" rx="5" fill={c} />
          <rect x="228" y="154" width="100" height="6" fill={c} />
          <ellipse cx="195" cy="198" rx="95" ry="10" fill={c} />
          <polygon fill={c} points="0,195 40,175 70,190 100,170 140,195" />
        </g>
      );
    case 'sky':
    default:
      return (
        <g>
          <rect x="0" y="205" width="400" height="55" fill="#2a2016" />
          {[
            [70, 70, -8, 1],
            [190, 110, -5, 0.8],
            [290, 60, -10, 0.65],
          ].map(([x, y, r, s], i) => (
            <g key={i} transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
              <polygon fill={c} points="0,0 70,8 0,16" />
              <polygon fill={c} points="28,-26 44,8 28,42" />
              <polygon fill={c} points="0,-6 12,8 0,22" />
            </g>
          ))}
        </g>
      );
  }
};

type Props = {
  photoKey: string;
  kind: PhotoKind;
  caption: string;
  width: number;
  height: number;
  rotate?: number;
  kbDuration?: number; // durasi Ken Burns (frame)
  style?: React.CSSProperties;
};

/** Foto arsip bergaya print vintage + efek kamera Ken Burns. */
export const PhotoFrame: React.FC<Props> = ({photoKey, kind, caption, width, height, rotate = 0, kbDuration = 300, style}) => {
  const frame = useCurrentFrame();
  const scale = interpolate(frame, [0, kbDuration], [1.0, 1.14], {extrapolateRight: 'clamp'});
  const file = USE_REAL_PHOTOS ? PHOTO_FILES[photoKey] : undefined;

  return (
    <div
      style={{
        position: 'relative',
        width,
        height,
        boxSizing: 'border-box',
        padding: '14px 14px 52px 14px',
        background: '#e6dcc3',
        boxShadow: '0 24px 60px rgba(0,0,0,0.65)',
        transform: `rotate(${rotate}deg)`,
        ...style,
      }}
    >
      <div style={{position: 'relative', width: '100%', height: '100%', overflow: 'hidden', background: '#000'}}>
        <div style={{width: '100%', height: '100%', transform: `scale(${scale})`}}>
          {file ? (
            <Img
              src={staticFile(file)}
              style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'sepia(0.55) contrast(1.15) brightness(0.9) grayscale(0.35)'}}
            />
          ) : (
            <svg width="100%" height="100%" viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice">
              <defs>
                <linearGradient id="archive-sky" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d9c59c" />
                  <stop offset="100%" stopColor="#8a6f4a" />
                </linearGradient>
              </defs>
              <rect width="400" height="260" fill="url(#archive-sky)" />
              <circle cx="310" cy="85" r="36" fill="#f3e5bf" opacity="0.7" />
              <Silhouette kind={kind} />
            </svg>
          )}
        </div>
        <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.55) 100%)'}} />
        {!file && (
          <div style={{position: 'absolute', left: 10, top: 8, fontFamily: FONT.mono, fontSize: 13, color: 'rgba(0,0,0,0.55)', letterSpacing: 2}}>
            FOTO ARSIP · PLACEHOLDER
          </div>
        )}
      </div>
      <div
        style={{
          position: 'absolute',
          left: 14,
          right: 14,
          bottom: 12,
          textAlign: 'center',
          fontFamily: FONT.mono,
          fontSize: 22,
          color: '#2b2218',
          letterSpacing: 1,
        }}
      >
        {caption}
      </div>
    </div>
  );
};
