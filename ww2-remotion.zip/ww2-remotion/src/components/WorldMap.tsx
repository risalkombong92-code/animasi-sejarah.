import React from 'react';
import {AbsoluteFill} from 'remotion';
import {HEIGHT, WIDTH} from '../config';
import {LAND_PATHS, MAP_W, WATER_PATHS, project} from '../geo';
import {COLORS} from '../theme';

export const BASE_SCALE = 0.64; // zoom=1 -> seluruh lebar dunia muat di layar

export const cameraTransform = (lon: number, lat: number, zoom: number) => {
  const S = BASE_SCALE * zoom;
  const [px, py] = project(lon, lat);
  return {S, transform: `translate(${WIDTH / 2} ${HEIGHT / 2}) scale(${S}) translate(${-px} ${-py})`};
};

// Daratan digambar 2x (offset MAP_W) agar Pasifik bisa "membungkus" melewati garis tanggal
export const Land: React.FC<{fill?: string; stroke?: string; strokeWidth?: number; water?: string}> = ({
  fill = COLORS.land,
  stroke = COLORS.landStroke,
  strokeWidth = 1.2,
  water = COLORS.ocean,
}) => (
  <>
    {[0, MAP_W].map((off) => (
      <g key={off} transform={`translate(${off} 0)`}>
        {LAND_PATHS.map((d, i) => (
          <path key={i} d={d} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" />
        ))}
        {WATER_PATHS.map((d, i) => (
          <path key={`w${i}`} d={d} fill={water} stroke={stroke} strokeWidth={strokeWidth * 0.6} />
        ))}
      </g>
    ))}
  </>
);

// Latar peta redup untuk scene Opening / Intro / Closing
export const WorldBackdrop: React.FC<{lon: number; lat: number; zoom: number; opacity?: number}> = ({
  lon,
  lat,
  zoom,
  opacity = 0.35,
}) => {
  const {S, transform} = cameraTransform(lon, lat, zoom);
  return (
    <AbsoluteFill style={{opacity}}>
      <svg width={WIDTH} height={HEIGHT}>
        <g transform={transform}>
          <Land fill="#2b251b" stroke="#6f6246" strokeWidth={1.4 / S} water={COLORS.bg} />
        </g>
      </svg>
    </AbsoluteFill>
  );
};
