import React from 'react';
import {useCurrentFrame} from 'remotion';

export const Typewriter: React.FC<{
  text: string;
  delay?: number;
  speed?: number; // karakter per frame
  style?: React.CSSProperties;
}> = ({text, delay = 0, speed = 0.6, style}) => {
  const frame = useCurrentFrame();
  const count = Math.max(0, Math.min(text.length, Math.floor((frame - delay) * speed)));
  const typing = count < text.length;
  const cursor = typing || Math.floor(frame / 8) % 2 === 0;
  return (
    <div style={{whiteSpace: 'pre', ...style}}>
      {text.slice(0, count)}
      <span style={{opacity: cursor && frame >= delay ? 1 : 0}}>▌</span>
    </div>
  );
};
