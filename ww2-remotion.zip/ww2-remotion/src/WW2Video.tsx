import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {DURATION, MUSIC_FILE, SCENES, TRANSITION_POINTS, USE_MUSIC} from './config';
import {FilmOverlay, Letterbox} from './components/FilmOverlay';
import {LightLeak} from './components/LightLeak';
import {SceneFade} from './components/SceneFade';
import {Opening} from './scenes/Opening';
import {Intro} from './scenes/Intro';
import {Timeline} from './scenes/Timeline';
import {MapScene} from './scenes/MapScene';
import {Closing} from './scenes/Closing';

// Efek kamera "handheld" halus untuk seluruh video
const Handheld: React.FC<React.PropsWithChildren> = ({children}) => {
  const f = useCurrentFrame();
  const x = Math.sin(f / 47) * 4 + Math.sin(f / 19) * 1.5;
  const y = Math.cos(f / 53) * 3;
  const r = Math.sin(f / 71) * 0.12;
  return <AbsoluteFill style={{transform: `translate(${x}px, ${y}px) rotate(${r}deg) scale(1.02)`}}>{children}</AbsoluteFill>;
};

export const WW2Video: React.FC = () => {
  const frame = useCurrentFrame();
  const fadeToBlack = interpolate(frame, [DURATION - 30, DURATION], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {USE_MUSIC && (
        <Audio
          src={staticFile(MUSIC_FILE)}
          volume={(f) => interpolate(f, [0, 45, DURATION - 60, DURATION], [0, 0.85, 0.85, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
        />
      )}

      <Handheld>
        <Sequence from={SCENES.opening.from} durationInFrames={SCENES.opening.dur}>
          <SceneFade fadeIn={1}>
            <Opening />
          </SceneFade>
        </Sequence>
        <Sequence from={SCENES.intro.from} durationInFrames={SCENES.intro.dur}>
          <SceneFade>
            <Intro />
          </SceneFade>
        </Sequence>
        <Sequence from={SCENES.timeline.from} durationInFrames={SCENES.timeline.dur}>
          <SceneFade>
            <Timeline />
          </SceneFade>
        </Sequence>
        <Sequence from={SCENES.map.from} durationInFrames={SCENES.map.dur}>
          <SceneFade>
            <MapScene />
          </SceneFade>
        </Sequence>
        <Sequence from={SCENES.closing.from} durationInFrames={SCENES.closing.dur}>
          <SceneFade>
            <Closing />
          </SceneFade>
        </Sequence>
      </Handheld>

      {TRANSITION_POINTS.map((p) => (
        <Sequence key={p} from={p - 20} durationInFrames={40}>
          <LightLeak duration={40} />
        </Sequence>
      ))}

      <FilmOverlay />
      <Letterbox />
      <AbsoluteFill style={{background: '#000', opacity: fadeToBlack, pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
