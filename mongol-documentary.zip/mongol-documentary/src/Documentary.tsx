import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {FPS, SCENES} from './data/scenes';
import {NAMEPLATES, RIBBONS} from './data/events';
import {GlobalFrame} from './lib/frameContext';
import {toFrame} from './lib/timing';
import {MapScene, SEA} from './components/MapScene';
import {ChapterChip, DateStamp, EndCard, Legend, Nameplate, Ribbon, TitleCard, Vignette} from './components/Hud';
import {Subtitles} from './components/Subtitles';
import {AudioTracks} from './components/AudioTracks';

/**
 * Satu peta yang kontinu menjadi "benang merah" seluruh dokumenter: kamera, tahap wilayah,
 * rute, dan penanda semuanya dihitung dari satu frame global dan dijangkarkan ke narasi.
 * <Sequence> hanya dipakai untuk melabeli timeline di Studio dan membatasi pemasangan elemen.
 */
export const Documentary: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <GlobalFrame.Provider value={frame}>
      <AbsoluteFill style={{backgroundColor: SEA}}>
        <MapScene />
        <Vignette />

        {SCENES.map((s, i) => {
          const from = Math.round(SCENES.slice(0, i).reduce((a, x) => a + x.durationSec, 0) * FPS);
          return (
            <Sequence key={s.id} from={from} durationInFrames={Math.round(s.durationSec * FPS)} name={`${s.no}. ${s.title}`} layout="none">
              <ChapterChip scene={s} />
            </Sequence>
          );
        })}

        {RIBBONS.map((r) => (
          <Sequence key={r.id} from={toFrame(r.at) - 2} durationInFrames={toFrame(r.dur) + 8} name={`Pita ${r.date}`} layout="none">
            <Ribbon r={r} />
          </Sequence>
        ))}
        {NAMEPLATES.map((n) => (
          <Sequence key={n.id} from={toFrame(n.at) - 2} durationInFrames={toFrame(n.to - n.at) + 8} name={`Tokoh: ${n.name}`} layout="none">
            <Nameplate n={n} />
          </Sequence>
        ))}

        <DateStamp />
        <Legend />
        <TitleCard />
        <Subtitles />
        <EndCard />
        <AudioTracks />
      </AbsoluteFill>
    </GlobalFrame.Provider>
  );
};
