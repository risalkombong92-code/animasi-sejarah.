import type {LonLat} from '../data/types';

/**
 * Proyeksi equirectangular dengan paralel standar 45°LU (sumbu-x dikali cos 45°)
 * agar bentuk Eurasia tidak terlalu melebar. Skematis, bukan peta presisi.
 */
export const LON0 = -10;
export const LAT_TOP = 75;
export const KPX = 30; // piksel dunia per derajat lintang
export const COS_STD = Math.cos((45 * Math.PI) / 180);

export const project = ([lon, lat]: LonLat): [number, number] => [
  (lon - LON0) * KPX * COS_STD,
  (LAT_TOP - lat) * KPX,
];

export const toPath = (pts: LonLat[], close = true): string =>
  pts
    .map((p, i) => {
      const [x, y] = project(p);
      return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ') + (close ? ' Z' : '');

export const WORLD = {minX: -1500, minY: -1500, maxX: 5400, maxY: 3800};
