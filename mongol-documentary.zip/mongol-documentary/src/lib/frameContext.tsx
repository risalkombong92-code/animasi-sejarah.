import {createContext, useContext} from 'react';

/** Frame GLOBAL video. Dipakai agar komponen di dalam <Sequence> tetap memakai waktu absolut. */
export const GlobalFrame = createContext<number>(0);
export const useGlobalFrame = (): number => useContext(GlobalFrame);
