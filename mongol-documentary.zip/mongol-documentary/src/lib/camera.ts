import {FPS, SCENES} from '../data/scenes';
import {easeInOut} from './anim';

/** Perpindahan dari adegan ke adegan berikutnya berlangsung selama 1,5 detik pertama adegan baru. */
export const TRAVEL_FRAMES = 45;

type KF = {f: number; lon: number; lat: number; zoom: number};

const KEYFRAMES: KF[] = (() => {
  const out: KF[] = [];
  let start = 0;
  SCENES.forEach((s, i) => {
    const dur = s.durationSec * FPS;
    s.camera.forEach((k, j) => {
      const f = i > 0 && j === 0 ? start + TRAVEL_FRAMES : start + k.at * dur;
      out.push({f, lon: k.lon, lat: k.lat, zoom: k.zoom});
    });
    start += dur;
  });
  return out;
})();

export const cameraAt = (frame: number): {lon: number; lat: number; zoom: number} => {
  const first = KEYFRAMES[0];
  const last = KEYFRAMES[KEYFRAMES.length - 1];
  if (frame <= first.f) return first;
  if (frame >= last.f) return last;
  let i = 0;
  while (i < KEYFRAMES.length - 2 && frame > KEYFRAMES[i + 1].f) i++;
  const a = KEYFRAMES[i];
  const b = KEYFRAMES[i + 1];
  const e = easeInOut((frame - a.f) / (b.f - a.f));
  return {
    lon: a.lon + (b.lon - a.lon) * e,
    lat: a.lat + (b.lat - a.lat) * e,
    zoom: Math.exp(Math.log(a.zoom) + (Math.log(b.zoom) - Math.log(a.zoom)) * e), // zoom di ruang logaritmik
  };
};
