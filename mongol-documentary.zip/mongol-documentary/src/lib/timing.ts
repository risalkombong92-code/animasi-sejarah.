import {FPS, SCENES, TOTAL_SEC} from '../data/scenes';
import voice from '../data/voiceTimings';

/**
 * SATU-SATUNYA sumber waktu. Semua visual (tahap peta, penanda, rute, pita, plakat tokoh,
 * efek suara) dijangkarkan ke KALIMAT narasi lewat T(adegan, kalimat, pecahan).
 * Jika suara sudah dibuat, jangkar memakai durasi audio asli; jika belum, memakai estimasi.
 */
export const HAS_VO: boolean = voice.generated;
export const EST_CPS = 13.5; // perkiraan karakter/detik narasi terukur
export const LEAD = 0.6; // jeda sebelum kalimat pertama adegan
export const GAP = 0.4; // jeda antarkalimat (estimasi)
export const TAIL = 0.8; // sisa hening di akhir adegan

export const sceneStart = (no: number): number =>
  SCENES.slice(0, no - 1).reduce((a, s) => a + s.durationSec, 0);

export type CueSpan = {
  sceneNo: number;
  idx: number;
  text: string;
  start: number; // detik global
  dur: number;
  file?: string;
};

const build = (): CueSpan[][] =>
  SCENES.map((s) => {
    const base = sceneStart(s.no);
    const real = HAS_VO ? voice.scenes[s.id] : undefined;
    if (real && real.cues.length === s.cues.length) {
      return s.cues.map((text, idx) => ({
        sceneNo: s.no, idx, text,
        start: base + real.cues[idx].start,
        dur: real.cues[idx].duration,
        file: real.cues[idx].file,
      }));
    }
    const raw = s.cues.map((c) => c.length / EST_CPS);
    const sum = raw.reduce((a, b) => a + b, 0);
    const room = s.durationSec - LEAD - TAIL - GAP * (s.cues.length - 1);
    const k = sum > room ? room / sum : 1;
    let t = LEAD;
    return s.cues.map((text, idx) => {
      const dur = raw[idx] * k;
      const span = {sceneNo: s.no, idx, text, start: base + t, dur};
      t += dur + GAP;
      return span;
    });
  });

export const CUES: CueSpan[][] = build();
export const ALL_CUES: CueSpan[] = CUES.flat();

export const cueSpan = (no: number, idx: number): CueSpan => {
  const c = CUES[no - 1]?.[idx];
  if (!c) throw new Error(`Kalimat tidak ada: adegan ${no}, indeks ${idx}`);
  return c;
};

/** Waktu global (detik): awal kalimat + pecahan durasinya + offset. */
export const T = (no: number, idx: number, frac = 0, off = 0): number => {
  const c = cueSpan(no, idx);
  return c.start + c.dur * frac + off;
};
/** Waktu global dari awal adegan + offset detik. */
export const S = (no: number, off = 0): number => sceneStart(no) + off;
export const cueEnd = (no: number, idx: number): number => {
  const c = cueSpan(no, idx);
  return c.start + c.dur;
};

export const END_CARD_START = Math.min(TOTAL_SEC - 6, cueEnd(13, 3) + 0.8);
export const toFrame = (sec: number): number => Math.round(sec * FPS);
