export const clamp01 = (x: number): number => Math.min(1, Math.max(0, x));
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const easeInOut = (t: number): number => {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
export const easeOut = (t: number): number => 1 - Math.pow(1 - clamp01(t), 3);

/** Jendela muncul-hilang: 0→1 selama `fin`, bertahan, 1→0 selama `fout` sebelum `end`. */
export const fadeWindow = (t: number, start: number, end: number, fin = 0.6, fout = 0.6): number =>
  clamp01((t - start) / fin) * clamp01((end - t) / fout);
