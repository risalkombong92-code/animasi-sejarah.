export type LonLat = [number, number];

export type Owner =
  | 'homeland'
  | 'mongol'
  | 'yuan'
  | 'ilkhanate'
  | 'chagatai'
  | 'goldenhorde'
  | 'ming'
  | 'rus'
  | 'timurid'
  | 'successor'
  | 'other';

/** Bentuk hubungan politik — dikodekan berbeda secara visual (lihat legenda). */
export type Status = 'controlled' | 'tributary' | 'occupied';
export type Confidence = 'high' | 'medium' | 'approximate';

export type RegionState = {owner: Owner; status: Status; confidence: Confidence};

export type RegionDef = {
  id: string;
  name: string;
  labelAt: LonLat;
  polygon: LonLat[];
};

export type CamKey = {at: number; lon: number; lat: number; zoom: number};

export type SceneDef = {
  no: number;
  id: string;
  title: string;
  dateLabel: string;
  durationSec: number;
  purpose: string;
  delivery: string;
  visual: string;
  onScreen: string;
  transition: string;
  sound: string;
  sources: string;
  camera: CamKey[];
  cues: string[];
};
