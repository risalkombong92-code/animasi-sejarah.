/**
 * Ditulis ulang otomatis oleh scripts/generate_voiceover.py setelah suara dibuat/direkam.
 * Selama `generated` = false, video memakai ESTIMASI durasi kalimat (tanpa audio suara)
 * dan semua visual tetap tersinkron ke estimasi itu.
 */
export type VoiceCue = {file: string; start: number; duration: number};
export type VoiceTimings = {
  generated: boolean;
  voice: string;
  scenes: Record<string, {cues: VoiceCue[]}>;
};

const voiceTimings: VoiceTimings = {generated: false, voice: '', scenes: {}};
export default voiceTimings;
