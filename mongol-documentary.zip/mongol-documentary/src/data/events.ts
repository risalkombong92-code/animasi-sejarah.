import type {LonLat} from './types';
import {S, T} from '../lib/timing';

/* ------------------------------------------------------------------ */
/* Penanda peristiwa / kota                                            */
/* ------------------------------------------------------------------ */
export type MarkerKind = 'capital' | 'battle' | 'siege' | 'event' | 'tribe';
export type MarkerDef = {
  id: string;
  label: string;
  sub?: string;
  ll: LonLat;
  at: number; // detik global
  hold: number; // lama label tampil
  kind: MarkerKind;
  dx?: number; // offset label (px layar)
  dy?: number;
  anchor?: 'start' | 'end';
  always?: boolean; // titik tetap tampil selamanya
  sfx?: 'ping' | 'drum' | 'impact' | 'none';
};

export const MARKERS: MarkerDef[] = [
  // --- Adegan 2: suku-suku (lokasi PERKIRAAN) ---
  {id: 'tribe-mongol', label: 'Mongol', sub: 'lokasi perkiraan', ll: [109, 48.3], at: T(2, 0, 0.66), hold: 11, kind: 'tribe', dx: 0, dy: 26, anchor: 'start'},
  {id: 'tribe-tatar', label: 'Tatar', ll: [117.5, 47.2], at: T(2, 0, 0.75), hold: 10, kind: 'tribe', dx: 10, dy: 8, anchor: 'start'},
  {id: 'tribe-kereyid', label: 'Kereyid', ll: [104.5, 47.5], at: T(2, 0, 0.82), hold: 9, kind: 'tribe', dx: -10, dy: 8, anchor: 'end'},
  {id: 'tribe-naiman', label: 'Naiman', ll: [92, 47.3], at: T(2, 0, 0.9), hold: 8, kind: 'tribe', dx: 0, dy: 8, anchor: 'start'},
  // --- Adegan 3 ---
  {id: 'kurultai', label: 'Kurultai, 1206', sub: 'dekat hulu Sungai Onon (perkiraan)', ll: [110.5, 48.8], at: T(3, 1, 0.3), hold: 8, kind: 'event', dx: 16, dy: -22, anchor: 'start', sfx: 'ping'},
  // --- Adegan 4 ---
  {id: 'zhongdu', label: 'Zhongdu (Beijing)', sub: 'direbut 1215', ll: [116.4, 39.9], at: T(4, 0, 0.78), hold: 7, kind: 'siege', dx: 16, dy: 14, anchor: 'start', sfx: 'drum'},
  {id: 'balasagun', label: 'Balasagun', sub: 'Kara Khitai, 1218', ll: [75.2, 42.7], at: T(4, 1, 0.6), hold: 6, kind: 'event', dx: -16, dy: -10, anchor: 'end', sfx: 'ping'},
  // --- Adegan 5 ---
  {id: 'otrar', label: 'Otrar', sub: 'c. 1218', ll: [68.3, 42.85], at: T(5, 1, 0.88), hold: 7, kind: 'siege', dx: 14, dy: -16, anchor: 'start', sfx: 'drum'},
  {id: 'bukhara', label: 'Bukhara', sub: '1220', ll: [64.4, 39.8], at: T(5, 2, 0.25), hold: 7, kind: 'siege', dx: -14, dy: -6, anchor: 'end', sfx: 'ping'},
  {id: 'samarkand', label: 'Samarkand', sub: '1220', ll: [67, 39.65], at: T(5, 2, 0.42), hold: 7, kind: 'siege', dx: 14, dy: 20, anchor: 'start', sfx: 'ping'},
  {id: 'merv', label: 'Merv', sub: '1221', ll: [62.2, 37.65], at: T(5, 2, 0.62), hold: 6, kind: 'siege', dx: -14, dy: 8, anchor: 'end', sfx: 'ping'},
  {id: 'nishapur', label: 'Nishapur', sub: '1221', ll: [58.8, 36.2], at: T(5, 2, 0.8), hold: 6, kind: 'siege', dx: -14, dy: 22, anchor: 'end', sfx: 'ping'},
  // --- Adegan 6 ---
  {id: 'karakorum', label: 'Karakorum', sub: 'pusat pemerintahan (dibangun 1230-an)', ll: [102.84, 47.2], at: T(6, 2, 0.6), hold: 9, kind: 'capital', dx: -14, dy: -14, anchor: 'end', always: true, sfx: 'ping'},
  // --- Adegan 7 ---
  {id: 'ryazan', label: 'Ryazan', sub: 'Des 1237', ll: [39.9, 54.6], at: T(7, 0, 0.7), hold: 4.5, kind: 'siege', dx: 14, dy: 18, anchor: 'start', sfx: 'ping'},
  {id: 'vladimir', label: 'Vladimir', sub: 'Feb 1238', ll: [40.4, 56.1], at: T(7, 0, 0.95), hold: 4.5, kind: 'siege', dx: 14, dy: -10, anchor: 'start', sfx: 'ping'},
  {id: 'kyiv', label: 'Kyiv', sub: 'Des 1240', ll: [30.5, 50.45], at: T(7, 1, 0.75), hold: 5, kind: 'siege', dx: -14, dy: 6, anchor: 'end', sfx: 'drum'},
  {id: 'legnica', label: 'Legnica', sub: '9 Apr 1241', ll: [16.2, 51.2], at: T(7, 2, 0.8), hold: 6, kind: 'battle', dx: -14, dy: -8, anchor: 'end', sfx: 'drum'},
  {id: 'mohi', label: 'Mohi', sub: '11 Apr 1241', ll: [21, 47.95], at: T(7, 2, 0.95), hold: 6, kind: 'battle', dx: -14, dy: 22, anchor: 'end', sfx: 'drum'},
  // --- Adegan 8 ---
  {id: 'baghdad', label: 'Baghdad', sub: 'Februari 1258', ll: [44.4, 33.3], at: T(8, 0, 0.72), hold: 6, kind: 'siege', dx: 14, dy: 16, anchor: 'start', sfx: 'impact'},
  {id: 'ainjalut', label: 'Ain Jalut', sub: '3 September 1260', ll: [35.36, 32.55], at: T(8, 1, 0.75), hold: 6, kind: 'battle', dx: 20, dy: 38, anchor: 'start', sfx: 'drum'},
  // --- Adegan 9 ---
  {id: 'dadu', label: 'Dadu (Beijing)', sub: 'ibu kota Yuan, 1271', ll: [116.4, 39.9], at: T(9, 1, 0.2), hold: 6, kind: 'capital', dx: 16, dy: -10, anchor: 'start', always: true, sfx: 'ping'},
  {id: 'yamen', label: 'Yamen', sub: '1279', ll: [113.0, 22.2], at: T(9, 1, 0.68), hold: 5, kind: 'battle', dx: -14, dy: 16, anchor: 'end', sfx: 'drum'},
  {id: 'hakata', label: 'Teluk Hakata', sub: '1274 dan 1281', ll: [130.4, 33.65], at: T(9, 2, 0.38), hold: 5.5, kind: 'event', dx: 14, dy: 14, anchor: 'start', sfx: 'ping'},
  {id: 'tuban', label: 'Jawa (Tuban)', sub: '1293 · ekspedisi gagal', ll: [112.05, -6.9], at: T(9, 2, 0.95), hold: 5, kind: 'event', dx: 14, dy: -10, anchor: 'start', sfx: 'ping'},
  // --- Adegan 10 ---
  {id: 'caffa', label: 'Kaffa (Feodosia)', sub: '1346 · dikaitkan dengan wabah', ll: [35.4, 45.03], at: T(10, 2, 0.6), hold: 6, kind: 'event', dx: -14, dy: -16, anchor: 'end', sfx: 'ping'},
  // --- Adegan 12 ---
  {id: 'dadu-1368', label: 'Dadu direbut Ming', sub: '1368', ll: [116.4, 39.9], at: T(12, 2, 0.55), hold: 5, kind: 'siege', dx: 16, dy: 24, anchor: 'start', sfx: 'impact'},
  {id: 'terek', label: 'Sungai Terek', sub: '1395 (lokasi perkiraan)', ll: [44.5, 43.5], at: T(12, 3, 0.4), hold: 4.5, kind: 'battle', dx: 12, dy: 20, anchor: 'start', sfx: 'ping'},
  {id: 'ugra', label: 'Sungai Ugra', sub: '1480 (lokasi perkiraan)', ll: [36.3, 54.7], at: T(12, 3, 0.9), hold: 5, kind: 'event', dx: -12, dy: -6, anchor: 'end', sfx: 'ping'},
  // --- Adegan 13 ---
  {id: 'panipat', label: 'Panipat', sub: '1526 · Babur', ll: [77.0, 29.4], at: T(13, 2, 0.8), hold: 6, kind: 'battle', dx: 14, dy: 14, anchor: 'start', sfx: 'drum'},
];

/* ------------------------------------------------------------------ */
/* Rute — setiap titik memiliki WAKTU tiba (sinkron dengan narasi)     */
/* ------------------------------------------------------------------ */
export type RouteKind = 'campaign' | 'naval' | 'trade';
export type RoutePoint = {ll: LonLat; t: number};
export type RouteDef = {
  id: string;
  label?: string;
  kind: RouteKind;
  color: string;
  points: RoutePoint[];
  riders?: number;
  linger?: number; // detik garis tetap terang setelah selesai
  hooves?: boolean;
  tag?: {dx: number; dy: number; anchor?: 'start' | 'end'}; // posisi label rute (px layar)
  fadeAt?: number; // untuk jalur dagang: mulai memudar (detik global)
};

const spread = (lls: LonLat[], t0: number, t1: number): RoutePoint[] =>
  lls.map((ll, i) => ({ll, t: t0 + ((t1 - t0) * i) / (lls.length - 1)}));

const GOLD = '#f0c35a';

export const ROUTES: RouteDef[] = [
  {id: 'jin-1211', label: 'Pasukan Mongol', kind: 'campaign', color: GOLD, riders: 7, hooves: true,
    points: [
      {ll: [110, 47.3], t: T(4, 0, 0.22)},
      {ll: [112, 43.5], t: T(4, 0, 0.5)},
      {ll: [115.5, 41], t: T(4, 0, 0.72)},
      {ll: [116.4, 39.9], t: T(4, 0, 0.8)},
    ]},
  {id: 'kara-khitai-1218', label: 'Pasukan Jebe', kind: 'campaign', color: GOLD, riders: 6, hooves: true,
    points: [
      {ll: [98, 47.5], t: T(4, 1, 0.0)},
      {ll: [88, 46.5], t: T(4, 1, 0.25)},
      {ll: [80.5, 44.2], t: T(4, 1, 0.45)},
      {ll: [75.2, 42.7], t: T(4, 1, 0.6)},
      {ll: [76, 39.5], t: T(4, 1, 0.85)},
    ]},
  {id: 'khwarazm-1219', label: 'Jenghis Khan', kind: 'campaign', color: GOLD, riders: 9, hooves: true, linger: 8,
    points: [
      {ll: [85, 48], t: T(5, 1, 0.5)},
      {ll: [76, 45.3], t: T(5, 1, 0.78)},
      {ll: [68.3, 42.85], t: T(5, 1, 0.92)},
      {ll: [64.4, 39.8], t: T(5, 2, 0.25)},
      {ll: [67, 39.65], t: T(5, 2, 0.42)},
      {ll: [62.2, 37.65], t: T(5, 2, 0.62)},
      {ll: [58.8, 36.2], t: T(5, 2, 0.8)},
    ]},
  {id: 'rus-1237', label: 'Batu Khan dan Subutai', kind: 'campaign', color: GOLD, riders: 9, hooves: true, linger: 8,
    points: [
      {ll: [48, 50.5], t: T(7, 0, 0.3)},
      {ll: [39.9, 54.6], t: T(7, 0, 0.7)},
      {ll: [40.4, 56.1], t: T(7, 0, 0.95)},
      {ll: [30.5, 50.45], t: T(7, 1, 0.8)},
      {ll: [24.7, 49.1], t: T(7, 2, 0.15)},
      {ll: [21, 47.95], t: T(7, 2, 0.95)},
    ]},
  {id: 'legnica-1241', kind: 'campaign', color: GOLD, riders: 5, hooves: true,
    points: [
      {ll: [24.7, 49.1], t: T(7, 2, 0.2)},
      {ll: [22.6, 51.25], t: T(7, 2, 0.5)},
      {ll: [16.2, 51.2], t: T(7, 2, 0.8)},
    ]},
  {id: 'hulagu-1258', label: 'Hulagu', kind: 'campaign', color: GOLD, riders: 8, hooves: true,
    points: [
      {ll: [48.5, 34.8], t: T(8, 0, 0.1)},
      {ll: [44.4, 33.3], t: T(8, 0, 0.75)},
    ]},
  {id: 'syria-1260', label: 'Pasukan Mongol di Suriah', kind: 'campaign', color: GOLD, riders: 6, hooves: true, tag: {dx: 22, dy: -34},
    points: [
      {ll: [44.4, 33.3], t: T(8, 0, 0.92)},
      {ll: [43.1, 36.34], t: T(8, 1, 0.0)},
      {ll: [39.0, 36.87], t: T(8, 1, 0.1)},
      {ll: [37.16, 36.2], t: T(8, 1, 0.2)},
      {ll: [36.3, 33.5], t: T(8, 1, 0.4)},
      {ll: [35.36, 32.55], t: T(8, 1, 0.72)},
    ]},
  {id: 'mamluk-1260', label: 'Mamluk (Qutuz dan Baibars)', kind: 'campaign', color: '#5fb4f0', riders: 6, hooves: true, tag: {dx: -22, dy: 46, anchor: 'end'},
    points: [
      {ll: [31.24, 30.05], t: T(8, 1, 0.25)},
      {ll: [34.47, 31.5], t: T(8, 1, 0.5)},
      {ll: [35.36, 32.55], t: T(8, 1, 0.7)},
    ]},
  {id: 'japan-1274', label: 'Armada Yuan ke Jepang', kind: 'naval', color: GOLD, riders: 4,
    points: [
      {ll: [128.6, 35.2], t: T(9, 2, 0.1)},
      {ll: [129.3, 34.4], t: T(9, 2, 0.26)},
      {ll: [130.4, 33.65], t: T(9, 2, 0.38)},
    ]},
  {id: 'java-1293', label: 'Armada Yuan ke Jawa', kind: 'naval', color: GOLD, riders: 4,
    points: [
      {ll: [118.6, 24.9], t: T(9, 2, 0.55)},
      {ll: [113, 17], t: T(9, 2, 0.68)},
      {ll: [108, 10], t: T(9, 2, 0.78)},
      {ll: [107, 4], t: T(9, 2, 0.86)},
      {ll: [110, -3.5], t: T(9, 2, 0.92)},
      {ll: [112.05, -6.9], t: T(9, 2, 0.97)},
    ]},
  {id: 'silk-road', label: 'Jalur Sutra (disederhanakan)', kind: 'trade', color: '#8fd3c8', linger: 999, fadeAt: S(11, 1.5),
    points: spread(
      [[116.4, 39.9], [103.8, 36.06], [94.7, 40.1], [76, 39.5], [67, 39.65], [62.2, 37.65], [46.3, 38.1], [39.7, 41.0]],
      T(10, 0, 0.2), T(10, 1, 0.8)),
  },
  {id: 'steppe-road', label: 'Jalur stepa (disederhanakan)', kind: 'trade', color: '#d6b3f0', linger: 999, fadeAt: S(11, 1.5),
    points: spread(
      [[102.84, 47.2], [80.6, 44.2], [46.1, 48.0], [35.4, 45.0]],
      T(10, 0, 0.5), T(10, 1, 0.95)),
  },
  {id: 'babur-1526', label: 'Babur', kind: 'campaign', color: '#d9a3e8', riders: 6, hooves: true,
    points: [
      {ll: [69.2, 34.5], t: T(13, 2, 0.35)},
      {ll: [73, 32], t: T(13, 2, 0.58)},
      {ll: [77.0, 29.4], t: T(13, 2, 0.78)},
    ]},
];

/* ------------------------------------------------------------------ */
/* Pita tanggal (headline), plakat tokoh, label wilayah               */
/* ------------------------------------------------------------------ */
export type RibbonDef = {id: string; date: string; title: string; at: number; dur: number};
export const RIBBONS: RibbonDef[] = [
  {id: 'r1206', date: '1206', title: 'Kurultai: Temüjin menjadi Jenghis Khan', at: T(3, 1, 0.4), dur: 5.5},
  {id: 'r1215', date: '1215', title: 'Zhongdu (Beijing) direbut', at: T(4, 0, 0.75), dur: 4.5},
  {id: 'r1218', date: 'c. 1218', title: 'Insiden Otrar', at: T(5, 1, 0.45), dur: 4.5},
  {id: 'r1227', date: '1227', title: 'Wafatnya Jenghis Khan', at: T(6, 0, 0.15), dur: 4.5},
  {id: 'r1241', date: '1241', title: 'Legnica dan Mohi', at: T(7, 2, 0.05), dur: 3.7},
  {id: 'r1242', date: '1242', title: 'Mongol mundur dari Hungaria', at: T(7, 3, 0.1), dur: 4.5},
  {id: 'r1258', date: '1258', title: 'Jatuhnya Baghdad', at: T(8, 0, 0.45), dur: 4.5},
  {id: 'r1260', date: '1260', title: 'Pertempuran Ain Jalut', at: T(8, 1, 0.4), dur: 5},
  {id: 'r1271', date: '1271', title: 'Dinasti Yuan berdiri', at: T(9, 1, 0.02), dur: 3.0},
  {id: 'r1279', date: '1279', title: 'Song Selatan jatuh', at: T(9, 1, 0.62), dur: 3.4},
  {id: 'rpax', date: 'c. 1300', title: 'Pax Mongolica (istilah modern)', at: S(10, 1.8), dur: 5},
  {id: 'r1335', date: '1335', title: 'Ilkhanat terpecah', at: T(12, 1, 0.0), dur: 3.6},
  {id: 'r1368', date: '1368', title: 'Yuan terusir dari Dadu (Beijing)', at: T(12, 2, 0.5), dur: 4.2},
  {id: 'r1395', date: '1395', title: 'Timur mengalahkan Tokhtamysh', at: T(12, 3, 0.33), dur: 3.8},
  {id: 'r1480', date: '1480', title: 'Moskow lepas dari kekuasaan Horde', at: T(12, 3, 0.85), dur: 4},
];

// Pita tidak boleh bertumpuk: jika durasi suara membuat dua pita berdekatan, pita kedua digeser
// sesaat setelah pita pertama selesai (urutan kronologis tetap terjaga).
(() => {
  RIBBONS.sort((a, b) => a.at - b.at);
  for (let i = 1; i < RIBBONS.length; i++) {
    const free = RIBBONS[i - 1].at + RIBBONS[i - 1].dur + 0.1;
    if (RIBBONS[i].at < free) RIBBONS[i].at = free;
  }
})();

export type NameplateDef = {
  id: string; name: string; role: string; years: string;
  at: number; to: number; slot: number; emblem: 'tug' | 'rider'; color: string;
};
export const NAMEPLATES: NameplateDef[] = [
  {id: 'jenghis', name: 'Jenghis Khan', role: 'Pendiri Kekaisaran Mongol', years: 'Temüjin · Khan sejak 1206 · w. 1227',
    at: T(3, 0, 0.05), to: T(3, 1, 0.95), slot: 0, emblem: 'tug', color: '#f0c35a'},
  {id: 'ogedei', name: 'Ögedei', role: 'Putra Jenghis Khan', years: 'Khagan 1229–1241',
    at: T(6, 1, 0.0), to: T(6, 2, 0.05), slot: 0, emblem: 'tug', color: '#f0c35a'},
  {id: 'batu', name: 'Batu Khan', role: 'Cucu Jenghis Khan, pemimpin ekspedisi barat', years: 'Ekspedisi 1236–1242',
    at: T(7, 0, 0.05), to: T(7, 1, 0.3), slot: 0, emblem: 'rider', color: '#f0c35a'},
  {id: 'subutai', name: 'Subutai', role: 'Jenderal senior Mongol', years: 'Strategi kampanye Eropa',
    at: T(7, 0, 0.05), to: T(7, 1, 0.3), slot: 1, emblem: 'rider', color: '#f0c35a'},
  {id: 'hulagu', name: 'Hulagu', role: 'Cucu Jenghis Khan, pendiri Ilkhanat', years: 'Baghdad 1258',
    at: T(8, 0, 0.0), to: T(8, 0, 1.0, 1.0), slot: 0, emblem: 'rider', color: '#f0c35a'},
  {id: 'kubilai', name: 'Kubilai Khan', role: 'Pendiri Dinasti Yuan (1271)', years: 'Khagan 1260–1294',
    at: T(9, 0, 0.05), to: T(9, 1, 0.1), slot: 0, emblem: 'tug', color: '#f0c35a'},
  {id: 'babur', name: 'Babur', role: 'Pendiri Kekaisaran Mughal', years: 'Panipat 1526',
    at: T(13, 2, 0.4), to: T(13, 3, 0.0), slot: 0, emblem: 'rider', color: '#d9a3e8'},
];

export type AreaLabelDef = {id: string; text: string; ll: LonLat; color: string; at: number; hold: number};
export const AREA_LABELS: AreaLabelDef[] = [
  {id: 'al-yuan', text: 'DINASTI YUAN', ll: [112, 38], color: '#e8776d', at: T(11, 2, 0.1), hold: 14},
  {id: 'al-ilkhan', text: 'ILKHANAT', ll: [52, 32.5], color: '#5fd0c6', at: T(11, 2, 0.28), hold: 12},
  {id: 'al-chagatai', text: 'KHANAT CHAGATAI', ll: [74, 42], color: '#b79cf0', at: T(11, 2, 0.44), hold: 10},
  {id: 'al-horde', text: 'GOLDEN HORDE', ll: [52, 51], color: '#7fb2ec', at: T(11, 2, 0.72), hold: 8},
  {id: 'al-succ-il', text: 'NEGARA PECAHAN ILKHANAT', ll: [52, 32.5], color: '#b8c0cc', at: T(12, 1, 0.15), hold: 5},
  {id: 'al-ming', text: 'DINASTI MING', ll: [112, 31], color: '#a9d36f', at: T(12, 2, 0.75), hold: 6},
  {id: 'al-nyuan', text: 'YUAN UTARA', ll: [103, 46.5], color: '#e8776d', at: T(12, 2, 0.8), hold: 6},
  {id: 'al-timurid', text: 'TIMUR (TIMURID)', ll: [64, 38.5], color: '#e0a3c4', at: T(12, 3, 0.55), hold: 5},
  {id: 'al-horde-succ', text: 'KHANAT-KHANAT PENERUS', ll: [50, 50.5], color: '#b8c0cc', at: T(12, 4, 0.0), hold: 8},
  {id: 'al-rus', text: 'MOSKOW DAN RUS', ll: [38.5, 57.5], color: '#d8cbb8', at: T(12, 4, 0.1), hold: 8},
];
