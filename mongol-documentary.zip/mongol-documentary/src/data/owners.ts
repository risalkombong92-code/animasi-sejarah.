import type {Owner} from './types';

export const OWNER: Record<Owner, {name: string; color: string}> = {
  homeland: {name: 'Tanah asal suku Mongol (belum bersatu)', color: '#c9a96a'},
  mongol: {name: 'Kekaisaran Mongol (bersatu)', color: '#e0b04a'},
  yuan: {name: 'Dinasti Yuan', color: '#c0463c'},
  ilkhanate: {name: 'Ilkhanat', color: '#2fa39a'},
  chagatai: {name: 'Khanat Chagatai', color: '#8e72c9'},
  goldenhorde: {name: 'Golden Horde', color: '#4f86c6'},
  ming: {name: 'Dinasti Ming', color: '#7fa650'},
  rus: {name: 'Rus / Moskow', color: '#b5a898'},
  timurid: {name: 'Kekaisaran Timurid', color: '#c47fa1'},
  successor: {name: 'Negara penerus Mongol', color: '#a9b4c0'},
  other: {name: 'Negara non-Mongol', color: '#8a6f55'},
};
