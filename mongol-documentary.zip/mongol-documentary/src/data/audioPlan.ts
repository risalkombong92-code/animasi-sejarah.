import {FPS, TOTAL_SEC} from './scenes';
import {MARKERS, RIBBONS, ROUTES} from './events';
import {DELTAS} from './mapStages';
import {S, T} from '../lib/timing';

/**
 * Rencana suara — setiap cue punya alasan naratif (lihat docs/cue_sheet.md).
 * Semua file dibuat oleh scripts/generate_music_sfx.py (sintesis asli, bebas lisensi pihak ketiga).
 */
export const MUSIC_FILE = 'audio/music/score.mp3';
export const SFX = {
  impact: 'audio/sfx/impact.mp3',
  drum: 'audio/sfx/drum.mp3',
  whoosh: 'audio/sfx/whoosh.mp3',
  ping: 'audio/sfx/ping.mp3',
  tick: 'audio/sfx/tick.mp3',
  hooves: 'audio/sfx/hooves.mp3', // loop
  wind: 'audio/sfx/wind.mp3', // loop
} as const;
export type SfxName = keyof typeof SFX;

export type OneShot = {id: string; sfx: SfxName; at: number; volume: number};
export type LoopCue = {id: string; sfx: SfxName; from: number; to: number; volume: number; fade: number};

const shots: OneShot[] = [];
shots.push({id: 'title-hit', sfx: 'impact', at: 0.6, volume: 0.8});

// Whoosh hanya pada perpindahan kamera yang berarti secara naratif
[2, 7, 9, 12].forEach((no) => shots.push({id: `whoosh-${no}`, sfx: 'whoosh', at: S(no, 0.25), volume: 0.32}));

// Cap tanggal pada setiap tahap peta (kecuali tahap awal)
DELTAS.slice(1).forEach((d) => shots.push({id: `tick-${d.id}`, sfx: 'tick', at: d.atSec, volume: 0.28}));

// Penanda
MARKERS.forEach((m) => {
  const kind = m.sfx ?? 'ping';
  if (kind === 'none' || m.kind === 'tribe') return;
  const vol = kind === 'impact' ? 0.55 : kind === 'drum' ? 0.42 : 0.2;
  shots.push({id: `m-${m.id}`, sfx: kind, at: m.at, volume: vol});
});
// Pita 1368 (kejatuhan) mendapat benturan dalam — satu-satunya tambahan
shots.push({id: 'fall-1368', sfx: 'impact', at: RIBBONS.find((r) => r.id === 'r1368')!.at, volume: 0.35});

export const ONE_SHOTS: OneShot[] = shots.sort((a, b) => a.at - b.at);

const loops: LoopCue[] = [
  {id: 'wind-open', sfx: 'wind', from: 0, to: S(3, 6), volume: 0.34, fade: 2.5},
  {id: 'wind-end', sfx: 'wind', from: S(13, 12), to: TOTAL_SEC, volume: 0.28, fade: 3},
];
ROUTES.filter((r) => r.hooves).forEach((r) =>
  loops.push({id: `hooves-${r.id}`, sfx: 'hooves', from: r.points[0].t, to: r.points[r.points.length - 1].t + 1.5, volume: 0.16, fade: 0.8}),
);
export const LOOPS: LoopCue[] = loops;

// Ducking musik di bawah narasi
export const MUSIC = {base: 0.5, ducked: 0.2, noVoBase: 0.38, rampSec: 0.45, fadeIn: 2.5, fadeOut: 7};
export const toF = (sec: number): number => Math.round(sec * FPS);
export {T};
