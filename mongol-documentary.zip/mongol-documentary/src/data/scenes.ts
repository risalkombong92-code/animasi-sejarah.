import narration from './narration.json';
import type {SceneDef} from './types';

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

const N = narration as {no: number; cues: string[]}[];
const cuesOf = (no: number): string[] => {
  const hit = N.find((n) => n.no === no);
  if (!hit) throw new Error(`Narasi adegan ${no} tidak ditemukan`);
  return hit.cues;
};

/**
 * Daftar adegan = satu garis waktu. Total harus tepat 300 detik (5 menit).
 * `camera.at` adalah pecahan 0..1 dari durasi adegan. Kamera adegan berikutnya
 * dimulai 1,5 dtk setelah adegan dimulai, jadi perpindahan antar adegan selalu mulus.
 */
export const SCENES: SceneDef[] = [
  {
    no: 1, id: 's01', title: 'Pembuka', dateLabel: 'c. 1200–1500-an', durationSec: 15,
    purpose: 'Hook visual dan pertanyaan besar: bagaimana kekuatan sebesar ini bangkit lalu runtuh?',
    delivery: 'Tenang, berat, spasi lebar. Jeda 1 dtk setelah kalimat pertama.',
    visual: 'Peta Eurasia skematis dari jauh, perlahan mendekat ke Mongolia. Kartu judul muncul di tengah.',
    onScreen: 'BANGKIT DAN RUNTUHNYA KEKAISARAN MONGOL',
    transition: 'Dorongan kamera (push-in) ke stepa Mongolia.',
    sound: 'Drone rendah mengembang, satu benturan dalam saat judul, angin tipis.',
    sources: 'Klaim "kekaisaran darat menyambung terbesar" lazim dalam literatur (mis. Morgan, The Mongols; May, The Mongol Conquests in World History).',
    camera: [{at: 0, lon: 85, lat: 45, zoom: 0.62}, {at: 1, lon: 100, lat: 47, zoom: 0.9}],
    cues: cuesOf(1),
  },
  {
    no: 2, id: 's02', title: 'Stepa yang Terpecah', dateLabel: 'c. 1200', durationSec: 20,
    purpose: 'Menetapkan konteks: Mongolia sebelum persatuan.',
    delivery: 'Reflektif, datar, mengamati.',
    visual: 'Zoom ke dataran tinggi Mongolia; label suku muncul satu per satu sesuai penyebutan (lokasi perkiraan).',
    onScreen: 'c. 1200 — Suku-suku stepa belum bersatu',
    transition: 'Camera travel dari Eurasia ke Mongolia.',
    sound: 'Angin stepa, pad rendah minimal, tanpa perkusi.',
    sources: 'Secret History of the Mongols (terj. de Rachewiltz); Morgan, The Mongols. Lokasi suku bersifat perkiraan.',
    camera: [{at: 0, lon: 100, lat: 47, zoom: 1.3}, {at: 1, lon: 103, lat: 47.5, zoom: 1.6}],
    cues: cuesOf(2),
  },
  {
    no: 3, id: 's03', title: 'Temüjin Menjadi Jenghis Khan', dateLabel: '1206', durationSec: 20,
    purpose: 'Titik awal: persatuan Mongol dan reorganisasi militer.',
    delivery: 'Mantap, sedikit lebih hangat; tekankan "1206".',
    visual: 'Mongolia terisi warna emas saat kurultai; kartu tokoh Jenghis Khan (ilustrasi simbolis).',
    onScreen: '1206 — Kurultai: Temüjin menjadi Jenghis Khan',
    transition: 'Dorongan lebih dekat; wilayah Mongolia menyala.',
    sound: 'Denyut frame-drum pertama (sangat pelan), pad naik.',
    sources: 'Secret History; Biran, Chinggis Khan (2007). Tahun lahir Temüjin diperdebatkan, sehingga tidak ditampilkan.',
    camera: [{at: 0, lon: 103, lat: 47.5, zoom: 1.6}, {at: 1, lon: 109, lat: 48, zoom: 2.2}],
    cues: cuesOf(3),
  },
  {
    no: 4, id: 's04', title: 'Ke Tiongkok dan Asia Tengah', dateLabel: '1209–1218', durationSec: 20,
    purpose: 'Ekspansi pertama: Xia Barat, Jin, Kara Khitai.',
    delivery: 'Lebih cepat sedikit, tegas.',
    visual: 'Panah kampanye ke Zhongdu, lalu ke barat ke Kara Khitai; pasukan berkuda bergerak.',
    onScreen: '1211–1215 Perang Jin · 1218 Kara Khitai',
    transition: 'Pan kamera ke barat mengikuti rute.',
    sound: 'Perkusi rendah mulai berdenyut, derap kuda tipis.',
    sources: 'Morgan; Jackson, The Mongols and the Islamic World. Rute disederhanakan.',
    camera: [{at: 0, lon: 108, lat: 43, zoom: 1.25}, {at: 1, lon: 95, lat: 44, zoom: 1.0}],
    cues: cuesOf(4),
  },
  {
    no: 5, id: 's05', title: 'Perang Khwarazmia', dateLabel: '1218–1221', durationSec: 30,
    purpose: 'Kampanye paling dramatis; angka korban sengaja tidak disebut.',
    delivery: 'Serius dan terkendali; kalimat terakhir lambat, tanpa dramatisasi.',
    visual: 'Rute Altai–Otrar–Bukhara–Samarkand–Merv–Nishapur; kota ditandai saat disebut.',
    onScreen: '1219–1221 Kampanye Khwarazmia',
    transition: 'Kamera mendekat ke Asia Tengah.',
    sound: 'Perkusi mantap, string rendah; musik menipis di kalimat terakhir.',
    sources: 'Juvaini, Tarikh-i Jahangushay; Jackson 2017. Jumlah korban diperdebatkan; rute disederhanakan (beberapa pasukan bergerak terpisah).',
    camera: [{at: 0, lon: 75, lat: 42, zoom: 1.2}, {at: 1, lon: 68, lat: 40, zoom: 1.5}],
    cues: cuesOf(5),
  },
  {
    no: 6, id: 's06', title: 'Penerus Sang Khan', dateLabel: '1227–1234', durationSec: 20,
    purpose: 'Suksesi dan konsolidasi: Ögedei, runtuhnya Jin, Karakorum.',
    delivery: 'Datar-formal, sedikit melambat.',
    visual: 'Tampilan luas Asia Timur; Xia Barat dan Jin berubah menjadi wilayah dikuasai; Karakorum ditandai.',
    onScreen: '1227 Wafatnya Jenghis Khan · 1234 Jin runtuh',
    transition: 'Zoom-out ke tampilan Asia.',
    sound: 'Perkusi mereda, pad berkabung ringan, lalu kembali naik.',
    sources: 'Morgan; Biran. Lokasi wafat Jenghis Khan diperdebatkan sehingga tidak ditandai.',
    camera: [{at: 0, lon: 90, lat: 43, zoom: 0.9}, {at: 1, lon: 95, lat: 42, zoom: 0.8}],
    cues: cuesOf(6),
  },
  {
    no: 7, id: 's07', title: 'Menuju Eropa', dateLabel: '1236–1242', durationSec: 25,
    purpose: 'Ekspansi ke barat: Rus, Polandia, Hungaria.',
    delivery: 'Energik terukur; kalimat terakhir jujur soal ketidakpastian.',
    visual: 'Rute Batu Khan dan Subutai ke Ryazan, Vladimir, Kyiv, lalu cabang Legnica dan Mohi.',
    onScreen: '1237–1242 Invasi Rus dan Eropa Tengah',
    transition: 'Pan cepat ke barat.',
    sound: 'Tempo naik, drum bertenaga, derap kuda.',
    sources: 'Jackson, The Mongols and the West. Penyebab mundur 1242 diperdebatkan.',
    camera: [{at: 0, lon: 42, lat: 51, zoom: 1.0}, {at: 1, lon: 28, lat: 50, zoom: 1.3}],
    cues: cuesOf(7),
  },
  {
    no: 8, id: 's08', title: 'Baghdad dan Ain Jalut', dateLabel: '1258–1260', durationSec: 20,
    purpose: 'Puncak ekspansi ke barat daya dan batasnya.',
    delivery: 'Berat pada Baghdad, lalu jeda sebelum Ain Jalut.',
    visual: 'Hulagu menuju Baghdad; pasukan Mongol dan Mamluk bertemu di Ain Jalut; kamera bergeser ke timur.',
    onScreen: '1258 Baghdad · 1260 Ain Jalut',
    transition: 'Kamera menyapu ke timur menuju Asia Timur.',
    sound: 'Benturan dalam saat Baghdad, jeda hening singkat sebelum Ain Jalut.',
    sources: 'Jackson 2017; Morgan. Kekhalifahan Abbasiyah berlanjut simbolis di Kairo, maka narasi dibatasi "di kota itu".',
    camera: [{at: 0, lon: 44, lat: 34.5, zoom: 1.5}, {at: 0.7, lon: 42, lat: 34, zoom: 1.55}, {at: 1, lon: 95, lat: 38, zoom: 0.85}],
    cues: cuesOf(8),
  },
  {
    no: 9, id: 's09', title: 'Kubilai dan Dinasti Yuan', dateLabel: '1260–1293', durationSec: 25,
    purpose: 'Puncak di Tiongkok dan batas kekuatan maritim.',
    delivery: 'Mantap, lalu nada "namun" yang dingin.',
    visual: 'Tiongkok jatuh ke Yuan; armada ke Jepang dan Jawa berakhir tanpa penaklukan.',
    onScreen: '1271 Yuan · 1279 Song Selatan · 1274/1281 Jepang · 1293 Jawa',
    transition: 'Kamera fokus ke Jepang lebih dulu, lalu turun ke selatan mengikuti armada ke Jawa.',
    sound: 'Pad mengangkat, perkusi sedang; musik meredup saat ekspedisi gagal.',
    sources: 'Morgan; Biran. Ekspedisi Jawa 1293 berkaitan dengan berdirinya Majapahit; rute laut dan pendaratan (Tuban) perkiraan.',
    camera: [{at: 0, lon: 100, lat: 30, zoom: 0.9}, {at: 0.38, lon: 116, lat: 26, zoom: 0.82}, {at: 0.55, lon: 118, lat: 25, zoom: 0.8}, {at: 0.66, lon: 116, lat: 9.2, zoom: 0.72}, {at: 1, lon: 116, lat: 9, zoom: 0.72}],
    cues: cuesOf(9),
  },
  {
    no: 10, id: 's10', title: 'Jalur Sutra dan Pos Yam', dateLabel: 'c. 1300', durationSec: 20,
    purpose: 'Sisi lain kekaisaran: konektivitas.',
    delivery: 'Lebih ringan dan mengalir.',
    visual: 'Dua jalur dagang menyala di seluruh Eurasia, kafilah bergerak; Kaffa ditandai.',
    onScreen: 'c. 1300 — Pax Mongolica (istilah modern)',
    transition: 'Zoom-out ke Eurasia utuh.',
    sound: 'Petikan lembut, pad terang, perkusi minimal.',
    sources: 'Jackson 2017; Cambridge History of Inner Asia: The Chinggisid Age. Hubungan jalur dagang dan Maut Hitam bersifat perkiraan/diperdebatkan.',
    camera: [{at: 0, lon: 85, lat: 40, zoom: 0.62}, {at: 1, lon: 75, lat: 41, zoom: 0.66}],
    cues: cuesOf(10),
  },
  {
    no: 11, id: 's11', title: 'Empat Wilayah (Ulus)', dateLabel: 'c. 1300–1310', durationSec: 25,
    purpose: 'Menjelaskan fragmentasi sebagai proses bertahap.',
    delivery: 'Analitis; sebut empat wilayah dengan jeda rapi.',
    visual: 'Warna wilayah berganti menjadi empat ulus; label muncul berurutan.',
    onScreen: 'Yuan · Ilkhanat · Chagatai · Golden Horde',
    transition: 'Warna menyebar (crossfade) tanpa memotong peta.',
    sound: 'Tegangan rendah, drone menahan, ritme hilang.',
    sources: 'Biran; Cambridge History of Inner Asia. Batas empat ulus bersifat perkiraan; Chagatai–Ögedeid berkonflik hingga c. 1300.',
    camera: [{at: 0, lon: 80, lat: 43, zoom: 0.64}, {at: 1, lon: 78, lat: 44, zoom: 0.66}],
    cues: cuesOf(11),
  },
  {
    no: 12, id: 's12', title: 'Keruntuhan yang Bertahap', dateLabel: '1335–1480', durationSec: 30,
    purpose: 'Keruntuhan sebagai proses panjang dan majemuk.',
    delivery: 'Reflektif, tanpa dramatisasi.',
    visual: 'Ilkhanat terpecah, Yuan jatuh ke Ming, Golden Horde melemah; peta berubah bertahap.',
    onScreen: '1335 · 1368 · 1395 · 1480',
    transition: 'Warna wilayah memudar menjadi abu-abu penerus.',
    sound: 'String rendah jarang, perkusi hilang, ruang hening.',
    sources: 'Jackson; Biran. Tanggal 1480 adalah tonggak tradisional "berakhirnya kuk Tatar". Lokasi Sungai Terek dan Ugra perkiraan.',
    camera: [{at: 0, lon: 80, lat: 43, zoom: 0.64}, {at: 1, lon: 80, lat: 45, zoom: 0.62}],
    cues: cuesOf(12),
  },
  {
    no: 13, id: 's13', title: 'Warisan', dateLabel: '1526 dan sesudahnya', durationSec: 30,
    purpose: 'Penutup berimbang: luka dan warisan.',
    delivery: 'Hangat, pelan, penuh jeda; kalimat terakhir tenang.',
    visual: 'Kamera ke India utara (Babur, Panipat 1526), lalu menjauh ke peta utuh; kartu penutup.',
    onScreen: 'Peta skematis — batas wilayah bersifat perkiraan',
    transition: 'Fade ke hitam.',
    sound: 'Pad mayor-ringan, resolusi lembut, memudar menjadi hening.',
    sources: 'Klaim keturunan Babur dari Timur dan (lewat garis ibu) Jenghis Khan lazim dalam literatur Mughal.',
    camera: [{at: 0, lon: 78, lat: 42, zoom: 0.64}, {at: 0.55, lon: 75, lat: 36, zoom: 1.0}, {at: 0.85, lon: 75, lat: 36, zoom: 1.0}, {at: 1, lon: 80, lat: 43, zoom: 0.58}],
    cues: cuesOf(13),
  },
];

export const TOTAL_SEC = SCENES.reduce((a, s) => a + s.durationSec, 0);
export const TOTAL_FRAMES = Math.round(TOTAL_SEC * FPS);
