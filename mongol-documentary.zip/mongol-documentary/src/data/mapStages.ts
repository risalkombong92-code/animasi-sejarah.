import type {Confidence, Owner, RegionState, Status} from './types';
import {S, T} from '../lib/timing';

/**
 * Tahap peta KUMULATIF. Setiap tahap hanya mendefinisikan PERUBAHAN (delta);
 * keadaan penuh dihitung dengan menggabungkan semua delta sebelumnya, sehingga
 * wilayah yang masih berlaku tidak pernah "hilang" antar tahap.
 */
const st = (owner: Owner, status: Status, confidence: Confidence = 'approximate'): RegionState => ({owner, status, confidence});

type Delta = {
  id: string;
  dateLabel: string;
  caption: string;
  atSec: number;
  regionLabels?: boolean;
  set: Record<string, RegionState>;
};

const YUAN_CORE = ['mongolia', 'xia', 'jin_north', 'jin_south', 'manchuria', 'song_south', 'yunnan'];

const ownerAll = (ids: string[], s: RegionState): Record<string, RegionState> =>
  Object.fromEntries(ids.map((id) => [id, s]));

export const DELTAS: Delta[] = [
  {id: 'c1200', dateLabel: 'c. 1200', caption: 'Suku-suku stepa Mongolia belum bersatu', atSec: 0,
    set: {mongolia: st('homeland', 'controlled')}},
  {id: '1206', dateLabel: '1206', caption: 'Temüjin menjadi Jenghis Khan — Ulus Mongol bersatu', atSec: T(3, 1, 0.55),
    set: {mongolia: st('mongol', 'controlled', 'medium')}},
  {id: '1209-1215', dateLabel: '1209–1215', caption: 'Xia Barat menjadi vasal; Jin utara diduduki', atSec: T(4, 0, 0.1),
    set: {xia: st('mongol', 'tributary', 'medium'), jin_north: st('mongol', 'occupied')}},
  {id: '1218', dateLabel: '1218', caption: 'Kara Khitai ditaklukkan', atSec: T(4, 1, 0.4),
    set: {kara_khitai: st('mongol', 'controlled')}},
  {id: '1220', dateLabel: '1220', caption: 'Bukhara dan Samarkand jatuh — Transoksiana dikuasai', atSec: T(5, 2, 0.3),
    set: {transoxiana: st('mongol', 'controlled', 'medium')}},
  {id: '1221', dateLabel: '1221', caption: 'Merv dan Nishapur jatuh — Khorasan diduduki', atSec: T(5, 2, 0.74),
    set: {khorasan: st('mongol', 'occupied')}},
  {id: '1227', dateLabel: '1227', caption: 'Jenghis Khan wafat; Xia Barat dihancurkan', atSec: T(6, 0, 0.8),
    set: {xia: st('mongol', 'controlled', 'medium')}},
  {id: '1234', dateLabel: '1234', caption: 'Dinasti Jin runtuh; Manchuria dikuasai (1233)', atSec: T(6, 2, 0.12),
    set: {jin_north: st('mongol', 'controlled', 'medium'), jin_south: st('mongol', 'controlled', 'medium'), manchuria: st('mongol', 'controlled')}},
  {id: '1236-1240', dateLabel: '1236–1240', caption: 'Stepa Kipchak dikuasai; kepangeranan Rus menjadi vasal', atSec: T(7, 1, 0.9),
    set: {kipchak: st('mongol', 'controlled'), rus: st('mongol', 'tributary', 'medium')}},
  {id: '1243-1256', dateLabel: '1243–1256', caption: 'Persia barat dan Kaukasus dikuasai; Rum (Seljuk) menjadi vasal (1243)', atSec: S(8, 1.2),
    set: {iran_west: st('mongol', 'controlled'), caucasus: st('mongol', 'tributary'), anatolia: st('mongol', 'tributary', 'medium')}},
  {id: '1258', dateLabel: '1258', caption: 'Baghdad direbut Hulagu', atSec: T(8, 0, 0.85),
    set: {iraq: st('mongol', 'controlled', 'medium')}},
  {id: '1253-1259', dateLabel: '1253–1259', caption: 'Di bawah Möngke Khan: Yunnan (1253), Tibet dan Korea (1259) tunduk', atSec: S(8, 17.2),
    set: {yunnan: st('mongol', 'controlled', 'medium'), tibet: st('mongol', 'tributary'), goryeo: st('mongol', 'tributary', 'medium')}},
  {id: '1279', dateLabel: '1279', caption: 'Song Selatan jatuh — seluruh Tiongkok di bawah Yuan', atSec: T(9, 1, 0.65),
    set: {song_south: st('mongol', 'controlled', 'medium')}},
  {id: 'c1300', dateLabel: 'c. 1300', caption: 'Pax Mongolica: jalur dagang Eurasia', atSec: S(10, 0.3), set: {}},
  {id: 'c1300-ulus', dateLabel: 'c. 1300–1310', caption: 'Terpecah bertahap menjadi empat wilayah utama', atSec: T(11, 1, 0.5), regionLabels: false,
    set: {
      ...ownerAll([...YUAN_CORE], st('yuan', 'controlled', 'approximate')),
      goryeo: st('yuan', 'tributary', 'approximate'),
      tibet: st('yuan', 'tributary', 'approximate'),
      kara_khitai: st('chagatai', 'controlled'),
      transoxiana: st('chagatai', 'controlled'),
      khorasan: st('ilkhanate', 'controlled'),
      iran_west: st('ilkhanate', 'controlled'),
      iraq: st('ilkhanate', 'controlled'),
      caucasus: st('ilkhanate', 'tributary'),
      anatolia: st('ilkhanate', 'tributary'),
      kipchak: st('goldenhorde', 'controlled'),
      rus: st('goldenhorde', 'tributary', 'medium'),
    }},
  {id: '1335', dateLabel: '1335', caption: 'Ilkhanat terpecah menjadi negara-negara kecil', atSec: T(12, 1, 0.1), regionLabels: false,
    set: ownerAll(['khorasan', 'iran_west', 'iraq', 'caucasus', 'anatolia'], st('successor', 'controlled'))},
  {id: '1368', dateLabel: '1368', caption: 'Yuan terusir dari Beijing oleh Ming; Korea dan Tibet lepas', atSec: T(12, 2, 0.7), regionLabels: false,
    set: {
      ...ownerAll(['jin_north', 'jin_south', 'song_south'], st('ming', 'controlled', 'medium')),
      goryeo: st('other', 'controlled'),
      tibet: st('other', 'controlled'),
    }},
  {id: '1395', dateLabel: '1395', caption: 'Timur menguasai Asia Tengah dan Iran timur; Chagatai terpecah', atSec: T(12, 3, 0.5), regionLabels: false,
    set: {
      transoxiana: st('timurid', 'controlled'),
      khorasan: st('timurid', 'controlled'),
      kara_khitai: st('successor', 'controlled'),
    }},
  {id: '1480', dateLabel: '1480', caption: 'Golden Horde terpecah; Moskow lepas dari Horde', atSec: T(12, 3, 0.95), regionLabels: false,
    set: {kipchak: st('successor', 'controlled'), rus: st('rus', 'controlled', 'medium')}},
];

export type Stage = {
  idx: number;
  id: string;
  dateLabel: string;
  caption: string;
  atSec: number;
  regionLabels: boolean;
  regions: Record<string, RegionState>;
  changed: string[];
};

export const STAGES: Stage[] = (() => {
  const out: Stage[] = [];
  let acc: Record<string, RegionState> = {};
  DELTAS.forEach((d, idx) => {
    const changed = Object.keys(d.set).filter((k) => JSON.stringify(acc[k]) !== JSON.stringify(d.set[k]));
    acc = {...acc, ...d.set};
    out.push({idx, id: d.id, dateLabel: d.dateLabel, caption: d.caption, atSec: d.atSec,
      regionLabels: d.regionLabels !== false, regions: acc, changed});
  });
  return out;
})();

export const STAGE_FADE = 2.0;

/**
 * Jaga jarak minimum antar tahap (>= STAGE_FADE + 0.3 dtk) agar crossfade tidak saling menimpa,
 * berapa pun durasi suara aslinya. Hanya menggeser tahap yang terlalu rapat ke belakang.
 */
(() => {
  for (let i = 1; i < STAGES.length; i++) {
    const min = STAGES[i - 1].atSec + STAGE_FADE + 0.3;
    if (STAGES[i].atSec < min) STAGES[i].atSec = min;
  }
})();

export const stageAt = (sec: number): {idx: number; p: number} => {
  let idx = 0;
  for (let i = 0; i < STAGES.length; i++) if (sec >= STAGES[i].atSec) idx = i;
  const p = idx === 0 ? 1 : Math.min(1, Math.max(0, (sec - STAGES[idx].atSec) / STAGE_FADE));
  return {idx, p};
};
