import React from 'react';
import {Composition} from 'remotion';
import {Documentary} from './Documentary';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './data/scenes';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MongolDocumentary"
    component={Documentary}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
