import React from 'react';

type IconProps = {x: number; y: number; scale: number; color: string; flip?: boolean; opacity?: number};

/** Penunggang kuda bergaya siluet (ilustrasi simbolis, bukan rekonstruksi perlengkapan). */
export const RiderIcon: React.FC<IconProps> = ({x, y, scale, color, flip, opacity = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`} opacity={opacity}>
    <g fill={color} stroke="#07101a" strokeWidth={0.9} strokeLinejoin="round" paintOrder="stroke">
      <ellipse cx={0} cy={0} rx={9} ry={3.8} />
      <path d="M7 -2 L11 -8 L14.5 -7 L12.5 -3.5 Z" />
      <circle cx={0} cy={-9} r={2.4} />
      <path d="M-2 -6.5 L2 -6.5 L1.5 -1.5 L-1.5 -1.5 Z" />
    </g>
    <g fill="none" stroke={color} strokeLinecap="round">
      <path d="M-8.5 -1 Q-13 0 -13 5" strokeWidth={1.4} />
      <path d="M-6 2 L-8 9 M-3 2 L-3.5 9 M4 2 L5 9 M7 2 L9.5 8" strokeWidth={1.7} />
      <path d="M2.5 -8 L11 -15" strokeWidth={1.2} />
    </g>
  </g>
);

export const ShipIcon: React.FC<IconProps> = ({x, y, scale, color, flip, opacity = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`} opacity={opacity}>
    <g fill={color} stroke="#07101a" strokeWidth={0.9} strokeLinejoin="round" paintOrder="stroke">
      <path d="M-11 0 L11 0 L7 5.5 L-7 5.5 Z" />
      <path d="M0 -1 L0 -14 L9 -3 Z" />
    </g>
    <path d="M0 0 L0 -15" stroke={color} strokeWidth={1.3} />
  </g>
);

/** Panji (tuğ) bergaya: tiang dengan rumbai — lambang generik, bukan reproduksi panji tertentu. */
export const TugEmblem: React.FC<{color: string; size?: number}> = ({color, size = 96}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx={50} cy={50} r={46} fill="rgba(8,14,20,0.85)" stroke={color} strokeWidth={2} />
    <path d="M50 84 L50 22" stroke={color} strokeWidth={3.2} strokeLinecap="round" />
    <circle cx={50} cy={19} r={5} fill={color} />
    <g fill="none" stroke={color} strokeWidth={2.4} strokeLinecap="round">
      <path d="M50 30 Q36 44 33 68" />
      <path d="M50 30 Q43 46 42 70" />
      <path d="M50 30 Q57 46 58 70" />
      <path d="M50 30 Q64 44 67 68" />
    </g>
  </svg>
);

export const RiderEmblem: React.FC<{color: string; size?: number}> = ({color, size = 96}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx={50} cy={50} r={46} fill="rgba(8,14,20,0.85)" stroke={color} strokeWidth={2} />
    <RiderIcon x={46} y={56} scale={2.6} color={color} />
  </svg>
);
