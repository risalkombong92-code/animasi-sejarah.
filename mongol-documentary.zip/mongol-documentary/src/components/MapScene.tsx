import React from 'react';
import {FPS, HEIGHT, WIDTH} from '../data/scenes';
import {AFRICA, EURASIA, ISLANDS, REGIONS, SEA_LABELS, WATERS} from '../data/geo';
import {OWNER} from '../data/owners';
import {STAGES, stageAt} from '../data/mapStages';
import {AREA_LABELS, MARKERS, ROUTES} from '../data/events';
import type {RegionDef, RegionState} from '../data/types';
import {cameraAt} from '../lib/camera';
import {useGlobalFrame} from '../lib/frameContext';
import {clamp01, easeOut, fadeWindow, lerp} from '../lib/anim';
import {project, toPath, WORLD} from '../lib/geo';
import {RiderIcon, ShipIcon} from './Icons';
import type {RouteDef} from '../data/events';

export const SEA = '#0b1620';
const LAND = '#2e2c24';
const LAND_EDGE = '#5f5238';
const SCREEN_CY = 500; // pusat kamera sedikit di atas tengah (ruang untuk subtitle)

const same = (a?: RegionState, b?: RegionState) => JSON.stringify(a) === JSON.stringify(b);
const LAND_PATHS = [EURASIA, AFRICA, ...ISLANDS].map((p) => toPath(p));
const OWNERS = Object.keys(OWNER) as (keyof typeof OWNER)[];

/** Teks dengan ukuran tetap di layar (tidak ikut membesar saat zoom). */
const ScreenText: React.FC<{
  x: number; y: number; z: number; children: React.ReactNode; size: number; fill: string;
  anchor?: 'start' | 'middle' | 'end'; opacity?: number; weight?: number | string; spacing?: number; italic?: boolean; font?: string;
}> = ({x, y, z, children, size, fill, anchor = 'middle', opacity = 1, weight = 600, spacing = 0, italic, font}) => (
  <g transform={`translate(${x} ${y}) scale(${1 / z})`} opacity={opacity}>
    <text
      textAnchor={anchor} fontSize={size} fill={fill} fontWeight={weight} letterSpacing={spacing}
      fontStyle={italic ? 'italic' : 'normal'}
      fontFamily={font ?? "'Helvetica Neue', Helvetica, Arial, sans-serif"}
      stroke={SEA} strokeWidth={4} paintOrder="stroke" strokeLinejoin="round"
    >
      {children}
    </text>
  </g>
);

/* ---------------------------- Rute ---------------------------- */
type Geo = {pts: [number, number][]; cum: number[]; times: number[]; total: number};
const GEO = new Map<string, Geo>();
const geoOf = (r: RouteDef): Geo => {
  const hit = GEO.get(r.id);
  if (hit) return hit;
  const pts = r.points.map((p) => project(p.ll));
  const cum = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const g = {pts, cum, times: r.points.map((p) => p.t), total: cum[cum.length - 1]};
  GEO.set(r.id, g);
  return g;
};

const pointAt = (g: Geo, s: number): {x: number; y: number; dx: number; dy: number} => {
  const ss = Math.min(g.total, Math.max(0, s));
  let i = 0;
  while (i < g.pts.length - 2 && ss > g.cum[i + 1]) i++;
  const seg = g.cum[i + 1] - g.cum[i] || 1;
  const u = (ss - g.cum[i]) / seg;
  const [ax, ay] = g.pts[i];
  const [bx, by] = g.pts[i + 1];
  const len = Math.hypot(bx - ax, by - ay) || 1;
  return {x: lerp(ax, bx, u), y: lerp(ay, by, u), dx: (bx - ax) / len, dy: (by - ay) / len};
};

const RouteView: React.FC<{r: RouteDef; t: number; z: number}> = ({r, t, z}) => {
  const g = geoOf(r);
  const t0 = g.times[0];
  const tEnd = g.times[g.times.length - 1];
  if (t < t0 - 0.05) return null;

  let i = 0;
  while (i < g.pts.length - 2 && t > g.times[i + 1]) i++;
  const u = clamp01((t - g.times[i]) / (g.times[i + 1] - g.times[i]));
  const sHead = t >= tEnd ? g.total : g.cum[i] + u * (g.cum[i + 1] - g.cum[i]);
  const head = pointAt(g, sHead);
  const finished = t >= tEnd;
  const linger = r.linger ?? 6;
  const lineAlpha =
    r.kind === 'trade'
      ? (r.fadeAt !== undefined ? 1 - clamp01((t - r.fadeAt) / 2.5) : 1) * 0.95
      : finished ? 1 - clamp01((t - tEnd - linger) / 3) : 1;
  if (lineAlpha <= 0.01) return null;
  const unitAlpha = finished ? 1 - clamp01((t - tEnd) / 2.5) : 1;

  const drawn = g.pts.slice(0, i + 1).map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`);
  drawn.push(`${head.x.toFixed(1)},${head.y.toFixed(1)}`);
  const d = 'M' + drawn.join(' L');

  const unitScale = 1 / z;
  const units: React.ReactNode[] = [];
  if (r.kind !== 'trade' && unitAlpha > 0) {
    const n = r.riders ?? 6;
    for (let k = 0; k < n; k++) {
      const back = (k * 30 + (k % 2) * 10) / z;
      const p = pointAt(g, Math.max(0, sHead - back));
      const nx = -p.dy;
      const ny = p.dx;
      const lat = (((k % 3) - 1) * 17) / z;
      const flip = p.dx < 0;
      const x = p.x + nx * lat;
      const y = p.y + ny * lat;
      units.push(
        r.kind === 'naval' ? (
          <ShipIcon key={k} x={x} y={y} scale={unitScale * 1.9} color={r.color} flip={flip} opacity={unitAlpha} />
        ) : (
          <RiderIcon key={k} x={x} y={y} scale={unitScale * 1.75} color={r.color} flip={flip} opacity={unitAlpha} />
        ),
      );
    }
  }

  // Kafilah (jalur dagang): titik bergerak setelah jalur terbentuk
  const caravans: React.ReactNode[] = [];
  if (r.kind === 'trade' && finished) {
    for (let k = 0; k < 4; k++) {
      const s = ((((t - tEnd) * 0.035 + k / 4) % 1) + 1) % 1 * g.total;
      const p = pointAt(g, s);
      caravans.push(<circle key={k} cx={p.x} cy={p.y} r={5 / z} fill="#fff6d8" stroke={r.color} strokeWidth={2 / z} />);
    }
  }
  // Pos yam: titik di setiap pemberhentian yang sudah dicapai
  const stations = r.kind === 'trade'
    ? g.pts.map(([x, y], k) => (t >= g.times[k] ? <rect key={k} x={x - 4 / z} y={y - 4 / z} width={8 / z} height={8 / z} fill={r.color} stroke={SEA} strokeWidth={1.5 / z} /> : null))
    : null;

  const angle = (Math.atan2(head.dy, head.dx) * 180) / Math.PI;
  const showArrow = r.kind === 'campaign' && unitAlpha > 0;
  const tagAlpha = fadeWindow(t, t0, tEnd + 3, 0.5, 0.8);

  return (
    <g opacity={lineAlpha}>
      <path d={d} fill="none" stroke={r.color} strokeOpacity={0.22} strokeWidth={9} vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
      <path
        d={d} fill="none" stroke={r.color} strokeWidth={3.2} vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round"
        strokeDasharray={r.kind === 'trade' ? '10 8' : r.kind === 'naval' ? '4 7' : undefined}
        strokeDashoffset={r.kind === 'trade' ? -t * 30 : undefined}
      />
      {stations}
      {showArrow && (
        <g transform={`translate(${head.x} ${head.y}) rotate(${angle}) scale(${1 / z})`} opacity={unitAlpha}>
          <path d="M6 0 L-12 -8 L-8 0 L-12 8 Z" fill={r.color} stroke={SEA} strokeWidth={1.2} />
        </g>
      )}
      {units}
      {caravans}
      {r.label && tagAlpha > 0.01 && (
        <ScreenText x={head.x} y={head.y} z={z} size={20} fill="#f6ecd2" anchor={r.tag?.anchor ?? 'start'} opacity={tagAlpha * (r.kind === 'trade' ? 0.9 : 1)} weight={600}>
          <tspan x={r.tag?.dx ?? 18} y={r.tag?.dy ?? -26}>{r.label}</tspan>
        </ScreenText>
      )}
    </g>
  );
};

/* -------------------------- Penanda -------------------------- */
const KIND_COLOR = {capital: '#ffe3a1', battle: '#ff7b66', siege: '#ffa45c', event: '#9fd8ff', tribe: '#e8d9b0'} as const;

const MarkerView: React.FC<{m: (typeof MARKERS)[number]; t: number; z: number}> = ({m, t, z}) => {
  const dt = t - m.at;
  if (dt < 0) return null;
  const labelAlpha = fadeWindow(t, m.at, m.at + m.hold, 0.35, 0.6);
  const dotAlpha = m.always ? 1 : clamp01((m.at + m.hold + 4 - t) / 1.5);
  if (labelAlpha <= 0.01 && dotAlpha <= 0.01) return null;
  const [x, y] = project(m.ll);
  const c = KIND_COLOR[m.kind];
  const dx = m.dx ?? 14;
  const dy = m.dy ?? -14;
  const start = (m.anchor ?? 'start') === 'start';
  const w = Math.max(m.label.length * 12.4, (m.sub?.length ?? 0) * 9.8) + 26;
  const h = m.sub ? 54 : 34;
  const rx = start ? dx : dx - w;

  const ringT = dt / 1.6;
  const rings = [0, 0.5].map((off, k) => {
    const p = ringT - off;
    if (p < 0 || p > 1) return null;
    return <circle key={k} cx={0} cy={0} r={6 + 40 * easeOut(p)} fill="none" stroke={c} strokeWidth={2.2} opacity={1 - p} />;
  });

  return (
    <g transform={`translate(${x} ${y}) scale(${1 / z})`}>
      {m.kind !== 'tribe' && rings}
      <g opacity={dotAlpha}>
        {m.kind === 'capital' && <rect x={-7} y={-7} width={14} height={14} transform="rotate(45)" fill={c} stroke={SEA} strokeWidth={2} />}
        {m.kind === 'battle' && (
          <g stroke={c} strokeWidth={3.4} strokeLinecap="round">
            <path d="M-7 -7 L7 7 M7 -7 L-7 7" />
          </g>
        )}
        {(m.kind === 'siege' || m.kind === 'event') && <circle r={6.5} fill={c} stroke={SEA} strokeWidth={2} />}
        {m.kind === 'tribe' && <circle r={3.5} fill={c} opacity={0.9} />}
      </g>
      {labelAlpha > 0.01 && m.kind !== 'tribe' && (
        <g opacity={labelAlpha}>
          <path d={`M0 0 L${dx} ${dy}`} stroke={c} strokeWidth={1.4} opacity={0.8} />
          <rect x={rx} y={dy - h / 2} width={w} height={h} rx={7} fill="rgba(7,13,19,0.86)" stroke={c} strokeWidth={1.4} />
          <text x={rx + 13} y={dy - h / 2 + 23} fontSize={22} fontWeight={700} fill="#fbf0d4" fontFamily="'Helvetica Neue', Helvetica, Arial, sans-serif">{m.label}</text>
          {m.sub && <text x={rx + 13} y={dy - h / 2 + 44} fontSize={17} fill="#c9d3dc" fontFamily="'Helvetica Neue', Helvetica, Arial, sans-serif">{m.sub}</text>}
        </g>
      )}
      {labelAlpha > 0.01 && m.kind === 'tribe' && (
        <g opacity={labelAlpha}>
          <text x={dx} y={dy} textAnchor={start ? 'start' : 'end'} fontSize={23} fontStyle="italic" fontWeight={600} fill="#f1e3bd"
            stroke={SEA} strokeWidth={4} paintOrder="stroke" fontFamily="Georgia, 'Times New Roman', serif">{m.label}</text>
          {m.sub && <text x={dx} y={dy + 19} textAnchor={start ? 'start' : 'end'} fontSize={15} fill="#b9c3cc" stroke={SEA} strokeWidth={3} paintOrder="stroke" fontFamily="'Helvetica Neue', Helvetica, Arial, sans-serif">{m.sub}</text>}
        </g>
      )}
    </g>
  );
};

/* ---------------------------- Peta ---------------------------- */
export const MapScene: React.FC = () => {
  const frame = useGlobalFrame();
  const t = frame / FPS;
  const cam = cameraAt(frame);
  const z = cam.zoom;
  const [cx, cy] = project([cam.lon, cam.lat]);
  const {idx, p} = stageAt(t);
  const stage = STAGES[idx];
  const prev = idx > 0 ? STAGES[idx - 1] : undefined;
  const pe = easeOut(p);

  const drawRegion = (r: RegionDef, s: RegionState, alpha: number, key: string) => {
    const col = OWNER[s.owner].color;
    const d = toPath(r.polygon);
    const pulse = s.owner === 'homeland' ? 0.82 + 0.18 * Math.sin(t * 2.2) : 1;
    return (
      <g key={key} opacity={alpha * pulse}>
        {s.status === 'controlled' && <path d={d} fill={col} fillOpacity={0.5} />}
        {s.status === 'tributary' && (
          <>
            <path d={d} fill={col} fillOpacity={0.12} />
            <path d={d} fill={`url(#hatch-${s.owner})`} />
          </>
        )}
        {s.status === 'occupied' && <path d={d} fill={col} fillOpacity={0.27} />}
        <path
          d={d} fill="none" stroke={col} strokeWidth={s.status === 'occupied' ? 2 : 1.7} vectorEffect="non-scaling-stroke"
          strokeDasharray={s.status === 'occupied' ? '2 5' : s.confidence === 'medium' ? '9 5' : '4 5'} strokeOpacity={0.95}
        />
      </g>
    );
  };

  const regionLayers: React.ReactNode[] = [];
  const labelLayers: React.ReactNode[] = [];
  REGIONS.forEach((r) => {
    const cur = stage.regions[r.id];
    if (!cur) return;
    const before = prev?.regions[r.id];
    if (before && !same(before, cur)) regionLayers.push(drawRegion(r, before, 1 - pe, `${r.id}-prev`));
    regionLayers.push(drawRegion(r, cur, before ? (same(before, cur) ? 1 : pe) : pe, `${r.id}-cur`));

    // Label hanya pada saat wilayah baru saja berubah (agar tidak penuh)
    let li = idx;
    while (li > 0 && !STAGES[li].changed.includes(r.id)) li--;
    const ls = STAGES[li];
    if (!ls.regionLabels || !ls.changed.includes(r.id)) return;
    const a = fadeWindow(t, ls.atSec + 0.4, ls.atSec + 8.5, 0.8, 1.2);
    if (a <= 0.01) return;
    const suffix = cur.status === 'tributary' ? ' · vasal' : cur.status === 'occupied' ? ' · diduduki' : '';
    const [lx, ly] = project(r.labelAt);
    labelLayers.push(
      <ScreenText key={`lab-${r.id}`} x={lx} y={ly} z={z} size={21} fill="#f7ecd0" spacing={1.5} opacity={a}>
        {r.name.toUpperCase() + suffix.toUpperCase()}
      </ScreenText>,
    );
  });

  return (
    <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', inset: 0}}>
      <defs>
        <clipPath id="landclip">
          {LAND_PATHS.map((d, i) => <path key={i} d={d} />)}
        </clipPath>
        {OWNERS.map((o) => (
          <pattern key={o} id={`hatch-${o}`} patternUnits="userSpaceOnUse" width={11 / z} height={11 / z} patternTransform="rotate(45)">
            <line x1={0} y1={0} x2={0} y2={11 / z} stroke={OWNER[o].color} strokeWidth={2.6 / z} strokeOpacity={0.9} />
          </pattern>
        ))}
        <radialGradient id="seaglow" cx="50%" cy="45%" r="75%">
          <stop offset="0%" stopColor="#12283a" />
          <stop offset="100%" stopColor={SEA} />
        </radialGradient>
      </defs>
      <rect width={WIDTH} height={HEIGHT} fill="url(#seaglow)" />

      <g transform={`translate(${WIDTH / 2} ${SCREEN_CY}) scale(${z}) translate(${-cx} ${-cy})`}>
        {/* grid derajat (tipis) */}
        <g stroke="rgba(255,255,255,0.05)" strokeWidth={1} vectorEffect="non-scaling-stroke">
          {Array.from({length: 17}, (_, k) => {
            const [x] = project([-10 + k * 10, 0]);
            return <line key={`v${k}`} x1={x} y1={WORLD.minY} x2={x} y2={WORLD.maxY} vectorEffect="non-scaling-stroke" />;
          })}
          {Array.from({length: 9}, (_, k) => {
            const [, y] = project([0, 70 - k * 10]);
            return <line key={`h${k}`} x1={WORLD.minX} y1={y} x2={WORLD.maxX} y2={y} vectorEffect="non-scaling-stroke" />;
          })}
        </g>

        {LAND_PATHS.map((d, i) => <path key={i} d={d} fill={LAND} stroke={LAND_EDGE} strokeWidth={1.4} vectorEffect="non-scaling-stroke" strokeLinejoin="round" />)}
        <g clipPath="url(#landclip)">{regionLayers}</g>
        {WATERS.map((w) => <path key={w.id} d={toPath(w.polygon)} fill={SEA} stroke={LAND_EDGE} strokeWidth={1.4} vectorEffect="non-scaling-stroke" strokeLinejoin="round" />)}

        {SEA_LABELS.map((s) => {
          const [x, y] = project(s.at);
          return <ScreenText key={s.text} x={x} y={y} z={z} size={17} fill="rgba(150,180,200,0.38)" spacing={5} italic weight={500} font="Georgia, serif">{s.text}</ScreenText>;
        })}
        {WATERS.filter((w) => w.name).map((w) => {
          const [x, y] = project(w.labelAt);
          return <ScreenText key={w.id} x={x} y={y} z={z} size={15} fill="rgba(150,180,200,0.38)" spacing={4} italic weight={500} font="Georgia, serif">{w.name}</ScreenText>;
        })}

        {labelLayers}
        {AREA_LABELS.map((a) => {
          const al = fadeWindow(t, a.at, a.at + a.hold, 0.8, 1.0);
          if (al <= 0.01) return null;
          const [x, y] = project(a.ll);
          return <ScreenText key={a.id} x={x} y={y} z={z} size={27} fill={a.color} spacing={3} opacity={al} weight={800}>{a.text}</ScreenText>;
        })}

        {ROUTES.map((r) => <RouteView key={r.id} r={r} t={t} z={z} />)}
        {MARKERS.map((m) => <MarkerView key={m.id} m={m} t={t} z={z} />)}
      </g>
    </svg>
  );
};
