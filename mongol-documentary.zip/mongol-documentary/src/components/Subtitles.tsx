import React from 'react';
import {FPS} from '../data/scenes';
import {useGlobalFrame} from '../lib/frameContext';
import {ALL_CUES} from '../lib/timing';
import {fadeWindow} from '../lib/anim';

/** Subtitle bahasa Indonesia, disinkronkan ke kalimat narasi (bukan ke batas adegan). */
export const Subtitles: React.FC = () => {
  const t = useGlobalFrame() / FPS;
  const cue = ALL_CUES.find((c) => t >= c.start - 0.08 && t <= c.start + c.dur + 0.4);
  if (!cue) return null;
  const a = fadeWindow(t, cue.start - 0.08, cue.start + cue.dur + 0.4, 0.16, 0.22);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 62, display: 'flex', justifyContent: 'center', opacity: a}}>
      <div
        style={{
          maxWidth: 1480, padding: '12px 30px', borderRadius: 12, background: 'rgba(4,8,12,0.62)', textAlign: 'center',
          fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontWeight: 600, fontSize: cue.text.length > 105 ? 40 : 44, lineHeight: 1.28, color: '#ffffff',
          textShadow: '0 2px 6px rgba(0,0,0,0.9)', textWrap: 'balance' as React.CSSProperties['textWrap'],
        }}
      >
        {cue.text}
      </div>
    </div>
  );
};
