import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {FPS, TOTAL_SEC} from '../data/scenes';
import {LOOPS, MUSIC, MUSIC_FILE, ONE_SHOTS, SFX, toF} from '../data/audioPlan';
import assetStatus from '../data/assetStatus.json';
import {ALL_CUES, HAS_VO} from '../lib/timing';
import {clamp01, lerp} from '../lib/anim';

const duckAmount = (t: number): number => {
  let d = 0;
  for (const c of ALL_CUES) {
    const a = c.start - 0.25;
    const b = c.start + c.dur + 0.3;
    if (t < a - MUSIC.rampSec || t > b + MUSIC.rampSec) continue;
    d = Math.max(d, clamp01((t - a) / MUSIC.rampSec) * clamp01((b - t) / MUSIC.rampSec));
  }
  return d;
};

/** Volume musik per frame: ducking di bawah narasi + fade awal/akhir. */
const musicVolume = (frame: number): number => {
  const t = frame / FPS;
  const level = HAS_VO ? lerp(MUSIC.base, MUSIC.ducked, duckAmount(t)) : MUSIC.noVoBase;
  return level * clamp01(t / MUSIC.fadeIn) * clamp01((TOTAL_SEC - t) / MUSIC.fadeOut);
};

export const AudioTracks: React.FC = () => (
  <>
    {/* Narasi: satu berkas per kalimat, diletakkan tepat pada waktu kalimat */}
    {HAS_VO &&
      ALL_CUES.filter((c) => c.file).map((c) => (
        <Sequence key={`vo-${c.sceneNo}-${c.idx}`} from={toF(c.start)} durationInFrames={toF(c.dur) + 20} name={`VO ${c.sceneNo}.${c.idx}`} layout="none">
          <Audio src={staticFile(c.file as string)} volume={1} />
        </Sequence>
      ))}

    {assetStatus.music && <Audio src={staticFile(MUSIC_FILE)} volume={musicVolume} />}

    {assetStatus.sfx &&
      LOOPS.map((l) => {
        const dur = toF(l.to - l.from);
        const fade = toF(l.fade);
        return (
          <Sequence key={l.id} from={toF(l.from)} durationInFrames={dur} name={`SFX loop ${l.id}`} layout="none">
            <Audio
              src={staticFile(SFX[l.sfx])}
              loop
              volume={(f: number) => l.volume * clamp01(f / Math.max(1, fade)) * clamp01((dur - f) / Math.max(1, fade))}
            />
          </Sequence>
        );
      })}

    {assetStatus.sfx &&
      ONE_SHOTS.map((o) => (
        <Sequence key={o.id} from={toF(o.at)} durationInFrames={toF(5)} name={`SFX ${o.id}`} layout="none">
          <Audio src={staticFile(SFX[o.sfx])} volume={o.volume} />
        </Sequence>
      ))}
  </>
);
