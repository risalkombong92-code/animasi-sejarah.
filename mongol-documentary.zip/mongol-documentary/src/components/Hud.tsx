import React from 'react';
import {FPS, SCENES, TOTAL_SEC} from '../data/scenes';
import type {SceneDef} from '../data/types';
import {OWNER} from '../data/owners';
import {STAGES, stageAt} from '../data/mapStages';
import {NAMEPLATES, RIBBONS} from '../data/events';
import type {NameplateDef, RibbonDef} from '../data/events';
import {useGlobalFrame} from '../lib/frameContext';
import {clamp01, easeOut, fadeWindow} from '../lib/anim';
import {END_CARD_START, S, sceneStart} from '../lib/timing';
import {RiderEmblem, TugEmblem} from './Icons';

const SANS = "'Helvetica Neue', Helvetica, Arial, sans-serif";
const SERIF = "Georgia, 'Times New Roman', serif";
const GOLD = '#f0c35a';
const useT = (): number => useGlobalFrame() / FPS;

/* ------------------ Tanggal & keterangan tahap ------------------ */
export const DateStamp: React.FC = () => {
  const t = useT();
  const {idx} = stageAt(t);
  const st = STAGES[idx];
  const vis = fadeWindow(t, S(2, 1.2), END_CARD_START - 0.2, 1.0, 1.0);
  if (vis <= 0.01) return null;
  const age = idx === 0 ? t - S(2, 1.2) : t - st.atSec;
  const e = easeOut(age / 0.7);
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 1100, height: 460, background: 'radial-gradient(ellipse at 0% 0%, rgba(6,11,16,0.82) 0%, rgba(6,11,16,0.55) 35%, rgba(6,11,16,0) 72%)', opacity: vis}}>
      <div style={{position: 'absolute', left: 64, top: 40, opacity: e, transform: `translateY(${(1 - e) * 14}px)`}}>
        <div style={{fontFamily: SERIF, fontSize: 92, lineHeight: 1, color: GOLD, textShadow: '0 3px 14px rgba(0,0,0,0.7)'}}>{st.dateLabel}</div>
        <div style={{fontFamily: SANS, fontSize: 28, marginTop: 10, color: '#efe6d0', maxWidth: 540, lineHeight: 1.25, textShadow: '0 2px 8px rgba(0,0,0,0.8)'}}>{st.caption}</div>
      </div>
    </div>
  );
};

/* ------------------------- Legenda ------------------------- */
const Row: React.FC<{children: React.ReactNode; sw: React.ReactNode}> = ({children, sw}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 12, height: 29}}>
    <div style={{width: 38, display: 'flex', justifyContent: 'center'}}>{sw}</div>
    <div>{children}</div>
  </div>
);

export const Legend: React.FC = () => {
  const t = useT();
  const {idx} = stageAt(t);
  const vis = fadeWindow(t, S(2, 1.6), END_CARD_START - 0.2, 1.0, 1.0);
  if (vis <= 0.01) return null;
  const owners = Array.from(new Set(Object.values(STAGES[idx].regions).map((s) => s.owner)));
  const c = '#e0b04a';
  return (
    <div style={{position: 'absolute', right: 40, top: 36, width: 360, padding: '14px 18px 12px', borderRadius: 12, background: 'rgba(7,13,19,0.78)', border: '1px solid rgba(240,195,90,0.35)', fontFamily: SANS, fontSize: 18, color: '#dfe6ec', opacity: vis * 0.95}}>
      <div style={{fontSize: 15, letterSpacing: 3, color: GOLD, marginBottom: 6}}>LEGENDA</div>
      <Row sw={<div style={{width: 30, height: 15, background: c, opacity: 0.55, border: `1.5px dashed ${c}`}} />}>Dikuasai langsung</Row>
      <Row sw={<div style={{width: 30, height: 15, background: `repeating-linear-gradient(45deg, ${c} 0 2px, transparent 2px 6px)`, border: `1.5px dashed ${c}`}} />}>Vasal / membayar upeti</Row>
      <Row sw={<div style={{width: 30, height: 15, background: c, opacity: 0.27, border: `1.5px dotted ${c}`}} />}>Diduduki / belum mapan</Row>
      <Row sw={<svg width={34} height={14}><path d="M2 7 L26 7" stroke="#f0c35a" strokeWidth={3} /><path d="M32 7 L24 2 L26 7 L24 12 Z" fill="#f0c35a" /></svg>}>Rute kampanye (sederhana)</Row>
      <Row sw={<svg width={16} height={16}><circle cx={8} cy={8} r={6} fill="#ffa45c" stroke="#0b1620" strokeWidth={2} /></svg>}>Kota / peristiwa</Row>
      {owners.length >= 1 && <div style={{height: 1, background: 'rgba(255,255,255,0.15)', margin: '7px 0'}} />}
      {owners.map((o) => (
        <Row key={o} sw={<div style={{width: 18, height: 18, borderRadius: 4, background: OWNER[o].color, opacity: 0.85}} />}>{OWNER[o].name}</Row>
      ))}
      <div style={{fontSize: 14, color: '#97a6b4', marginTop: 8, lineHeight: 1.3}}>Peta skematis. Garis putus-putus = batas perkiraan.</div>
    </div>
  );
};

/* ---------------------- Judul bab per adegan ---------------------- */
export const ChapterChip: React.FC<{scene: SceneDef}> = ({scene}) => {
  const t = useT();
  const st = sceneStart(scene.no);
  const a = fadeWindow(t, st + 1.4, st + 5.2, 0.6, 0.8);
  if (scene.no === 1 || a <= 0.01) return null;
  return (
    <div style={{position: 'absolute', top: 34, left: 0, right: 0, display: 'flex', justifyContent: 'center', opacity: a, transform: `translateY(${(1 - a) * -10}px)`}}>
      <div style={{fontFamily: SANS, fontSize: 21, letterSpacing: 4, color: '#f2e6c6', padding: '8px 22px', borderRadius: 999, background: 'rgba(7,13,19,0.72)', border: '1px solid rgba(240,195,90,0.4)'}}>
        BAB {String(scene.no).padStart(2, '0')} · {scene.title.toUpperCase()}
      </div>
    </div>
  );
};

/* -------------------------- Pita tanggal -------------------------- */
export const Ribbon: React.FC<{r: RibbonDef}> = ({r}) => {
  const t = useT();
  const a = fadeWindow(t, r.at, r.at + r.dur, 0.45, 0.55);
  if (a <= 0.01) return null;
  const e = easeOut((t - r.at) / 0.5);
  return (
    <div style={{position: 'absolute', top: 104, left: 620, right: 400, display: 'flex', justifyContent: 'center', opacity: a, transform: `translateY(${(1 - e) * -18}px)`}}>
      <div style={{display: 'flex', alignItems: 'baseline', gap: 18, padding: '10px 30px', borderRadius: 10, background: 'linear-gradient(90deg, rgba(7,13,19,0.92), rgba(18,32,44,0.92))', borderLeft: `6px solid ${GOLD}`, boxShadow: '0 6px 24px rgba(0,0,0,0.5)'}}>
        <span style={{fontFamily: SERIF, fontSize: 38, color: GOLD}}>{r.date}</span>
        <span style={{fontFamily: SANS, fontSize: 29, color: '#f6ecd2', fontWeight: 600}}>{r.title}</span>
      </div>
    </div>
  );
};

/* ------------------------- Plakat tokoh ------------------------- */
export const Nameplate: React.FC<{n: NameplateDef}> = ({n}) => {
  const t = useT();
  const a = fadeWindow(t, n.at, n.to, 0.6, 0.7);
  if (a <= 0.01) return null;
  const e = easeOut((t - n.at) / 0.7);
  const Emblem = n.emblem === 'tug' ? TugEmblem : RiderEmblem;
  return (
    <div style={{position: 'absolute', left: 56, bottom: 214 + n.slot * 150, opacity: a, transform: `translateX(${(1 - e) * -70}px)`, display: 'flex', alignItems: 'center', gap: 20, padding: '14px 28px 14px 16px', borderRadius: 14, background: 'rgba(7,13,19,0.86)', border: `1px solid ${n.color}66`, boxShadow: '0 8px 30px rgba(0,0,0,0.55)'}}>
      <Emblem color={n.color} size={92} />
      <div>
        <div style={{fontFamily: SERIF, fontSize: 40, color: '#fbf0d4', lineHeight: 1.05}}>{n.name}</div>
        <div style={{fontFamily: SANS, fontSize: 22, color: '#d6dde3', marginTop: 4}}>{n.role}</div>
        <div style={{fontFamily: SANS, fontSize: 19, color: n.color, marginTop: 3}}>{n.years}</div>
        <div style={{fontFamily: SANS, fontSize: 14, color: '#8796a5', marginTop: 5, fontStyle: 'italic'}}>Lambang simbolis — bukan potret</div>
      </div>
    </div>
  );
};

export const NameplateList: React.FC = () => <>{NAMEPLATES.map((n) => <Nameplate key={n.id} n={n} />)}</>;
export const RibbonList: React.FC = () => <>{RIBBONS.map((r) => <Ribbon key={r.id} r={r} />)}</>;

/* ------------------------ Kartu judul ------------------------ */
export const TitleCard: React.FC = () => {
  const t = useT();
  const a = fadeWindow(t, 0.9, 12.6, 1.6, 1.8);
  if (a <= 0.01) return null;
  const k = 1.04 - 0.04 * clamp01((t - 0.9) / 9);
  return (
    <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: `radial-gradient(ellipse at center, rgba(5,9,14,${0.62 * a}), rgba(5,9,14,0) 70%)`}}>
      <div style={{textAlign: 'center', opacity: a, transform: `scale(${k})`}}>
        <div style={{fontFamily: SANS, fontSize: 24, letterSpacing: 12, color: '#cdbf99', marginBottom: 22}}>DOKUMENTER SEJARAH</div>
        <div style={{fontFamily: SERIF, fontSize: 104, lineHeight: 1.04, letterSpacing: 5, color: '#f6e7bd', textShadow: '0 4px 30px rgba(0,0,0,0.85)'}}>BANGKIT DAN<br />RUNTUHNYA</div>
        <div style={{fontFamily: SERIF, fontSize: 118, lineHeight: 1.08, letterSpacing: 6, color: GOLD, textShadow: '0 4px 30px rgba(0,0,0,0.85)'}}>KEKAISARAN MONGOL</div>
      </div>
    </div>
  );
};

/* ------------------------ Kartu penutup ------------------------ */
export const EndCard: React.FC = () => {
  const t = useT();
  if (t < END_CARD_START) return null;
  const bg = easeOut((t - END_CARD_START) / 2.6) * 0.9;
  const tx = easeOut((t - END_CARD_START - 0.8) / 2.0);
  const fadeOut = clamp01((TOTAL_SEC - t) / 1.2);
  return (
    <div style={{position: 'absolute', inset: 0, background: `rgba(3,6,10,${bg})`, opacity: fadeOut, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{opacity: tx, textAlign: 'center', maxWidth: 1500, transform: `translateY(-70px)`}}>
        <div style={{fontFamily: SERIF, fontSize: 62, letterSpacing: 4, lineHeight: 1.12, color: '#f6e7bd'}}>BANGKIT DAN RUNTUHNYA<br />KEKAISARAN MONGOL</div>
        <div style={{width: 160, height: 2, background: GOLD, margin: '22px auto'}} />
        <div style={{fontFamily: SANS, fontSize: 24, color: '#cfd8df', lineHeight: 1.45}}>
          Peta bersifat skematis. Batas wilayah, rute, dan lokasi bertanda “perkiraan” bukan data kartografi presisi.<br />
          Angka korban dan penyebab yang masih diperdebatkan sejarawan sengaja tidak disajikan sebagai kepastian.
        </div>
        <div style={{fontFamily: SANS, fontSize: 19, color: '#8fa0b0', marginTop: 26, lineHeight: 1.5}}>
          Bacaan untuk verifikasi: D. Morgan, The Mongols · M. Biran, Chinggis Khan · P. Jackson, The Mongols and the West; The Mongols and the Islamic World ·
          T. May, The Mongol Conquests in World History · I. de Rachewiltz (terj.), The Secret History of the Mongols
        </div>
      </div>
    </div>
  );
};

/* ------------------- Vignette & gelembung grain ------------------- */
const GRAIN = Array.from({length: 140}, (_, i) => ({x: (i * 977) % 1920, y: (i * 613) % 1080, r: 0.6 + ((i * 31) % 10) / 12}));
export const Vignette: React.FC = () => {
  const f = useGlobalFrame();
  const j = (f % 3) * 7; // gerak halus deterministik
  return (
    <>
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)', pointerEvents: 'none'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 260, background: 'linear-gradient(0deg, rgba(3,6,10,0.78), rgba(3,6,10,0))'}} />
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0, opacity: 0.07, transform: `translate(${j}px, ${-j}px)`}}>
        {GRAIN.map((g, i) => <circle key={i} cx={g.x} cy={g.y} r={g.r} fill="#fff" />)}
      </svg>
    </>
  );
};
