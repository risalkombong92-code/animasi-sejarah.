# Bangkit dan Runtuhnya Kekaisaran Mongol — proyek Remotion

Dokumenter sejarah **5 menit (300 dtk, 1920×1080, 30 fps, 9000 frame)** berbahasa Indonesia. Satu peta Eurasia yang kontinu menjadi benang merah: kamera, wilayah kronologis, rute pasukan, penanda peristiwa, subtitle, musik, dan efek suara semuanya **dijangkarkan ke kalimat narasi**, sehingga tetap sinkron berapa pun durasi suara aslinya.

## Mulai cepat

```bash
npm install
npm run validate          # cek konsistensi data (kronologi, rute, durasi) — Node ≥ 22.6
npm run studio            # pratinjau interaktif di Remotion Studio
npm run render:draft      # draf cepat setengah resolusi → out/draft.mp4
npm run render            # final → out/bangkit-runtuhnya-kekaisaran-mongol.mp4
```

Musik dan efek suara **sudah disertakan** (`public/audio/`). Voice-over **belum** (butuh internet, lihat di bawah): tanpa suara pun video bisa dirender (subtitle + musik + SFX).

## Menambahkan voice-over pria (Indonesia)

**Otomatis** — suara neural `id-ID-ArdiNeural` (pria):
```bash
pip install edge-tts mutagen
npm run assets:vo         # membuat satu berkas per kalimat + menulis src/data/voiceTimings.ts
npm run check
npm run render
```
Skrip mengukur durasi tiap kalimat; jika sebuah adegan tidak muat, lajunya dipercepat otomatis (maks +18%). Setelah itu subtitle, penanda, rute, tahap peta, dan ducking musik menyesuaikan ke durasi audio asli.

> `edge-tts` memakai layanan online Microsoft Edge. Cek ketentuan penggunaannya sebelum memonetisasi. Untuk produksi komersial pakai Azure AI Speech, ElevenLabs, atau pengisi suara sendiri.

**Rekaman sendiri / TTS lain** — simpan per kalimat sebagai `public/audio/vo/sNN_cMM.mp3` (mis. `s03_c01.mp3` = adegan 3, kalimat ke-2), lalu `npm run assets:vo:measure`. Naskah, panduan pelafalan, dan arahan pengisi suara ada di `docs/naskah.md`.

## Struktur folder

```
src/
  index.ts, Root.tsx, Documentary.tsx   komposisi utama (satu frame global → semua layer)
  data/
    narration.json     ★ SUMBER NARASI (dibaca Remotion, skrip TTS, dan generator dokumen)
    scenes.ts          13 adegan: durasi, kamera, catatan storyboard
    mapStages.ts       tahap wilayah KUMULATIF (hanya delta; tidak ada wilayah "hilang")
    events.ts          penanda, rute (waktu per titik), pita tanggal, plakat tokoh, label
    geo.ts             daratan, perairan, 18 wilayah politik (poligon skematis)
    owners.ts          palet pemilik wilayah
    audioPlan.ts       cue SFX, loop, ducking musik
    voiceTimings.ts    ditulis otomatis oleh skrip suara
  lib/
    timing.ts          T(adegan, kalimat, pecahan) → detik; memakai durasi audio asli bila ada
    camera.ts, geo.ts (proyeksi), anim.ts, frameContext.tsx
  components/          MapScene, Hud (tanggal/legenda/pita/plakat/judul/penutup), Subtitles, AudioTracks, Icons
public/audio/          music/score.mp3 · sfx/*.mp3 · vo/ (diisi skrip suara)
scripts/
  generate_music_sfx.py   musik 300 dtk + 7 SFX, sintesis original (numpy)
  generate_voiceover.py   TTS / pengukuran rekaman → voiceTimings.ts
  validate_data.mjs       validator konsistensi
  export_docs.mjs         → docs/*.md dan out/subtitles.id.srt
  check_assets.mjs        pengecekan aset sebelum render
docs/  naskah.md · storyboard.md · cue_sheet.md · fact_sheet.md
```

## Cara kerja sinkronisasi

Semua waktu dibangun dari `T(adegan, kalimat, pecahan)`. Contoh: penanda Bukhara = `T(5, 2, 0.25)` → "seperempat jalan di kalimat ke-3 adegan 5". Selama suara belum ada, durasi kalimat diestimasi (13,5 karakter/dtk); setelah `voiceTimings.ts` terisi, durasi asli dipakai. Jarak minimum antar tahap peta dan antar pita dijaga otomatis agar tidak bertabrakan. Ini sudah diuji pada kecepatan bicara 13–17 karakter/dtk.

Mengubah narasi? Edit `src/data/narration.json` (jumlah kalimat per adegan sebaiknya tetap, karena visual menjangkar ke indeks kalimat), lalu `npm run validate && npm run export`.

## Apa yang sudah dan belum diverifikasi

| Sudah | Cara |
|---|---|
| Konsistensi data (300 dtk tepat, kronologi, rute, tahap kumulatif, tidak ada tabrakan jadwal) | `npm run validate`; diuji di 4 skenario durasi suara |
| Semua TSX ter-bundle dan lolos type-check (dengan stub tipe) | esbuild + tsc |
| Tampilan 11 frame kunci + sapuan 60 frame tanpa galat/`NaN` | Chromium headless dengan runtime Remotion yang di-mock |
| Musik: peak −3,1 dBFS, aman di mono, kurva energi sesuai dramaturgi | analisis numerik |

| **Belum** | Catatan |
|---|---|
| **Render MP4 dengan Remotion sungguhan** | Tidak ada jaringan/Remotion saat pembuatan. Jalankan `npm run render:draft` lebih dulu. Jika versi paket `@remotion/*` tidak sinkron: `npx remotion upgrade` |
| **Voice-over** | Butuh internet; lihat di atas |
| **Didengar manusia** | Musik/SFX dianalisis angkanya, belum didengarkan. Atur `MUSIC` di `src/data/audioPlan.ts` bila perlu |
| **Verifikasi sejarah oleh ahli** | Lihat `docs/fact_sheet.md` (butir ⚠) |

## Catatan teknis

- **Font:** memakai Georgia/Helvetica dengan fallback sistem. Di Linux pasang `fonts-liberation` agar tampilan konsisten.
- **Waktu render:** 9000 frame; kira-kira 15–40 menit tergantung CPU. Pakai `--concurrency` untuk menyetel.
- **Peta skematis:** bukan data kartografi. Batas wilayah selalu putus-putus dan berlabel perkiraan.
- **Lisensi audio:** musik dan SFX dihasilkan oleh skrip ini (original). Voice-over mengikuti lisensi penyedia TTS yang Anda pilih.
