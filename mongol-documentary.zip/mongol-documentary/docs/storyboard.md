# Storyboard — per adegan

Satu peta Eurasia yang kontinu menjadi benang merah: kamera bergerak antar-adegan tanpa pemotongan (travel 1,5 dtk di awal tiap adegan). Semua elemen visual dijangkarkan ke kalimat narasi.

## 1. Pembuka

| | |
|---|---|
| Waktu | 00:00.0–00:15.0 (15 dtk) |
| Tujuan | Hook visual dan pertanyaan besar: bagaimana kekuatan sebesar ini bangkit lalu runtuh? |
| Visual | Peta Eurasia skematis dari jauh, perlahan mendekat ke Mongolia. Kartu judul muncul di tengah. |
| Teks layar | BANGKIT DAN RUNTUHNYA KEKAISARAN MONGOL |
| Kamera | (85°B, 45°U, zoom 0.62) → (100°B, 47°U, zoom 0.9) |
| Transisi | Dorongan kamera (push-in) ke stepa Mongolia. |
| Suara | Drone rendah mengembang, satu benturan dalam saat judul, angin tipis. |
| Catatan sumber | Klaim "kekaisaran darat menyambung terbesar" lazim dalam literatur (mis. Morgan, The Mongols; May, The Mongol Conquests in World History). |

## 2. Stepa yang Terpecah

| | |
|---|---|
| Waktu | 00:15.0–00:35.0 (20 dtk) |
| Tujuan | Menetapkan konteks: Mongolia sebelum persatuan. |
| Visual | Zoom ke dataran tinggi Mongolia; label suku muncul satu per satu sesuai penyebutan (lokasi perkiraan). |
| Teks layar | c. 1200 — Suku-suku stepa belum bersatu |
| Kamera | (100°B, 47°U, zoom 1.3) → (103°B, 47.5°U, zoom 1.6) |
| Transisi | Camera travel dari Eurasia ke Mongolia. |
| Suara | Angin stepa, pad rendah minimal, tanpa perkusi. |
| Catatan sumber | Secret History of the Mongols (terj. de Rachewiltz); Morgan, The Mongols. Lokasi suku bersifat perkiraan. |

## 3. Temüjin Menjadi Jenghis Khan

| | |
|---|---|
| Waktu | 00:35.0–00:55.0 (20 dtk) |
| Tujuan | Titik awal: persatuan Mongol dan reorganisasi militer. |
| Visual | Mongolia terisi warna emas saat kurultai; kartu tokoh Jenghis Khan (ilustrasi simbolis). |
| Teks layar | 1206 — Kurultai: Temüjin menjadi Jenghis Khan |
| Kamera | (103°B, 47.5°U, zoom 1.6) → (109°B, 48°U, zoom 2.2) |
| Transisi | Dorongan lebih dekat; wilayah Mongolia menyala. |
| Suara | Denyut frame-drum pertama (sangat pelan), pad naik. |
| Catatan sumber | Secret History; Biran, Chinggis Khan (2007). Tahun lahir Temüjin diperdebatkan, sehingga tidak ditampilkan. |

## 4. Ke Tiongkok dan Asia Tengah

| | |
|---|---|
| Waktu | 00:55.0–01:15.0 (20 dtk) |
| Tujuan | Ekspansi pertama: Xia Barat, Jin, Kara Khitai. |
| Visual | Panah kampanye ke Zhongdu, lalu ke barat ke Kara Khitai; pasukan berkuda bergerak. |
| Teks layar | 1211–1215 Perang Jin · 1218 Kara Khitai |
| Kamera | (108°B, 43°U, zoom 1.25) → (95°B, 44°U, zoom 1) |
| Transisi | Pan kamera ke barat mengikuti rute. |
| Suara | Perkusi rendah mulai berdenyut, derap kuda tipis. |
| Catatan sumber | Morgan; Jackson, The Mongols and the Islamic World. Rute disederhanakan. |

## 5. Perang Khwarazmia

| | |
|---|---|
| Waktu | 01:15.0–01:45.0 (30 dtk) |
| Tujuan | Kampanye paling dramatis; angka korban sengaja tidak disebut. |
| Visual | Rute Altai–Otrar–Bukhara–Samarkand–Merv–Nishapur; kota ditandai saat disebut. |
| Teks layar | 1219–1221 Kampanye Khwarazmia |
| Kamera | (75°B, 42°U, zoom 1.2) → (68°B, 40°U, zoom 1.5) |
| Transisi | Kamera mendekat ke Asia Tengah. |
| Suara | Perkusi mantap, string rendah; musik menipis di kalimat terakhir. |
| Catatan sumber | Juvaini, Tarikh-i Jahangushay; Jackson 2017. Jumlah korban diperdebatkan; rute disederhanakan (beberapa pasukan bergerak terpisah). |

## 6. Penerus Sang Khan

| | |
|---|---|
| Waktu | 01:45.0–02:05.0 (20 dtk) |
| Tujuan | Suksesi dan konsolidasi: Ögedei, runtuhnya Jin, Karakorum. |
| Visual | Tampilan luas Asia Timur; Xia Barat dan Jin berubah menjadi wilayah dikuasai; Karakorum ditandai. |
| Teks layar | 1227 Wafatnya Jenghis Khan · 1234 Jin runtuh |
| Kamera | (90°B, 43°U, zoom 0.9) → (95°B, 42°U, zoom 0.8) |
| Transisi | Zoom-out ke tampilan Asia. |
| Suara | Perkusi mereda, pad berkabung ringan, lalu kembali naik. |
| Catatan sumber | Morgan; Biran. Lokasi wafat Jenghis Khan diperdebatkan sehingga tidak ditandai. |

## 7. Menuju Eropa

| | |
|---|---|
| Waktu | 02:05.0–02:30.0 (25 dtk) |
| Tujuan | Ekspansi ke barat: Rus, Polandia, Hungaria. |
| Visual | Rute Batu Khan dan Subutai ke Ryazan, Vladimir, Kyiv, lalu cabang Legnica dan Mohi. |
| Teks layar | 1237–1242 Invasi Rus dan Eropa Tengah |
| Kamera | (42°B, 51°U, zoom 1) → (28°B, 50°U, zoom 1.3) |
| Transisi | Pan cepat ke barat. |
| Suara | Tempo naik, drum bertenaga, derap kuda. |
| Catatan sumber | Jackson, The Mongols and the West. Penyebab mundur 1242 diperdebatkan. |

## 8. Baghdad dan Ain Jalut

| | |
|---|---|
| Waktu | 02:30.0–02:50.0 (20 dtk) |
| Tujuan | Puncak ekspansi ke barat daya dan batasnya. |
| Visual | Hulagu menuju Baghdad; pasukan Mongol dan Mamluk bertemu di Ain Jalut; kamera bergeser ke timur. |
| Teks layar | 1258 Baghdad · 1260 Ain Jalut |
| Kamera | (44°B, 34.5°U, zoom 1.5) → (42°B, 34°U, zoom 1.55) → (95°B, 38°U, zoom 0.85) |
| Transisi | Kamera menyapu ke timur menuju Asia Timur. |
| Suara | Benturan dalam saat Baghdad, jeda hening singkat sebelum Ain Jalut. |
| Catatan sumber | Jackson 2017; Morgan. Kekhalifahan Abbasiyah berlanjut simbolis di Kairo, maka narasi dibatasi "di kota itu". |

## 9. Kubilai dan Dinasti Yuan

| | |
|---|---|
| Waktu | 02:50.0–03:15.0 (25 dtk) |
| Tujuan | Puncak di Tiongkok dan batas kekuatan maritim. |
| Visual | Tiongkok jatuh ke Yuan; armada ke Jepang dan Jawa berakhir tanpa penaklukan. |
| Teks layar | 1271 Yuan · 1279 Song Selatan · 1274/1281 Jepang · 1293 Jawa |
| Kamera | (100°B, 30°U, zoom 0.9) → (116°B, 26°U, zoom 0.82) → (118°B, 25°U, zoom 0.8) → (116°B, 9.2°U, zoom 0.72) → (116°B, 9°U, zoom 0.72) |
| Transisi | Kamera fokus ke Jepang lebih dulu, lalu turun ke selatan mengikuti armada ke Jawa. |
| Suara | Pad mengangkat, perkusi sedang; musik meredup saat ekspedisi gagal. |
| Catatan sumber | Morgan; Biran. Ekspedisi Jawa 1293 berkaitan dengan berdirinya Majapahit; rute laut dan pendaratan (Tuban) perkiraan. |

## 10. Jalur Sutra dan Pos Yam

| | |
|---|---|
| Waktu | 03:15.0–03:35.0 (20 dtk) |
| Tujuan | Sisi lain kekaisaran: konektivitas. |
| Visual | Dua jalur dagang menyala di seluruh Eurasia, kafilah bergerak; Kaffa ditandai. |
| Teks layar | c. 1300 — Pax Mongolica (istilah modern) |
| Kamera | (85°B, 40°U, zoom 0.62) → (75°B, 41°U, zoom 0.66) |
| Transisi | Zoom-out ke Eurasia utuh. |
| Suara | Petikan lembut, pad terang, perkusi minimal. |
| Catatan sumber | Jackson 2017; Cambridge History of Inner Asia: The Chinggisid Age. Hubungan jalur dagang dan Maut Hitam bersifat perkiraan/diperdebatkan. |

## 11. Empat Wilayah (Ulus)

| | |
|---|---|
| Waktu | 03:35.0–04:00.0 (25 dtk) |
| Tujuan | Menjelaskan fragmentasi sebagai proses bertahap. |
| Visual | Warna wilayah berganti menjadi empat ulus; label muncul berurutan. |
| Teks layar | Yuan · Ilkhanat · Chagatai · Golden Horde |
| Kamera | (80°B, 43°U, zoom 0.64) → (78°B, 44°U, zoom 0.66) |
| Transisi | Warna menyebar (crossfade) tanpa memotong peta. |
| Suara | Tegangan rendah, drone menahan, ritme hilang. |
| Catatan sumber | Biran; Cambridge History of Inner Asia. Batas empat ulus bersifat perkiraan; Chagatai–Ögedeid berkonflik hingga c. 1300. |

## 12. Keruntuhan yang Bertahap

| | |
|---|---|
| Waktu | 04:00.0–04:30.0 (30 dtk) |
| Tujuan | Keruntuhan sebagai proses panjang dan majemuk. |
| Visual | Ilkhanat terpecah, Yuan jatuh ke Ming, Golden Horde melemah; peta berubah bertahap. |
| Teks layar | 1335 · 1368 · 1395 · 1480 |
| Kamera | (80°B, 43°U, zoom 0.64) → (80°B, 45°U, zoom 0.62) |
| Transisi | Warna wilayah memudar menjadi abu-abu penerus. |
| Suara | String rendah jarang, perkusi hilang, ruang hening. |
| Catatan sumber | Jackson; Biran. Tanggal 1480 adalah tonggak tradisional "berakhirnya kuk Tatar". Lokasi Sungai Terek dan Ugra perkiraan. |

## 13. Warisan

| | |
|---|---|
| Waktu | 04:30.0–05:00.0 (30 dtk) |
| Tujuan | Penutup berimbang: luka dan warisan. |
| Visual | Kamera ke India utara (Babur, Panipat 1526), lalu menjauh ke peta utuh; kartu penutup. |
| Teks layar | Peta skematis — batas wilayah bersifat perkiraan |
| Kamera | (78°B, 42°U, zoom 0.64) → (75°B, 36°U, zoom 1) → (75°B, 36°U, zoom 1) → (80°B, 43°U, zoom 0.58) |
| Transisi | Fade ke hitam. |
| Suara | Pad mayor-ringan, resolusi lembut, memudar menjadi hening. |
| Catatan sumber | Klaim keturunan Babur dari Timur dan (lewat garis ibu) Jenghis Khan lazim dalam literatur Mughal. |

## Tahap peta kronologis

| Waktu | Tanggal | Perubahan |
|---|---|---|
| 00:00.0 | c. 1200 | Suku-suku stepa Mongolia belum bersatu |
| 00:45.7 | 1206 | Temüjin menjadi Jenghis Khan — Ulus Mongol bersatu |
| 00:56.5 | 1209–1215 | Xia Barat menjadi vasal; Jin utara diduduki |
| 01:06.4 | 1218 | Kara Khitai ditaklukkan |
| 01:30.2 | 1220 | Bukhara dan Samarkand jatuh — Transoksiana dikuasai |
| 01:32.4 | 1221 | Merv dan Nishapur jatuh — Khorasan diduduki |
| 01:49.3 | 1227 | Jenghis Khan wafat; Xia Barat dihancurkan |
| 01:56.8 | 1234 | Dinasti Jin runtuh; Manchuria dikuasai (1233) |
| 02:12.5 | 1236–1240 | Stepa Kipchak dikuasai; kepangeranan Rus menjadi vasal |
| 02:31.2 | 1243–1256 | Persia barat dan Kaukasus dikuasai; Rum (Seljuk) menjadi vasal (1243) |
| 02:36.4 | 1258 | Baghdad direbut Hulagu |
| 02:47.2 | 1253–1259 | Di bawah Möngke Khan: Yunnan (1253), Tibet dan Korea (1259) tunduk |
| 03:00.9 | 1279 | Song Selatan jatuh — seluruh Tiongkok di bawah Yuan |
| 03:15.3 | c. 1300 | Pax Mongolica: jalur dagang Eurasia |
| 03:43.1 | c. 1300–1310 | Terpecah bertahap menjadi empat wilayah utama |
| 04:06.0 | 1335 | Ilkhanat terpecah menjadi negara-negara kecil |
| 04:11.2 | 1368 | Yuan terusir dari Beijing oleh Ming; Korea dan Tibet lepas |
| 04:17.7 | 1395 | Timur menguasai Asia Tengah dan Iran timur; Chagatai terpecah |
| 04:22.0 | 1480 | Golden Horde terpecah; Moskow lepas dari Horde |

## Penanda & pita peristiwa

| Waktu | Peristiwa |
|---|---|
| 00:44.1 | Kurultai, 1206 — dekat hulu Sungai Onon (perkiraan) |
| 00:44.7 | **Pita:** 1206 Kurultai: Temüjin menjadi Jenghis Khan |
| 01:02.1 | **Pita:** 1215 Zhongdu (Beijing) direbut |
| 01:02.4 | Zhongdu (Beijing) — direbut 1215 |
| 01:07.2 | Balasagun — Kara Khitai, 1218 |
| 01:24.6 | **Pita:** c. 1218 Insiden Otrar |
| 01:27.5 | Otrar — c. 1218 |
| 01:29.9 | Bukhara — 1220 |
| 01:30.8 | Samarkand — 1220 |
| 01:31.8 | Merv — 1221 |
| 01:32.7 | Nishapur — 1221 |
| 01:46.3 | **Pita:** 1227 Wafatnya Jenghis Khan |
| 01:59.3 | Karakorum — pusat pemerintahan (dibangun 1230-an) |
| 02:08.9 | Ryazan — Des 1237 |
| 02:10.1 | Vladimir — Feb 1238 |
| 02:12.2 | Kyiv — Des 1240 |
| 02:13.3 | **Pita:** 1241 Legnica dan Mohi |
| 02:16.2 | Legnica — 9 Apr 1241 |
| 02:16.7 | Mohi — 11 Apr 1241 |
| 02:18.1 | **Pita:** 1242 Mongol mundur dari Hungaria |
| 02:33.7 | **Pita:** 1258 Jatuhnya Baghdad |
| 02:35.5 | Baghdad — Februari 1258 |
| 02:41.3 | **Pita:** 1260 Pertempuran Ain Jalut |
| 02:44.4 | Ain Jalut — 3 September 1260 |
| 02:57.5 | **Pita:** 1271 Dinasti Yuan berdiri |
| 02:58.5 | Dadu (Beijing) — ibu kota Yuan, 1271 |
| 03:00.7 | **Pita:** 1279 Song Selatan jatuh |
| 03:01.0 | Yamen — 1279 |
| 03:05.5 | Teluk Hakata — 1274 dan 1281 |
| 03:09.1 | Jawa (Tuban) — 1293 · ekspedisi gagal |
| 03:16.8 | **Pita:** c. 1300 Pax Mongolica (istilah modern) |
| 03:31.6 | Kaffa (Feodosia) — 1346 · dikaitkan dengan wabah |
| 04:05.7 | **Pita:** 1335 Ilkhanat terpecah |
| 04:10.4 | **Pita:** 1368 Yuan terusir dari Dadu (Beijing) |
| 04:10.6 | Dadu direbut Ming — 1368 |
| 04:16.0 | **Pita:** 1395 Timur mengalahkan Tokhtamysh |
| 04:16.7 | Sungai Terek — 1395 (lokasi perkiraan) |
| 04:21.0 | **Pita:** 1480 Moskow lepas dari kekuasaan Horde |
| 04:21.5 | Sungai Ugra — 1480 (lokasi perkiraan) |
| 04:50.5 | Panipat — 1526 · Babur |
