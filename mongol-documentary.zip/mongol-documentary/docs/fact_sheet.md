# Lembar fakta & verifikasi

Setiap klaim di narasi dan peta tercatat di sini beserta tingkat keyakinannya. **Pemeriksaan ini berasal dari pengetahuan penulis, bukan dari penelusuran sumber primer pada saat pembuatan.** Sebelum dipublikasikan, verifikasi butir bertanda ⚠ dengan bacaan di bagian bawah.

Legenda: ✔ konsensus luas · ◐ konsensus dengan nuansa · ⚠ diperdebatkan/perkiraan

## Kronologi

| Tahun | Klaim di video | Status | Catatan |
|---|---|---|---|
| c. 1200 | Suku Mongol, Tatar, Kereyid, Naiman bersaing di stepa | ✔ | **Lokasi suku di peta ⚠ perkiraan** (dilabeli "lokasi perkiraan") |
| 1206 | Kurultai menobatkan Temüjin sebagai Jenghis Khan | ✔ | Lokasi "dekat hulu Sungai Onon" ⚠ tradisi; dilabeli perkiraan. **Tahun lahir Temüjin sengaja tidak disebut** (1155/1162/1167 diperdebatkan) |
| 1206 | Pasukan ditata dalam puluhan, ratusan, ribuan | ✔ | Juga puluhan ribu (tümen); narasi menyederhanakan |
| 1209 | Xia Barat menjadi vasal | ✔ | Ditampilkan di tahap "1209–1215" |
| 1211–1215 | Serangan ke Jin; Zhongdu (kini Beijing) direbut 1215 | ✔ | Zhongdu berada di sekitar Beijing modern |
| 1218 | Kara Khitai jatuh | ✔ | Ditaklukkan pasukan Jebe |
| c. 1218 | Kafilah dagang Mongol dibantai di Otrar | ◐ | Rincian (kafilah vs utusan, motif gubernur) bervariasi antarsumber |
| 1219–1221 | Bukhara, Samarkand, Merv, Nishapur jatuh | ✔ | Bukhara & Samarkand 1220; Merv & Nishapur 1221. **Rute di peta ⚠ disederhanakan** (beberapa pasukan bergerak terpisah) |
| — | "Korban jiwa sangat besar, angka pastinya diperdebatkan" | ✔ | Sengaja **tidak** menyebut angka; estimasi sumber abad pertengahan sering dianggap berlebihan |
| 1227 | Jenghis Khan wafat saat kampanye Xia Barat | ✔ | **Lokasi/penyebab wafat ⚠ diperdebatkan**, tidak ditandai di peta |
| 1229 | Ögedei terpilih khagan | ✔ | |
| 1233–1234 | Jin runtuh 1234 | ✔ | Manchuria (1233) ikut diwarnai |
| 1230-an | Karakorum menjadi pusat pemerintahan | ◐ | Tembok dibangun c. 1235 |
| 1236–1240 | Kipchak dikuasai; Rus menjadi vasal | ◐ | Batas wilayah ⚠ perkiraan |
| 1237–1238 | Ryazan (Des 1237), Vladimir (Feb 1238) | ✔ | |
| 1240 | Kyiv jatuh (akhir 1240) | ✔ | Desember 1240 |
| 1241 | Legnica (9 Apr), Mohi (11 Apr) | ✔ | |
| 1242 | Mundur dari Hungaria | ✔ | **Penyebabnya ⚠ diperdebatkan** — narasi menyebutkan itu |
| 1243 | Rum (Seljuk) menjadi vasal | ✔ | Pertempuran Köse Dağ |
| 1253–1259 | Yunnan (Dali) 1253; Tibet, Korea (1259) tunduk | ◐ | Tibet: hubungan bertahap sejak 1240-an; status "vasal" ⚠ perkiraan |
| 1258 | Baghdad direbut Hulagu; kekhalifahan Abbasiyah berakhir "di kota itu" | ✔ | Garis Abbasiyah berlanjut simbolis di Kairo — makanya frasa dibatasi |
| 1260 | Ain Jalut (3 Sep): Mamluk mengalahkan pasukan Mongol | ✔ | Pasukan Mongol di sana relatif kecil (Hulagu telah pergi). Rute Mongol 1260 ⚠ disederhanakan |
| 1260 | Kubilai naik takhta setelah berebut kuasa dengan adiknya | ✔ | Ariq Böke |
| 1271 / 1279 | Yuan berdiri / Song Selatan jatuh | ✔ | Yamen 1279 |
| 1274, 1281, 1293 | Ekspedisi Jepang dan Jawa gagal | ✔ | Jawa 1293 berkaitan dengan berdirinya Majapahit; **rute laut & titik pendaratan (Tuban) ⚠ perkiraan** |
| c. 1300 | Pos yam; Jalur Sutra relatif aman | ◐ | "Pax Mongolica" adalah istilah modern (dilabeli). Jalur di peta ⚠ disederhanakan |
| 1340-an | Jalur dagang "dikaitkan" dengan wabah pes | ⚠ | Peran jalur dan kisah Kaffa 1346 diperdebatkan — wording sengaja hati-hati |
| c. 1300–1310 | Empat wilayah utama | ◐ | Perpecahan bertahap sejak 1260; **batas empat ulus ⚠ perkiraan**; Chagatai–Ögedeid berkonflik hingga c. 1300 |
| 1335 | Ilkhanat terpecah | ✔ | Wafatnya Abu Said tanpa pewaris |
| 1368 | Yuan terusir dari Beijing oleh Ming | ✔ | Yuan Utara bertahan di Mongolia. Korea & Tibet digambar "lepas" ⚠ penyederhanaan |
| 1395 | Timur mengalahkan Tokhtamysh | ✔ | Sungai Terek: **lokasi ⚠ perkiraan** |
| 1480 | Moskow lepas dari Horde | ◐ | Tonggak **tradisional** (Ugra); proses lepas bertahap — narasi memakai "secara tradisional" |
| 1526 | Babur mendirikan Mughal; mengklaim keturunan Timur dan Jenghis Khan | ✔ | Keturunan Jenghis Khan lewat garis ibu |

## Kebijakan penyajian

- **Tidak ada kutipan yang diatribusikan** kepada tokoh sejarah.
- **Tidak ada potret/wajah** tokoh: plakat memakai lambang simbolis (panji/penunggang) dan diberi keterangan "bukan potret".
- **Tidak ada angka korban.** Narasi menyatakan bahwa angka diperdebatkan.
- **Peta skematis:** garis pantai digambar tangan; batas politik digambar putus-putus; wilayah dipotong ke daratan; tidak ada batas negara modern.
- **Satu kalimat netral** untuk dua sisi: luka (korban) dan warisan (konektivitas) disebut berimbang di penutup.

## Bacaan untuk verifikasi

- David Morgan, *The Mongols* (Blackwell)
- Michal Biran, *Chinggis Khan* (Oneworld)
- Peter Jackson, *The Mongols and the West*; *The Mongols and the Islamic World*
- Timothy May, *The Mongol Conquests in World History*
- Igor de Rachewiltz (terj.), *The Secret History of the Mongols*
- *The Cambridge History of Inner Asia: The Chinggisid Age*
- Juvaini, *Tarikh-i Jahangushay*; Rashid al-Din, *Jami' al-tawarikh* (sumber primer Persia)
