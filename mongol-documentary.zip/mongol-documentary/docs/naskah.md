# Naskah — Bangkit dan Runtuhnya Kekaisaran Mongol

Durasi: **5 menit** (300 dtk) · 13 adegan · ±465 kata narasi · bahasa Indonesia

> Waktu per kalimat di berkas ini **ESTIMASI** (suara belum dibuat); akan berubah setelah `npm run assets:vo`.

## Arahan pengisi suara (pria, gaya dokumenter)

- Rentang suara bariton, hangat, tidak berteriak; laju ±100–110 kata/menit termasuk jeda.
- Jeda ±0,4 dtk antarkalimat; jeda lebih panjang setelah angka tahun penting.
- Jangan mendramatisasi korban jiwa; nada tetap faktual dan tenang.
- Ketidakpastian ("diperdebatkan", "perkiraan") dibacakan datar, bukan sebagai keraguan pembicara.

## Panduan pelafalan

| Tulisan | Dilafalkan |
|---|---|
| Temüjin | te-mu-jin |
| Ögedei | ö-ge-dei (≈ "ugedei") |
| Jenghis Khan | jeng-gis kan |
| Khwarazmia | kwa-raz-mi-a |
| Zhongdu | jung-du |
| Kyiv | ki-ev |
| Legnica | leg-ni-tsa |
| Mohi | mo-hi |
| Nishapur | ni-sya-pur |
| Kubilai | ku-bi-lai |
| Ilkhanat | il-ka-nat |
| Chagatai | ca-ga-tai |

## Naskah per adegan

### 1. Pembuka  
*00:00.0–00:15.0 · 15 dtk · c. 1200–1500-an*

_Arahan:_ Tenang, berat, spasi lebar. Jeda 1 dtk setelah kalimat pertama.

1. Dari padang rumput Mongolia, lahir kekaisaran darat berwilayah menyambung terbesar dalam sejarah.  
   <sub>berkas `s01_c00.mp3` · 00:00.6 · 7.2 dtk</sub>
2. Inilah kisah kebangkitan, kejayaan, dan keruntuhan Kekaisaran Mongol.  
   <sub>berkas `s01_c01.mp3` · 00:08.2 · 5.1 dtk</sub>

### 2. Stepa yang Terpecah  
*00:15.0–00:35.0 · 20 dtk · c. 1200*

_Arahan:_ Reflektif, datar, mengamati.

1. Sekitar tahun 1200, stepa Mongolia dihuni suku-suku penggembala yang saling bersaing: Mongol, Tatar, Kereyid, dan Naiman.  
   <sub>berkas `s02_c00.mp3` · 00:15.6 · 9.0 dtk</sub>
2. Mereka hidup berpindah bersama ternak, dan sering berperang.  
   <sub>berkas `s02_c01.mp3` · 00:25.0 · 4.4 dtk</sub>
3. Belum ada negara tunggal yang menyatukan mereka.  
   <sub>berkas `s02_c02.mp3` · 00:29.8 · 3.6 dtk</sub>

### 3. Temüjin Menjadi Jenghis Khan  
*00:35.0–00:55.0 · 20 dtk · 1206*

_Arahan:_ Mantap, sedikit lebih hangat; tekankan "1206".

1. Seorang pemimpin muda, Temüjin, menyatukan suku-suku itu lewat aliansi dan perang.  
   <sub>berkas `s03_c00.mp3` · 00:35.6 · 6.1 dtk</sub>
2. Pada 1206, majelis para pemimpin yang disebut kurultai menobatkannya sebagai Jenghis Khan.  
   <sub>berkas `s03_c01.mp3` · 00:42.1 · 6.7 dtk</sub>
3. Pasukannya ditata dalam satuan puluhan, ratusan, dan ribuan.  
   <sub>berkas `s03_c02.mp3` · 00:49.1 · 4.4 dtk</sub>

### 4. Ke Tiongkok dan Asia Tengah  
*00:55.0–01:15.0 · 20 dtk · 1209–1218*

_Arahan:_ Lebih cepat sedikit, tegas.

1. Mulai 1211, Mongol menyerang Dinasti Jin di Tiongkok utara, dan pada 1215 merebut ibu kotanya, Zhongdu, kini Beijing.  
   <sub>berkas `s04_c00.mp3` · 00:55.6 · 8.7 dtk</sub>
2. Tiga tahun kemudian, Kara Khitai di Asia Tengah pun jatuh.  
   <sub>berkas `s04_c01.mp3` · 01:04.7 · 4.3 dtk</sub>
3. Mobilitas pasukan berkuda menjadi salah satu kuncinya.  
   <sub>berkas `s04_c02.mp3` · 01:09.4 · 4.0 dtk</sub>

### 5. Perang Khwarazmia  
*01:15.0–01:45.0 · 30 dtk · 1218–1221*

_Arahan:_ Serius dan terkendali; kalimat terakhir lambat, tanpa dramatisasi.

1. Babak berikutnya adalah Khwarazmia, kekuatan besar di Asia Tengah dan Iran.  
   <sub>berkas `s05_c00.mp3` · 01:15.6 · 5.6 dtk</sub>
2. Setelah kafilah dagang Mongol dibantai di kota Otrar, sekitar 1218, Jenghis Khan menyerang.  
   <sub>berkas `s05_c01.mp3` · 01:21.6 · 6.7 dtk</sub>
3. Antara 1219 dan 1221, Bukhara, Samarkand, Merv, dan Nishapur jatuh.  
   <sub>berkas `s05_c02.mp3` · 01:28.7 · 5.0 dtk</sub>
4. Kerusakan dan korban jiwa sangat besar, dan angka pastinya masih diperdebatkan.  
   <sub>berkas `s05_c03.mp3` · 01:34.1 · 5.9 dtk</sub>

### 6. Penerus Sang Khan  
*01:45.0–02:05.0 · 20 dtk · 1227–1234*

_Arahan:_ Datar-formal, sedikit melambat.

1. Jenghis Khan wafat pada 1227, saat kampanye melawan Xia Barat.  
   <sub>berkas `s06_c00.mp3` · 01:45.6 · 4.6 dtk</sub>
2. Putranya, Ögedei, terpilih sebagai khagan, atau khan agung, pada 1229.  
   <sub>berkas `s06_c01.mp3` · 01:50.6 · 5.2 dtk</sub>
3. Dinasti Jin runtuh pada 1234, dan Karakorum menjadi pusat pemerintahan.  
   <sub>berkas `s06_c02.mp3` · 01:56.2 · 5.3 dtk</sub>

### 7. Menuju Eropa  
*02:05.0–02:30.0 · 25 dtk · 1236–1242*

_Arahan:_ Energik terukur; kalimat terakhir jujur soal ketidakpastian.

1. Di barat, Batu Khan dan Subutai menyerbu wilayah Rus mulai 1237.  
   <sub>berkas `s07_c00.mp3` · 02:05.6 · 4.7 dtk</sub>
2. Kyiv jatuh pada akhir 1240.  
   <sub>berkas `s07_c01.mp3` · 02:10.7 · 2.0 dtk</sub>
3. Pada April 1241, Mongol menang di Legnica dan Mohi.  
   <sub>berkas `s07_c02.mp3` · 02:13.1 · 3.8 dtk</sub>
4. Mereka mundur dari Hungaria pada 1242; peran wafatnya Ögedei dalam keputusan itu masih diperdebatkan.  
   <sub>berkas `s07_c03.mp3` · 02:17.3 · 7.5 dtk</sub>

### 8. Baghdad dan Ain Jalut  
*02:30.0–02:50.0 · 20 dtk · 1258–1260*

_Arahan:_ Berat pada Baghdad, lalu jeda sebelum Ain Jalut.

1. Pada 1258, pasukan Hulagu merebut Baghdad dan mengakhiri kekhalifahan Abbasiyah di kota itu.  
   <sub>berkas `s08_c00.mp3` · 02:30.6 · 6.8 dtk</sub>
2. Dua tahun kemudian, di Ain Jalut, pasukan Mamluk Mesir mengalahkan pasukan Mongol dan menahan kemajuan mereka ke Mesir.  
   <sub>berkas `s08_c01.mp3` · 02:37.8 · 8.8 dtk</sub>

### 9. Kubilai dan Dinasti Yuan  
*02:50.0–03:15.0 · 25 dtk · 1260–1293*

_Arahan:_ Mantap, lalu nada "namun" yang dingin.

1. Cucu Jenghis Khan, Kubilai, naik takhta pada 1260 setelah berebut kuasa dengan adiknya.  
   <sub>berkas `s09_c00.mp3` · 02:50.6 · 6.4 dtk</sub>
2. Ia mendirikan Dinasti Yuan pada 1271, dan Song Selatan jatuh pada 1279.  
   <sub>berkas `s09_c01.mp3` · 02:57.4 · 5.3 dtk</sub>
3. Namun ekspedisi lautnya ke Jepang pada 1274 dan 1281, serta ke Jawa pada 1293, gagal.  
   <sub>berkas `s09_c02.mp3` · 03:03.1 · 6.3 dtk</sub>

### 10. Jalur Sutra dan Pos Yam  
*03:15.0–03:35.0 · 20 dtk · c. 1300*

_Arahan:_ Lebih ringan dan mengalir.

1. Sistem pos berkuda, yam, menghubungkan wilayah yang luas itu.  
   <sub>berkas `s10_c00.mp3` · 03:15.6 · 4.5 dtk</sub>
2. Jalur Sutra relatif aman bagi pedagang dan utusan, sehingga barang, gagasan, dan teknologi berpindah.  
   <sub>berkas `s10_c01.mp3` · 03:20.5 · 7.5 dtk</sub>
3. Jalur yang sama juga dikaitkan dengan penyebaran wabah pes pada 1340-an.  
   <sub>berkas `s10_c02.mp3` · 03:28.4 · 5.3 dtk</sub>

### 11. Empat Wilayah (Ulus)  
*03:35.0–04:00.0 · 25 dtk · c. 1300–1310*

_Arahan:_ Analitis; sebut empat wilayah dengan jeda rapi.

1. Wilayah sebesar itu sulit diperintah dari satu pusat.  
   <sub>berkas `s11_c00.mp3` · 03:35.6 · 3.9 dtk</sub>
2. Sejak perebutan takhta 1260, kekaisaran terpecah bertahap menjadi empat wilayah utama.  
   <sub>berkas `s11_c01.mp3` · 03:39.9 · 6.4 dtk</sub>
3. Yuan di Tiongkok, Ilkhanat di Persia, Khanat Chagatai di Asia Tengah, dan Golden Horde di stepa barat.  
   <sub>berkas `s11_c02.mp3` · 03:46.7 · 7.6 dtk</sub>

### 12. Keruntuhan yang Bertahap  
*04:00.0–04:30.0 · 30 dtk · 1335–1480*

_Arahan:_ Reflektif, tanpa dramatisasi.

1. Keruntuhannya berlangsung bertahap, selama lebih dari satu abad.  
   <sub>berkas `s12_c00.mp3` · 04:00.6 · 4.7 dtk</sub>
2. Ilkhanat terpecah setelah 1335.  
   <sub>berkas `s12_c01.mp3` · 04:05.7 · 2.3 dtk</sub>
3. Dinasti Yuan terusir dari Beijing oleh Ming pada 1368.  
   <sub>berkas `s12_c02.mp3` · 04:08.4 · 4.0 dtk</sub>
4. Golden Horde dilemahkan perang saudara dan serangan Timur pada 1395, lalu secara tradisional dianggap lepas dari Moskow pada 1480.  
   <sub>berkas `s12_c03.mp3` · 04:12.8 · 9.6 dtk</sub>
5. Perebutan takhta, wabah, dan bangkitnya kekuatan lokal ikut berperan.  
   <sub>berkas `s12_c04.mp3` · 04:22.9 · 5.1 dtk</sub>

### 13. Warisan  
*04:30.0–05:00.0 · 30 dtk · 1526 dan sesudahnya*

_Arahan:_ Hangat, pelan, penuh jeda; kalimat terakhir tenang.

1. Kekaisaran Mongol meninggalkan luka sekaligus warisan.  
   <sub>berkas `s13_c00.mp3` · 04:30.6 · 4.0 dtk</sub>
2. Penaklukannya menelan korban jiwa yang sangat besar, tetapi jalur perdagangannya juga mempertemukan Asia dan Eropa.  
   <sub>berkas `s13_c01.mp3` · 04:35.0 · 8.5 dtk</sub>
3. Dinasti Mughal di India, yang didirikan Babur pada 1526, mengklaim garis keturunan dari Timur dan Jenghis Khan.  
   <sub>berkas `s13_c02.mp3` · 04:43.9 · 8.2 dtk</sub>
4. Kekaisaran itu runtuh, tetapi jejaknya bertahan.  
   <sub>berkas `s13_c03.mp3` · 04:52.5 · 3.6 dtk</sub>

