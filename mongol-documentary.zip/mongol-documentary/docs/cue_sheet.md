# Cue sheet — musik & efek suara

Semua suara dibuat sintetis oleh `scripts/generate_music_sfx.py` (original, tanpa sampel pihak ketiga). Palet sengaja abstrak agar tidak meniru gaya/instrumen budaya tertentu secara stereotip.

## Dramaturgi musik (satu trek 300 dtk)

| Adegan | Waktu | Suasana | Elemen |
|---|---|---|---|
| 1. Pembuka | 00:00.0–00:15.0 | Drone rendah mengembang, satu benturan dalam saat judul, angin tipis. | |
| 2. Stepa yang Terpecah | 00:15.0–00:35.0 | Angin stepa, pad rendah minimal, tanpa perkusi. | |
| 3. Temüjin Menjadi Jenghis Khan | 00:35.0–00:55.0 | Denyut frame-drum pertama (sangat pelan), pad naik. | |
| 4. Ke Tiongkok dan Asia Tengah | 00:55.0–01:15.0 | Perkusi rendah mulai berdenyut, derap kuda tipis. | |
| 5. Perang Khwarazmia | 01:15.0–01:45.0 | Perkusi mantap, string rendah; musik menipis di kalimat terakhir. | |
| 6. Penerus Sang Khan | 01:45.0–02:05.0 | Perkusi mereda, pad berkabung ringan, lalu kembali naik. | |
| 7. Menuju Eropa | 02:05.0–02:30.0 | Tempo naik, drum bertenaga, derap kuda. | |
| 8. Baghdad dan Ain Jalut | 02:30.0–02:50.0 | Benturan dalam saat Baghdad, jeda hening singkat sebelum Ain Jalut. | |
| 9. Kubilai dan Dinasti Yuan | 02:50.0–03:15.0 | Pad mengangkat, perkusi sedang; musik meredup saat ekspedisi gagal. | |
| 10. Jalur Sutra dan Pos Yam | 03:15.0–03:35.0 | Petikan lembut, pad terang, perkusi minimal. | |
| 11. Empat Wilayah (Ulus) | 03:35.0–04:00.0 | Tegangan rendah, drone menahan, ritme hilang. | |
| 12. Keruntuhan yang Bertahap | 04:00.0–04:30.0 | String rendah jarang, perkusi hilang, ruang hening. | |
| 13. Warisan | 04:30.0–05:00.0 | Pad mayor-ringan, resolusi lembut, memudar menjadi hening. | |

Ducking: musik turun otomatis di bawah setiap kalimat narasi (aktif setelah suara dibuat), fade-in 2,5 dtk, fade-out 7 dtk.

## Efek suara sekali-putar (49)

| Waktu | Efek | Volume | ID |
|---|---|---|---|
| 00:00.6 | impact | 0.8 | title-hit |
| 00:15.3 | whoosh | 0.32 | whoosh-2 |
| 00:44.1 | ping | 0.2 | m-kurultai |
| 00:45.7 | tick | 0.28 | tick-1206 |
| 00:56.5 | tick | 0.28 | tick-1209-1215 |
| 01:02.4 | drum | 0.42 | m-zhongdu |
| 01:06.4 | tick | 0.28 | tick-1218 |
| 01:07.2 | ping | 0.2 | m-balasagun |
| 01:27.5 | drum | 0.42 | m-otrar |
| 01:29.9 | ping | 0.2 | m-bukhara |
| 01:30.2 | tick | 0.28 | tick-1220 |
| 01:30.8 | ping | 0.2 | m-samarkand |
| 01:31.8 | ping | 0.2 | m-merv |
| 01:32.4 | tick | 0.28 | tick-1221 |
| 01:32.7 | ping | 0.2 | m-nishapur |
| 01:49.3 | tick | 0.28 | tick-1227 |
| 01:56.8 | tick | 0.28 | tick-1234 |
| 01:59.3 | ping | 0.2 | m-karakorum |
| 02:05.3 | whoosh | 0.32 | whoosh-7 |
| 02:08.9 | ping | 0.2 | m-ryazan |
| 02:10.1 | ping | 0.2 | m-vladimir |
| 02:12.2 | drum | 0.42 | m-kyiv |
| 02:12.5 | tick | 0.28 | tick-1236-1240 |
| 02:16.2 | drum | 0.42 | m-legnica |
| 02:16.7 | drum | 0.42 | m-mohi |
| 02:31.2 | tick | 0.28 | tick-1243-1256 |
| 02:35.5 | impact | 0.55 | m-baghdad |
| 02:36.4 | tick | 0.28 | tick-1258 |
| 02:44.4 | drum | 0.42 | m-ainjalut |
| 02:47.2 | tick | 0.28 | tick-1253-1259 |
| 02:50.3 | whoosh | 0.32 | whoosh-9 |
| 02:58.5 | ping | 0.2 | m-dadu |
| 03:00.9 | tick | 0.28 | tick-1279 |
| 03:01.0 | drum | 0.42 | m-yamen |
| 03:05.5 | ping | 0.2 | m-hakata |
| 03:09.1 | ping | 0.2 | m-tuban |
| 03:15.3 | tick | 0.28 | tick-c1300 |
| 03:31.6 | ping | 0.2 | m-caffa |
| 03:43.1 | tick | 0.28 | tick-c1300-ulus |
| 04:00.3 | whoosh | 0.32 | whoosh-12 |
| 04:06.0 | tick | 0.28 | tick-1335 |
| 04:10.4 | impact | 0.35 | fall-1368 |
| 04:10.6 | impact | 0.55 | m-dadu-1368 |
| 04:11.2 | tick | 0.28 | tick-1368 |
| 04:16.7 | ping | 0.2 | m-terek |
| 04:17.7 | tick | 0.28 | tick-1395 |
| 04:21.5 | ping | 0.2 | m-ugra |
| 04:22.0 | tick | 0.28 | tick-1480 |
| 04:50.5 | drum | 0.42 | m-panipat |

## Loop ambient/derap (11)

| Dari | Sampai | Efek | Volume |
|---|---|---|---|
| 00:00.0 | 00:41.0 | wind | 0.34 |
| 04:42.0 | 05:00.0 | wind | 0.28 |
| 00:57.5 | 01:04.0 | hooves | 0.16 |
| 01:04.7 | 01:09.8 | hooves | 0.16 |
| 01:24.9 | 01:34.2 | hooves | 0.16 |
| 02:07.0 | 02:18.2 | hooves | 0.16 |
| 02:13.9 | 02:17.7 | hooves | 0.16 |
| 02:31.3 | 02:37.2 | hooves | 0.16 |
| 02:36.9 | 02:45.7 | hooves | 0.16 |
| 02:40.0 | 02:45.5 | hooves | 0.16 |
| 04:46.8 | 04:51.8 | hooves | 0.16 |
