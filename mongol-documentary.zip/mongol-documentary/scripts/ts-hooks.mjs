// Loader kecil agar Node dapat mengimpor file .ts tanpa ekstensi dan file .json,
// sehingga skrip validasi memakai SUMBER DATA YANG SAMA dengan Remotion.
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';

export async function resolve(specifier, context, nextResolve) {
  try {
    return await nextResolve(specifier, context);
  } catch (err) {
    if (specifier.startsWith('.') || specifier.startsWith('/')) {
      for (const ext of ['.ts', '/index.ts']) {
        try {
          return await nextResolve(specifier + ext, context);
        } catch {
          /* coba berikutnya */
        }
      }
    }
    throw err;
  }
}

export async function load(url, context, nextLoad) {
  if (url.endsWith('.json')) {
    const src = await readFile(fileURLToPath(url), 'utf8');
    return {format: 'module', source: `export default ${src};`, shortCircuit: true};
  }
  return nextLoad(url, context);
}
