// Pratinjau geometri peta sebagai SVG (tanpa Remotion) untuk pemeriksaan visual.
import {writeFileSync, mkdirSync} from 'node:fs';
import {EURASIA, AFRICA, ISLANDS, WATERS, REGIONS} from '../src/data/geo.ts';
import {project, toPath} from '../src/lib/geo.ts';

const colors = ['#e0b04a', '#c0463c', '#2fa39a', '#8e72c9', '#4f86c6', '#7fa650', '#c47fa1', '#b5a898'];
const [x0, y0] = project([-10, 75]);
const [x1, y1] = project([150, -12]);
const land = [EURASIA, AFRICA, ...ISLANDS].map((p) => `<path d="${toPath(p)}" fill="#2b2a22" stroke="#6b5b3e" stroke-width="1.5"/>`).join('');
const regs = REGIONS.map((r, i) => `<path d="${toPath(r.polygon)}" fill="${colors[i % colors.length]}" fill-opacity=".45" stroke="#fff" stroke-dasharray="6 4" stroke-width="1.2"/>`).join('');
const labels = REGIONS.map((r) => { const [x, y] = project(r.labelAt); return `<text x="${x}" y="${y}" fill="#fff" font-size="16" text-anchor="middle">${r.name}</text>`; }).join('');
const water = WATERS.map((w) => `<path d="${toPath(w.polygon)}" fill="#0b1620" stroke="#6b5b3e" stroke-width="1.5"/>`).join('');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x0} ${y0} ${x1 - x0} ${y1 - y0}" width="1800"><rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" fill="#0b1620"/>${land}${regs}${water}${labels}</svg>`;
mkdirSync('out', {recursive: true});
writeFileSync('out/map_preview.svg', svg);
console.log('ditulis: out/map_preview.svg');
