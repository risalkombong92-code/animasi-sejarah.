// Validasi konsistensi data: durasi, kronologi, tahap peta kumulatif, rute, jangkar waktu.
import {SCENES, TOTAL_SEC, FPS} from '../src/data/scenes.ts';
import {STAGES} from '../src/data/mapStages.ts';
import {MARKERS, ROUTES, RIBBONS, NAMEPLATES, AREA_LABELS} from '../src/data/events.ts';
import {REGIONS} from '../src/data/geo.ts';
import {CUES, EST_CPS, HAS_VO} from '../src/lib/timing.ts';
import {ONE_SHOTS, LOOPS} from '../src/data/audioPlan.ts';

const errors = [];
const warns = [];
const err = (m) => errors.push(m);
const warn = (m) => warns.push(m);

// 1. Durasi
if (TOTAL_SEC !== 300) err(`Total durasi ${TOTAL_SEC}s, harus 300s`);
SCENES.forEach((s, i) => { if (s.no !== i + 1) err(`Nomor adegan tidak berurutan: ${s.id}`); });

// 2. Kamera
SCENES.forEach((s) => {
  if (s.camera[0].at !== 0) err(`${s.id}: kamera harus mulai di at=0`);
  if (s.camera[s.camera.length - 1].at !== 1) err(`${s.id}: kamera harus berakhir di at=1`);
  s.camera.forEach((k, i) => {
    if (i > 0 && k.at <= s.camera[i - 1].at) err(`${s.id}: keyframe kamera tidak naik`);
    if (i > 0 && k.at * s.durationSec * FPS < 60 && SCENES.indexOf(s) > 0 && i === 1) err(`${s.id}: keyframe ke-2 terlalu dekat awal (travel 45f)`);
  });
});

// 3. Kalimat muat dalam slot adegan
let words = 0;
CUES.forEach((cues, i) => {
  const s = SCENES[i];
  const lastEnd = cues[cues.length - 1].start + cues[cues.length - 1].dur;
  const base = SCENES.slice(0, i).reduce((a, x) => a + x.durationSec, 0);
  if (lastEnd - base > s.durationSec - 0.3) err(`${s.id}: narasi (${(lastEnd - base).toFixed(1)}s) melebihi slot ${s.durationSec}s`);
  cues.forEach((c, j) => {
    words += c.text.split(/\s+/).length;
    if (j > 0 && c.start < cues[j - 1].start + cues[j - 1].dur) err(`${s.id}: kalimat ${j} tumpang tindih`);
  });
});

// 4. Tahap peta: kronologis, kumulatif, wilayah valid
const regionIds = new Set(REGIONS.map((r) => r.id));
STAGES.forEach((st, i) => {
  if (i > 0 && st.atSec <= STAGES[i - 1].atSec + 2) err(`Tahap ${st.id} terlalu dekat/mendahului tahap sebelumnya`);
  if (st.atSec > TOTAL_SEC) err(`Tahap ${st.id} di luar durasi`);
  Object.keys(st.regions).forEach((k) => { if (!regionIds.has(k)) err(`Tahap ${st.id}: wilayah tak dikenal ${k}`); });
  if (i > 0) {
    Object.keys(STAGES[i - 1].regions).forEach((k) => {
      if (!st.regions[k]) err(`Tahap ${st.id}: wilayah ${k} HILANG (tidak kumulatif)`);
    });
  }
});
if (STAGES[0].atSec !== 0) err('Tahap pertama harus di detik 0');

// 5. Rute
ROUTES.forEach((r) => {
  r.points.forEach((p, i) => {
    if (i > 0 && p.t <= r.points[i - 1].t + 0.15) err(`Rute ${r.id}: waktu titik ${i} tidak naik (${p.t.toFixed(2)})`);
    if (p.ll[0] < -10 || p.ll[0] > 150 || p.ll[1] < -12 || p.ll[1] > 75) err(`Rute ${r.id}: koordinat di luar peta`);
  });
  if (r.points[r.points.length - 1].t > TOTAL_SEC) err(`Rute ${r.id} melewati akhir video`);
});

// 6. Penanda, pita, plakat
MARKERS.forEach((m) => { if (m.at < 0 || m.at + m.hold > TOTAL_SEC + 0.01) err(`Penanda ${m.id} di luar durasi`); });
const ids = new Set();
[...MARKERS, ...ROUTES, ...RIBBONS, ...NAMEPLATES, ...AREA_LABELS].forEach((x) => { if (ids.has(x.id)) err(`ID ganda: ${x.id}`); ids.add(x.id); });
const sorted = [...RIBBONS].sort((a, b) => a.at - b.at);
sorted.forEach((r, i) => { if (i > 0 && r.at < sorted[i - 1].at + sorted[i - 1].dur - 0.05) err(`Pita ${r.id} tumpang tindih dengan ${sorted[i - 1].id}`); });
NAMEPLATES.forEach((n) => { if (n.to - n.at < 3) err(`Plakat ${n.id} tampil < 3 dtk`); });
const bySlot = {};
NAMEPLATES.forEach((n) => { (bySlot[n.slot] ??= []).push(n); });
Object.values(bySlot).forEach((arr) => { const a = [...arr].sort((x, y) => x.at - y.at); a.forEach((n, i) => { if (i > 0 && n.at < a[i - 1].to) err(`Plakat ${n.id} bertumpuk dengan ${a[i - 1].id}`); }); });

// 7. Audio
ONE_SHOTS.forEach((o) => { if (o.at < 0 || o.at > TOTAL_SEC) err(`SFX ${o.id} di luar durasi`); });
LOOPS.forEach((l) => { if (l.to <= l.from) err(`Loop ${l.id} durasi tidak valid`); });

console.log(`Adegan: ${SCENES.length} | Durasi: ${TOTAL_SEC}s (${TOTAL_SEC * FPS} frame) | Kata narasi: ${words} (~${(words / (TOTAL_SEC / 60)).toFixed(0)} kata/menit rata-rata)`);
console.log(`Tahap peta: ${STAGES.length} | Wilayah: ${REGIONS.length} | Penanda: ${MARKERS.length} | Rute: ${ROUTES.length} | Pita: ${RIBBONS.length} | Plakat: ${NAMEPLATES.length}`);
console.log(`SFX sekali-putar: ${ONE_SHOTS.length} | Loop: ${LOOPS.length} | Suara asli: ${HAS_VO ? 'ya' : 'belum (memakai estimasi ' + EST_CPS + ' kar/dtk)'}`);
warns.forEach((w) => console.log('PERINGATAN:', w));
if (errors.length) { errors.forEach((e) => console.log('GALAT:', e)); process.exit(1); }
console.log('VALID ✔');
