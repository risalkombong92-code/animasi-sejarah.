// Memeriksa semua aset yang dibutuhkan sebelum render, dan memperbarui src/data/assetStatus.json.
import {existsSync, readFileSync, writeFileSync, statSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const p = (...a) => join(root, ...a);
const ok = (b) => (b ? '✔' : '✘');

const sfx = ['impact', 'drum', 'whoosh', 'ping', 'tick', 'hooves', 'wind'].map((n) => `public/audio/sfx/${n}.mp3`);
const music = ['public/audio/music/score.mp3'];
const hasMusic = music.every((f) => existsSync(p(f)));
const hasSfx = sfx.every((f) => existsSync(p(f)));

[...music, ...sfx].forEach((f) => console.log(`${ok(existsSync(p(f)))} ${f}${existsSync(p(f)) ? ` (${(statSync(p(f)).size / 1024).toFixed(0)} KB)` : ''}`));

// Suara: baca voiceTimings.ts, pastikan semua berkas yang disebut ada
const vt = readFileSync(p('src/data/voiceTimings.ts'), 'utf8');
const generated = /generated:\s*true/.test(vt);
let voiceOk = true;
if (generated) {
  const files = [...vt.matchAll(/"file":\s*"([^"]+)"/g)].map((m) => m[1]);
  const missing = files.filter((f) => !existsSync(p('public', f)));
  voiceOk = missing.length === 0;
  console.log(`${ok(voiceOk)} voice-over: ${files.length} berkas${voiceOk ? '' : ', HILANG: ' + missing.slice(0, 5).join(', ')}`);
} else {
  console.log('• voice-over: belum dibuat (video tetap bisa dirender: subtitle + musik, tanpa suara).');
  console.log('  Buat dengan: pip install edge-tts mutagen && npm run assets:vo');
}

writeFileSync(p('src/data/assetStatus.json'), JSON.stringify({music: hasMusic, sfx: hasSfx}) + '\n');
console.log(`assetStatus.json diperbarui: music=${hasMusic}, sfx=${hasSfx}`);
if (generated && !voiceOk) process.exit(1);
if (!hasMusic || !hasSfx) console.log('• Audio latar belum lengkap — jalankan: npm run assets:audio');
