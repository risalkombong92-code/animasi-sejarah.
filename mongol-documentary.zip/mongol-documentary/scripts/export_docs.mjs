// Menghasilkan docs/naskah.md, docs/storyboard.md, docs/cue_sheet.md dan out/subtitles.id.srt
// dari data yang SAMA dengan yang dipakai Remotion (satu sumber kebenaran).
import {mkdirSync, writeFileSync} from 'node:fs';
import {SCENES, TOTAL_SEC} from '../src/data/scenes.ts';
import {CUES, HAS_VO, sceneStart} from '../src/lib/timing.ts';
import {ONE_SHOTS, LOOPS} from '../src/data/audioPlan.ts';
import {DELTAS} from '../src/data/mapStages.ts';
import {MARKERS, RIBBONS} from '../src/data/events.ts';

mkdirSync('docs', {recursive: true});
mkdirSync('out', {recursive: true});

const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${(s % 60).toFixed(1).padStart(4, '0')}`;
const srtT = (s) => {
  const ms = Math.round(s * 1000);
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), sec = Math.floor((ms % 60000) / 1000), r = ms % 1000;
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(h)}:${p(m)}:${p(sec)},${p(r, 3)}`;
};
const range = (s) => `${mmss(sceneStart(s.no))}–${mmss(sceneStart(s.no) + s.durationSec)}`;
const words = SCENES.flatMap((s) => s.cues).join(' ').split(/\s+/).length;

/* ---------------- naskah ---------------- */
let md = `# Naskah — Bangkit dan Runtuhnya Kekaisaran Mongol\n\n`;
md += `Durasi: **${TOTAL_SEC / 60} menit** (${TOTAL_SEC} dtk) · ${SCENES.length} adegan · ±${words} kata narasi · bahasa Indonesia\n\n`;
md += `> Waktu per kalimat di berkas ini ${HAS_VO ? 'berasal dari durasi audio suara asli' : '**ESTIMASI** (suara belum dibuat); akan berubah setelah `npm run assets:vo`'}.\n\n`;
md += `## Arahan pengisi suara (pria, gaya dokumenter)\n\n- Rentang suara bariton, hangat, tidak berteriak; laju ±100–110 kata/menit termasuk jeda.\n- Jeda ±0,4 dtk antarkalimat; jeda lebih panjang setelah angka tahun penting.\n- Jangan mendramatisasi korban jiwa; nada tetap faktual dan tenang.\n- Ketidakpastian ("diperdebatkan", "perkiraan") dibacakan datar, bukan sebagai keraguan pembicara.\n\n`;
md += `## Panduan pelafalan\n\n| Tulisan | Dilafalkan |\n|---|---|\n| Temüjin | te-mu-jin |\n| Ögedei | ö-ge-dei (≈ "ugedei") |\n| Jenghis Khan | jeng-gis kan |\n| Khwarazmia | kwa-raz-mi-a |\n| Zhongdu | jung-du |\n| Kyiv | ki-ev |\n| Legnica | leg-ni-tsa |\n| Mohi | mo-hi |\n| Nishapur | ni-sya-pur |\n| Kubilai | ku-bi-lai |\n| Ilkhanat | il-ka-nat |\n| Chagatai | ca-ga-tai |\n\n`;
md += `## Naskah per adegan\n\n`;
for (const s of SCENES) {
  md += `### ${s.no}. ${s.title}  \n*${range(s)} · ${s.durationSec} dtk · ${s.dateLabel}*\n\n`;
  md += `_Arahan:_ ${s.delivery}\n\n`;
  CUES[s.no - 1].forEach((c, i) => { md += `${i + 1}. ${c.text}  \n   <sub>berkas \`s${String(s.no).padStart(2, '0')}_c${String(i).padStart(2, '0')}.mp3\` · ${mmss(c.start)} · ${c.dur.toFixed(1)} dtk</sub>\n`; });
  md += `\n`;
}
writeFileSync('docs/naskah.md', md);

/* ---------------- storyboard ---------------- */
let sb = `# Storyboard — per adegan\n\nSatu peta Eurasia yang kontinu menjadi benang merah: kamera bergerak antar-adegan tanpa pemotongan (travel 1,5 dtk di awal tiap adegan). Semua elemen visual dijangkarkan ke kalimat narasi.\n\n`;
for (const s of SCENES) {
  sb += `## ${s.no}. ${s.title}\n\n| | |\n|---|---|\n`;
  sb += `| Waktu | ${range(s)} (${s.durationSec} dtk) |\n| Tujuan | ${s.purpose} |\n| Visual | ${s.visual} |\n| Teks layar | ${s.onScreen} |\n`;
  sb += `| Kamera | ${s.camera.map((k) => `(${k.lon}°B, ${k.lat}°U, zoom ${k.zoom})`).join(' → ')} |\n| Transisi | ${s.transition} |\n| Suara | ${s.sound} |\n| Catatan sumber | ${s.sources} |\n\n`;
}
sb += `## Tahap peta kronologis\n\n| Waktu | Tanggal | Perubahan |\n|---|---|---|\n`;
DELTAS.forEach((d) => { sb += `| ${mmss(d.atSec)} | ${d.dateLabel} | ${d.caption} |\n`; });
sb += `\n## Penanda & pita peristiwa\n\n| Waktu | Peristiwa |\n|---|---|\n`;
[...MARKERS.filter((m) => m.kind !== 'tribe').map((m) => [m.at, `${m.label}${m.sub ? ' — ' + m.sub : ''}`]), ...RIBBONS.map((r) => [r.at, `**Pita:** ${r.date} ${r.title}`])]
  .sort((a, b) => a[0] - b[0]).forEach(([t, l]) => { sb += `| ${mmss(t)} | ${l} |\n`; });
writeFileSync('docs/storyboard.md', sb);

/* ---------------- cue sheet ---------------- */
let cs = `# Cue sheet — musik & efek suara\n\nSemua suara dibuat sintetis oleh \`scripts/generate_music_sfx.py\` (original, tanpa sampel pihak ketiga). Palet sengaja abstrak agar tidak meniru gaya/instrumen budaya tertentu secara stereotip.\n\n`;
cs += `## Dramaturgi musik (satu trek ${TOTAL_SEC} dtk)\n\n| Adegan | Waktu | Suasana | Elemen |\n|---|---|---|---|\n`;
for (const s of SCENES) cs += `| ${s.no}. ${s.title} | ${range(s)} | ${s.sound} | |\n`;
cs += `\nDucking: musik turun otomatis di bawah setiap kalimat narasi (${HAS_VO ? 'berdasarkan audio asli' : 'aktif setelah suara dibuat'}), fade-in 2,5 dtk, fade-out 7 dtk.\n\n`;
cs += `## Efek suara sekali-putar (${ONE_SHOTS.length})\n\n| Waktu | Efek | Volume | ID |\n|---|---|---|---|\n`;
ONE_SHOTS.forEach((o) => { cs += `| ${mmss(o.at)} | ${o.sfx} | ${o.volume} | ${o.id} |\n`; });
cs += `\n## Loop ambient/derap (${LOOPS.length})\n\n| Dari | Sampai | Efek | Volume |\n|---|---|---|---|\n`;
LOOPS.forEach((l) => { cs += `| ${mmss(l.from)} | ${mmss(l.to)} | ${l.sfx} | ${l.volume} |\n`; });
writeFileSync('docs/cue_sheet.md', cs);

/* ---------------- SRT ---------------- */
let srt = '';
let n = 1;
CUES.flat().forEach((c) => { srt += `${n++}\n${srtT(c.start)} --> ${srtT(c.start + c.dur + 0.3)}\n${c.text}\n\n`; });
writeFileSync('out/subtitles.id.srt', srt);

console.log(`Ditulis: docs/naskah.md, docs/storyboard.md, docs/cue_sheet.md, out/subtitles.id.srt (${n - 1} subtitle, ${HAS_VO ? 'waktu asli' : 'waktu ESTIMASI'})`);
