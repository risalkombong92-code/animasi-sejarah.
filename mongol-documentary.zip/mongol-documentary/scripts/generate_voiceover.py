#!/usr/bin/env python3
"""
Voice-over bahasa Indonesia, suara PRIA bergaya dokumenter — satu berkas per kalimat narasi.

Mode 1 (otomatis, butuh internet):
    pip install edge-tts mutagen
    python3 scripts/generate_voiceover.py
  Memakai suara neural Microsoft Edge "id-ID-ArdiNeural" (pria). Ini layanan online milik Microsoft;
  periksa ketentuan penggunaannya sebelum memonetisasi video. Untuk produksi komersial pertimbangkan
  Azure AI Speech (berlisensi), ElevenLabs, atau rekaman pengisi suara sendiri (Mode 2).

Mode 2 (rekaman sendiri / TTS lain):
    Simpan rekaman per kalimat sebagai public/audio/vo/sNN_cMM.mp3 (mis. s03_c01.mp3 = adegan 3, kalimat ke-2),
    lalu jalankan:  python3 scripts/generate_voiceover.py --measure-only

Kedua mode mengukur durasi tiap berkas dan menulis src/data/voiceTimings.ts. Setelah itu SELURUH visual
(peta, penanda, rute, subtitle, ducking musik) otomatis menyesuaikan dengan durasi suara yang sebenarnya.

Opsi: --voice id-ID-ArdiNeural  --rate -6%  --pitch -4Hz
"""
import argparse
import asyncio
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VO_DIR = os.path.join(ROOT, "public", "audio", "vo")
NARRATION = os.path.join(ROOT, "src", "data", "narration.json")
OUT_TS = os.path.join(ROOT, "src", "data", "voiceTimings.ts")

# Durasi adegan (detik) — HARUS sama dengan src/data/scenes.ts
SCENE_DURATION = {1: 15, 2: 20, 3: 20, 4: 20, 5: 30, 6: 20, 7: 25, 8: 20, 9: 25, 10: 20, 11: 25, 12: 30, 13: 30}
LEAD, GAP, TAIL = 0.6, 0.4, 0.8

# Ejaan khusus HANYA untuk mesin TTS (teks subtitle tetap memakai ejaan asli).
PRONUNCIATION = [
    (r"Temüjin", "Temujin"), (r"Ögedei", "Ugedei"), (r"Jenghis", "Jengis"), (r"Kubilai", "Kubilai"),
    (r"Khwarazmia", "Kwarazmia"), (r"Zhongdu", "Jungdu"), (r"Ryazan", "Riazan"), (r"Kyiv", "Kiev"),
    (r"Legnica", "Legnitsa"), (r"Nishapur", "Nisyapur"), (r"Chagatai", "Cagatai"), (r"Ilkhanat", "Ilkanat"),
    (r"Subutai", "Subutai"), (r"Kereyid", "Kereyid"), (r"Mughal", "Mugal"), (r"Kara Khitai", "Kara Kitai"),
    (r"Xia Barat", "Sya Barat"), (r"Golden Horde", "Golden Hord"), (r"Mamluk", "Mamluk"),
    (r"\bkhagan\b", "kagan"), (r"\bkurultai\b", "kurultai"), (r"\byam\b", "yam"), (r"1340-an", "seribu tiga ratus empat puluhan"),
]


def tts_text(s: str) -> str:
    for pat, rep in PRONUNCIATION:
        s = re.sub(pat, rep, s)
    return s


def fname(no: int, idx: int) -> str:
    return f"s{no:02d}_c{idx:02d}.mp3"


def mp3_len(path: str) -> float:
    from mutagen.mp3 import MP3
    return float(MP3(path).info.length)


async def synth(text: str, path: str, voice: str, rate: str, pitch: str):
    import edge_tts
    await edge_tts.Communicate(text, voice, rate=rate, pitch=pitch).save(path)


def write_ts(voice: str, scenes: dict):
    body = json.dumps({"generated": True, "voice": voice, "scenes": scenes}, ensure_ascii=False, indent=2)
    with open(OUT_TS, "w", encoding="utf-8") as f:
        f.write(
            "/** DITULIS OTOMATIS oleh scripts/generate_voiceover.py — jangan edit manual. */\n"
            "export type VoiceCue = {file: string; start: number; duration: number};\n"
            "export type VoiceTimings = {generated: boolean; voice: string; scenes: Record<string, {cues: VoiceCue[]}>};\n\n"
            f"const voiceTimings: VoiceTimings = {body};\n"
            "export default voiceTimings;\n"
        )


def layout(no: int, durations: list) -> list:
    """Tempatkan kalimat berurutan di dalam adegan: lead + durasi + jeda."""
    t, out = LEAD, []
    for i, d in enumerate(durations):
        out.append({"file": f"audio/vo/{fname(no, i)}", "start": round(t, 3), "duration": round(d, 3)})
        t += d + GAP
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--measure-only", action="store_true")
    ap.add_argument("--voice", default="id-ID-ArdiNeural")
    ap.add_argument("--rate", default="-6%", help="kecepatan dasar, mis. -6%% (lebih lambat = lebih sinematik)")
    ap.add_argument("--pitch", default="-4Hz", help="nada, negatif = lebih dalam")
    args = ap.parse_args()

    os.makedirs(VO_DIR, exist_ok=True)
    narration = json.load(open(NARRATION, encoding="utf-8"))
    result, problems = {}, []

    for sc in narration:
        no = sc["no"]
        slot = SCENE_DURATION[no]
        durs = []
        if args.measure_only:
            for i in range(len(sc["cues"])):
                p = os.path.join(VO_DIR, fname(no, i))
                if not os.path.exists(p):
                    sys.exit(f"Berkas tidak ada: {os.path.relpath(p, ROOT)}")
                durs.append(mp3_len(p))
        else:
            # Coba laju dasar; jika adegan tidak muat, percepat bertahap (maks +18%).
            base = int(args.rate.replace("%", "").replace("+", ""))
            for bump in range(0, 25, 3):
                rate = f"{base + bump:+d}%"
                durs = []
                for i, text in enumerate(sc["cues"]):
                    p = os.path.join(VO_DIR, fname(no, i))
                    asyncio.run(synth(tts_text(text), p, args.voice, rate, args.pitch))
                    durs.append(mp3_len(p))
                total = LEAD + sum(durs) + GAP * (len(durs) - 1) + TAIL
                if total <= slot:
                    break
            print(f"adegan {no:2d}: laju {rate:>5}  total {total:5.1f}s / slot {slot}s")
        total = LEAD + sum(durs) + GAP * (len(durs) - 1) + TAIL
        if total > slot:
            problems.append(f"adegan {no}: narasi {total:.1f}s > slot {slot}s — persingkat teks atau perpanjang adegan")
        result[f"s{no:02d}"] = {"cues": layout(no, durs)}

    write_ts(args.voice, result)
    print("Ditulis:", os.path.relpath(OUT_TS, ROOT))
    for p in problems:
        print("PERINGATAN:", p)
    print("Selesai. Jalankan: npm run check && npm run render")


if __name__ == "__main__":
    main()
