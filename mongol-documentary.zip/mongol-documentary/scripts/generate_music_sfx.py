#!/usr/bin/env python3
"""
Membuat musik latar sinematik (300 dtk) dan efek suara SECARA SINTETIS (numpy/scipy).
Semua suara dihasilkan dari rumus di file ini -> ORIGINAL, tidak memakai sampel/lagu pihak ketiga,
sehingga tidak ada lisensi eksternal yang perlu diverifikasi (lisensi = milik Anda sebagai pembuat).

Palet sengaja abstrak (drone rendah, pad string-sintetis, frame-drum, petikan lembut).
Tidak meniru instrumen/gaya tradisional tertentu agar tidak terjatuh ke stereotip budaya.

Keluaran : public/audio/music/score.mp3, public/audio/sfx/*.mp3
Kebutuhan: python3, numpy, scipy, ffmpeg (dengan libmp3lame)
Pakai    : python3 scripts/generate_music_sfx.py
"""
import os
import subprocess
import tempfile

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, fftconvolve, lfilter

SR = 32000
TOTAL = 300.0
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_DIR = os.path.join(ROOT, "public", "audio", "music")
SFX_DIR = os.path.join(ROOT, "public", "audio", "sfx")
rng = np.random.default_rng(7)  # deterministik: hasil sama setiap dijalankan


# ----------------------------------------------------------------- util
def tarr(dur):
    return np.arange(int(dur * SR)) / SR


def smooth_env(n, attack, release):
    """Envelope bentuk sinus: naik selama attack, turun selama release (detik)."""
    e = np.ones(n, dtype=np.float32)
    a = min(int(attack * SR), n // 2)
    r = min(int(release * SR), n // 2)
    if a > 0:
        e[:a] = np.sin(np.linspace(0, np.pi / 2, a)) ** 2
    if r > 0:
        e[n - r:] *= np.cos(np.linspace(0, np.pi / 2, r)) ** 2
    return e


def curve(points, n):
    """Interpolasi linear (detik,nilai) ke array sepanjang n sampel."""
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return np.interp(np.arange(n) / SR, xs, ys).astype(np.float32)


def lowpass(x, fc, order=2):
    b, a = butter(order, fc / (SR / 2), btype="low")
    return lfilter(b, a, x)


def bandpass(x, lo, hi, order=2):
    b, a = butter(order, [lo / (SR / 2), hi / (SR / 2)], btype="band")
    return lfilter(b, a, x)


def make_ir(seed, dur=2.6, decay=3.2):
    r = np.random.default_rng(seed)
    n = int(dur * SR)
    ir = r.standard_normal(n) * np.exp(-decay * np.arange(n) / SR)
    ir = lowpass(ir, 4200)
    ir[0] = 0
    return (ir / np.sqrt(np.sum(ir ** 2))).astype(np.float32)


def add(dst, src, at_sec, gain=1.0):
    i = int(at_sec * SR)
    if i >= len(dst):
        return
    j = min(len(dst), i + len(src))
    dst[i:j] += src[: j - i] * gain


def save_mp3(path, audio, stereo=False, q=4):
    audio = np.clip(audio, -1, 1)
    data = (audio * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wavfile.write(tmp.name, SR, data)
        wav = tmp.name
    os.makedirs(os.path.dirname(path), exist_ok=True)
    subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-codec:a", "libmp3lame", "-q:a", str(q), path],
        check=True,
    )
    os.remove(wav)
    print(f"  -> {os.path.relpath(path, ROOT)}  ({os.path.getsize(path) / 1024:.0f} KB)")


# ----------------------------------------------------------------- nada
N = {  # frekuensi (Hz)
    "D2": 73.42, "A2": 110.0, "Bb2": 116.54, "C3": 130.81, "D3": 146.83, "Eb3": 155.56, "E3": 164.81,
    "F3": 174.61, "Fs3": 185.0, "G2": 98.0, "G3": 196.0, "A3": 220.0, "Bb3": 233.08, "C4": 261.63,
    "D4": 293.66, "E4": 329.63, "F4": 349.23, "A4": 440.0,
}


def voice(freq, dur, harmonics=6, detune=0.0015, phase=0.0):
    """Suara pad: harmonik menurun + dua salinan sedikit disetem-ulang (efek ansambel)."""
    t = tarr(dur)
    out = np.zeros_like(t)
    for d in (-detune, detune):
        for k in range(1, harmonics + 1):
            out += np.sin(2 * np.pi * freq * (1 + d) * k * t + phase + k) / (k ** 1.35)
    return out.astype(np.float32)


def frame_drum(dur=1.4, f0=150.0, f1=62.0, tone=0.9, noise=0.35):
    t = tarr(dur)
    f = f1 + (f0 - f1) * np.exp(-t * 22)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t * 7.5)
    click = bandpass(rng.standard_normal(len(t)), 300, 2400) * np.exp(-t * 55)
    ring = np.sin(2 * np.pi * 2.0 * f1 * t) * np.exp(-t * 11) * 0.15
    return (tone * body + noise * click + ring).astype(np.float32)


# ============================================================= MUSIK
def build_score():
    n = int(TOTAL * SR)
    drone = np.zeros(n, dtype=np.float32)
    pad = np.zeros(n, dtype=np.float32)
    perc = np.zeros(n, dtype=np.float32)
    pluck = np.zeros(n, dtype=np.float32)

    # --- Drone D2 + A2 (lapisan paling bawah, mengikuti kurva intensitas) ---
    t = tarr(TOTAL)
    d = np.sin(2 * np.pi * N["D2"] * t) + 0.5 * np.sin(2 * np.pi * N["D2"] * 2 * t + 0.7) \
        + 0.55 * np.sin(2 * np.pi * N["A2"] * t * (1 + 0.0007 * np.sin(2 * np.pi * 0.05 * t)))
    d += 0.25 * np.sin(2 * np.pi * N["D2"] * 3 * t)
    drone[:] = d.astype(np.float32) * (0.85 + 0.15 * np.sin(2 * np.pi * 0.07 * t)).astype(np.float32)
    drone *= curve([(0, 0), (3, .30), (15, .36), (35, .26), (75, .32), (125, .36), (150, .46), (163, .20),
                    (170, .30), (215, .36), (250, .28), (285, .10), (300, 0)], n)

    # --- Pad akor (jadwal dibuat mengikuti dramaturgi adegan) ---
    chords = [
        (15, 35, ["D3", "A3"], .55), (35, 55, ["D3", "F3", "A3"], .7), (55, 75, ["Bb2", "D3", "F3"], .85),
        (75, 90, ["D3", "F3", "A3"], .9), (90, 105, ["G2", "Bb2", "D3"], .9),
        (105, 115, ["Bb2", "D3", "F3"], .55), (115, 125, ["G2", "Bb2", "D3"], .5),     # adegan 6: ringan, berkabung
        (125, 137, ["D3", "F3", "A3"], 1.0), (137, 150, ["C3", "E3", "G3"], 1.0),       # adegan 7: tenaga naik
        (150, 163, ["D3", "Eb3", "A3"], .85), (163, 170, ["D3", "A3"], .45),            # adegan 8: tegang, lalu jeda
        (170, 182, ["F3", "A3", "C4"], .95), (182, 195, ["C3", "E3", "G3"], .95),       # adegan 9: terangkat
        (195, 215, ["D3", "F3", "A3", "C4"], .6),                                       # adegan 10: ringan
        (215, 228, ["G2", "Bb2", "D3"], .6), (228, 240, ["D3", "F3", "A3"], .55),       # adegan 11: tegang tertahan
        (240, 250, ["Bb2", "D3", "F3"], .45), (250, 262, ["G2", "Bb2", "D3"], .38),     # adegan 12: menurun
        (262, 272, ["D3", "F3", "A3"], .3),
        (272, 290, ["D3", "Fs3", "A3"], .55), (290, 300, ["D3", "E3", "A3"], .3),       # adegan 13: cahaya lembut -> hening
    ]
    for (a, b, notes, amp) in chords:
        dur = (b - a) + 6.0  # tumpang tindih 3 dtk di kedua sisi untuk crossfade
        env = smooth_env(int(dur * SR), 3.0, 3.0)
        seg = np.zeros(int(dur * SR), dtype=np.float32)
        for i, nm in enumerate(notes):
            seg += voice(N[nm], dur, phase=i * 1.3)
        seg *= env * amp * 0.16
        # tremolo sangat pelan agar terasa "bernapas"
        tt = tarr(dur)
        seg *= (0.88 + 0.12 * np.sin(2 * np.pi * 0.11 * tt + a)).astype(np.float32)
        add(pad, seg, a - 3.0)
    pad *= curve([(0, 0), (8, .5), (15, .9), (300, .9)], n)

    # --- Perkusi frame-drum (pola per bagian) ---
    kick = frame_drum()
    soft = frame_drum(f0=130, f1=58, tone=0.8, noise=0.25)
    sections = [  # (mulai, selesai, bpm, pola 8 langkah, amplitudo)
        (35, 55, 54, [1, 0, 0, 0, 0, 0, 0, 0], .30),
        (55, 105, 72, [1, 0, .5, 0, .8, 0, .5, .4], .55),
        (105, 125, 54, [1, 0, 0, 0, 0, 0, 0, 0], .30),
        (125, 150, 88, [1, 0, .6, .5, .9, 0, .6, .5], .72),
        (150, 160, 60, [1, 0, 0, 0, 0, 0, 0, 0], .42),
        (170, 195, 76, [1, 0, .5, 0, .8, 0, .5, 0], .48),
        (215, 240, 60, [1, 0, 0, 0, 0, 0, 0, 0], .30),
        (240, 262, 50, [1, 0, 0, 0, 0, 0, 0, 0], .22),
    ]
    for (a, b, bpm, pat, amp) in sections:
        step = 60.0 / bpm / 2  # not 1/8
        k = 0
        while a + k * step < b:
            v = pat[k % 8]
            if v > 0:
                # fade amplitudo di dua detik terakhir bagian agar tidak terpotong tiba-tiba
                fade = min(1.0, (b - (a + k * step)) / 2.0)
                add(perc, (kick if v >= .8 else soft), a + k * step + rng.uniform(-0.004, 0.004), amp * v * fade)
            k += 1
    # satu pukulan dalam saat Baghdad & jeda hening menjelang Ain Jalut (adegan 8)
    add(perc, frame_drum(2.2, 120, 48, 1.1, .3), 156.4, 0.7)
    add(perc, frame_drum(2.6, 120, 46, 1.1, .3), 166.0, 0.6)

    # --- Petikan lembut (adegan 10: konektivitas Jalur Sutra) ---
    scale = ["D3", "F3", "A3", "C4", "D4", "F4", "A4", "E4"]
    seq = [0, 2, 4, 3, 5, 4, 2, 1, 0, 3, 4, 6, 5, 3, 2, 7]
    step = 60.0 / 92 / 2
    k = 0
    while 195 + k * step < 215:
        nm = scale[seq[k % len(seq)]]
        tt = tarr(1.6)
        note = (np.sin(2 * np.pi * N[nm] * tt) + .4 * np.sin(2 * np.pi * N[nm] * 2 * tt) + .15 * np.sin(2 * np.pi * N[nm] * 3 * tt)) * np.exp(-tt * 3.2)
        a_t = 195 + k * step
        fade = min(1.0, (a_t - 195) / 3.0, (215 - a_t) / 3.0)
        add(pluck, note.astype(np.float32), a_t, 0.16 * max(0.0, fade) * (0.7 + 0.3 * ((k % 4) == 0)))
        k += 1

    # --- Reverb (IR berbeda untuk kiri/kanan => lebar stereo) ---
    wet_src = pad + 0.6 * pluck + 0.35 * perc
    irL, irR = make_ir(11), make_ir(23)
    wetL = fftconvolve(wet_src, irL)[:n].astype(np.float32)
    wetR = fftconvolve(wet_src, irR)[:n].astype(np.float32)

    dry = drone + pad + pluck + perc
    L = dry + 0.55 * wetL
    R = dry + 0.55 * wetR
    # pelebaran ringan: drone sedikit bergeser antar kanal
    sh = int(0.0007 * SR)
    R = np.roll(R, sh)

    mix = np.stack([L, R], axis=1)
    peak = np.max(np.abs(mix))
    mix = mix / peak * 0.7  # sisakan headroom (~ -3 dBFS)
    # fade awal & akhir (musik berakhir hening di detik 300)
    fade_in = np.minimum(1, np.arange(n) / (2.0 * SR))
    fade_out = np.minimum(1, (n - np.arange(n)) / (6.0 * SR))
    mix *= (fade_in * fade_out)[:, None]
    return mix.astype(np.float32)


def save_stereo_mp3(path, stereo, q=3):
    data = (np.clip(stereo, -1, 1) * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wavfile.write(tmp.name, SR, data)
        wav = tmp.name
    os.makedirs(os.path.dirname(path), exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-codec:a", "libmp3lame", "-q:a", str(q), path], check=True)
    os.remove(wav)
    print(f"  -> {os.path.relpath(path, ROOT)}  ({os.path.getsize(path) / 1024 / 1024:.1f} MB)")


# ============================================================= SFX
def sfx_impact():
    dur = 3.8
    t = tarr(dur)
    f = 36 + 40 * np.exp(-t * 6)
    boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 1.6)
    rumble = lowpass(rng.standard_normal(len(t)), 180) * np.exp(-t * 2.2) * 2.2
    hit = bandpass(rng.standard_normal(len(t)), 80, 900) * np.exp(-t * 18) * 0.6
    x = boom + rumble + hit
    wet = fftconvolve(x, make_ir(5, 2.0, 3.0))[: len(t)]
    x = (x + 0.5 * wet) * smooth_env(len(t), 0.002, 0.8)
    return x / np.max(np.abs(x)) * 0.9


def sfx_drum():
    x = frame_drum(1.6, 170, 66, 1.0, 0.4)
    wet = fftconvolve(x, make_ir(9, 1.2, 4.0))[: len(x)]
    x = x + 0.25 * wet
    return x / np.max(np.abs(x)) * 0.85


def sfx_whoosh():
    dur = 2.4
    n = int(dur * SR)
    noise = rng.standard_normal(n)
    out = np.zeros(n)
    block = 1024
    zi = None
    for i in range(0, n, block):
        p = i / n
        fc = 250 + 2600 * np.sin(np.pi * p) ** 2  # sapuan frekuensi naik-turun
        b, a = butter(2, [max(60, fc * 0.5) / (SR / 2), min(0.95, fc / (SR / 2))], btype="band")
        if zi is None:
            zi = np.zeros(max(len(a), len(b)) - 1)
        seg, zi = lfilter(b, a, noise[i:i + block], zi=zi)
        out[i:i + block] = seg
    env = np.sin(np.pi * np.linspace(0, 1, n)) ** 2.2
    x = out * env
    return x / np.max(np.abs(x)) * 0.8


def sfx_ping():
    t = tarr(1.4)
    x = (np.sin(2 * np.pi * 880 * t) + 0.45 * np.sin(2 * np.pi * 1320 * t) + 0.2 * np.sin(2 * np.pi * 1760 * t)) * np.exp(-t * 4.2)
    x *= smooth_env(len(t), 0.004, 0.2)
    return x / np.max(np.abs(x)) * 0.7


def sfx_tick():
    t = tarr(0.45)
    click = bandpass(rng.standard_normal(len(t)), 1200, 5500) * np.exp(-t * 90)
    tone = np.sin(2 * np.pi * 1500 * t) * np.exp(-t * 28) * 0.6
    x = click + tone
    return x / np.max(np.abs(x)) * 0.7


def sfx_hooves():
    """Derap berirama ('gallop' 3-ketuk), 6 dtk, dibuat agar mulus saat di-loop."""
    dur = 6.0
    n = int(dur * SR)
    out = np.zeros(n, dtype=np.float64)
    cycle = 0.62  # detik per siklus galop
    r = np.random.default_rng(3)
    k = 0
    while k * cycle < dur:
        for off, amp in ((0.0, 0.8), (0.17, 1.0), (0.33, 0.9)):
            t0 = k * cycle + off + r.uniform(-0.006, 0.006)
            for rider in range(3):  # beberapa kuda, sedikit tidak serempak
                tt = t0 + rider * r.uniform(0.004, 0.02)
                m = int(0.09 * SR)
                tk = np.arange(m) / SR
                hit = bandpass(r.standard_normal(m), 350, 1800) * np.exp(-tk * 55) + 0.5 * np.sin(2 * np.pi * 95 * tk) * np.exp(-tk * 35)
                i = int(tt * SR) % n  # bungkus melingkar -> loop mulus
                end = min(n, i + m)
                out[i:end] += hit[: end - i] * amp * (0.6 + 0.4 * r.random())
        k += 1
    out = lowpass(out, 2600)
    return (out / np.max(np.abs(out)) * 0.7).astype(np.float32)


def sfx_wind():
    """Angin stepa, 24 dtk, loop mulus lewat crossfade."""
    dur = 26.0
    n = int(dur * SR)
    noise = rng.standard_normal(n)
    out = np.zeros(n)
    block = 2048
    zi = None
    for i in range(0, n, block):
        tsec = i / SR
        fc = 380 + 240 * np.sin(2 * np.pi * tsec / 9.0) + 120 * np.sin(2 * np.pi * tsec / 3.7)
        b, a = butter(2, fc / (SR / 2), btype="low")
        if zi is None:
            zi = np.zeros(max(len(a), len(b)) - 1)
        seg, zi = lfilter(b, a, noise[i:i + block], zi=zi)
        out[i:i + block] = seg
    tt = np.arange(n) / SR
    out *= 0.65 + 0.35 * np.sin(2 * np.pi * tt / 6.3 + 1.0) * np.sin(2 * np.pi * tt / 11.0)
    cf = int(2.0 * SR)
    loop = out[: n - cf].copy()
    w = np.linspace(0, 1, cf)
    loop[:cf] = loop[:cf] * w + out[n - cf:] * (1 - w)
    return (loop / np.max(np.abs(loop)) * 0.6).astype(np.float32)


def main():
    print("Membuat efek suara ...")
    save_mp3(os.path.join(SFX_DIR, "impact.mp3"), sfx_impact())
    save_mp3(os.path.join(SFX_DIR, "drum.mp3"), sfx_drum())
    save_mp3(os.path.join(SFX_DIR, "whoosh.mp3"), sfx_whoosh())
    save_mp3(os.path.join(SFX_DIR, "ping.mp3"), sfx_ping())
    save_mp3(os.path.join(SFX_DIR, "tick.mp3"), sfx_tick())
    save_mp3(os.path.join(SFX_DIR, "hooves.mp3"), sfx_hooves())
    save_mp3(os.path.join(SFX_DIR, "wind.mp3"), sfx_wind())
    print("Membuat musik latar 300 dtk (butuh beberapa detik) ...")
    save_stereo_mp3(os.path.join(MUSIC_DIR, "score.mp3"), build_score())
    print("Selesai. Jalankan: node scripts/check_assets.mjs")


if __name__ == "__main__":
    main()
